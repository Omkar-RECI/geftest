import gefIconLogo from "../assets/gef/Gef_icon_logo.svg";

export const SITE_NAME = "Global Entrepreneurs Forum";
export const SITE_SHORT_NAME = "GEF";
export const SITE_ALTERNATE_NAMES = [
  "GEF",
  "Global Entrepreneur Forum",
  "Global Entrepreneurs Conclave",
  "GEC",
];
export const SITE_URL = "https://gefofficial.com";
export const SITE_LEGACY_URL = "https://globalentrepreneursforum.com";
export const DEFAULT_OG_IMAGE = `${SITE_URL}/Assets/Gallary/1.webp`;
export const ORGANIZATION_LOGO = gefIconLogo;
export const SITE_DESCRIPTION =
  "Global Entrepreneurs Forum connects entrepreneurs, investors, business leaders, policymakers, academia, and ecosystem partners across global markets.";
export const ORGANIZATION_EMAIL = "info@gefofficial.com";
export const ORGANIZATION_PHONE = "+91 95035 63577";
export const ORGANIZATION_ADDRESS_TEXT =
  "9th Floor, Park Plaza, IndiQube, Shivajinagar, Pune, Maharashtra 411016";
export const ORGANIZATION_ADDRESS = {
  "@type": "PostalAddress",
  streetAddress: "9th Floor, Park Plaza, IndiQube, Shivajinagar",
  addressLocality: "Pune",
  addressRegion: "Maharashtra",
  postalCode: "411016",
  addressCountry: "IN",
} as const;

export const SOCIAL_PROFILES = {
  linkedin: "https://www.linkedin.com/company/globalentrepreneursforum/",
  instagram: "https://www.instagram.com/gef_officiall",
  youtube: null,
  facebook: null,
} as const;

export const SOCIAL_LINKS = Object.values(SOCIAL_PROFILES).filter((url): url is string => Boolean(url));

export type SeoInput = {
  title: string;
  description: string;
  path: string;
  image?: string;
  type?: "website" | "article";
  keywords?: string[];
  noIndex?: boolean;
};

export function absoluteUrl(path: string) {
  if (!path) return SITE_URL;
  if (/^https?:\/\//i.test(path)) return path;
  return `${SITE_URL}${path.startsWith("/") ? path : `/${path}`}`;
}

export function createSeoHead({
  title,
  description,
  path,
  image = DEFAULT_OG_IMAGE,
  type = "website",
  keywords,
  noIndex = false,
}: SeoInput) {
  const canonicalUrl = absoluteUrl(path);
  const socialImage = absoluteUrl(image);

  return {
    meta: [
      { title },
      { name: "description", content: description },
      ...(keywords?.length ? [{ name: "keywords", content: keywords.join(", ") }] : []),
      {
        name: "robots",
        content: noIndex
          ? "noindex, nofollow"
          : "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1",
      },
      ...(noIndex
        ? []
        : [
            {
              name: "googlebot",
              content: "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1",
            },
          ]),
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: type },
      { property: "og:url", content: canonicalUrl },
      { property: "og:site_name", content: SITE_NAME },
      { property: "og:image", content: socialImage },
      { property: "og:image:alt", content: `${SITE_NAME} preview image` },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: title },
      { name: "twitter:description", content: description },
      { name: "twitter:image", content: socialImage },
    ],
    links: [{ rel: "canonical", href: canonicalUrl }],
  };
}

export function organizationSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "Organization",
    "@id": `${SITE_URL}/#organization`,
    name: SITE_NAME,
    legalName: SITE_NAME,
    alternateName: SITE_ALTERNATE_NAMES,
    url: SITE_URL,
    logo: absoluteUrl(ORGANIZATION_LOGO),
    image: absoluteUrl(DEFAULT_OG_IMAGE),
    description: SITE_DESCRIPTION,
    email: ORGANIZATION_EMAIL,
    telephone: ORGANIZATION_PHONE,
    address: ORGANIZATION_ADDRESS,
    areaServed: "Worldwide",
    foundingDate: "2022",
    sameAs: SOCIAL_LINKS,
    subjectOf: [
      {
        "@type": "WebSite",
        url: SITE_LEGACY_URL,
        name: "Global Entrepreneurs Forum legacy domain",
      },
    ],
    brand: {
      "@type": "Brand",
      name: SITE_NAME,
      logo: absoluteUrl(ORGANIZATION_LOGO),
      url: SITE_URL,
    },
    foundingOrganization: {
      "@type": "Organization",
      name: "RECI India Foundation",
      url: "https://reciindia.com/",
    },
    knowsAbout: [
      "Entrepreneurship",
      "Business Networking",
      "Startups",
      "Investment",
      "Innovation",
      "Business Growth",
      "Global Partnerships",
      "Trade",
      "Economic Development",
    ],
    contactPoint: [
      {
        "@type": "ContactPoint",
        contactType: "customer support",
        email: ORGANIZATION_EMAIL,
        telephone: ORGANIZATION_PHONE,
        areaServed: "Worldwide",
        availableLanguage: ["English"],
      },
    ],
  };
}

export function websiteSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "@id": `${SITE_URL}/#website`,
    url: SITE_URL,
    name: SITE_NAME,
    alternateName: [SITE_SHORT_NAME, ...SITE_ALTERNATE_NAMES],
    description: SITE_DESCRIPTION,
    keywords: [SITE_NAME, SITE_SHORT_NAME, ...SITE_ALTERNATE_NAMES],
    publisher: {
      "@id": `${SITE_URL}/#organization`,
    },
    inLanguage: "en",
  };
}

export function webpageSchema({
  path,
  name,
  description,
}: {
  path: string;
  name: string;
  description: string;
}) {
  return {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "@id": `${absoluteUrl(path)}#webpage`,
    url: absoluteUrl(path),
    name,
    description,
    primaryImageOfPage: absoluteUrl(DEFAULT_OG_IMAGE),
    isPartOf: {
      "@id": `${SITE_URL}/#website`,
    },
    about: {
      "@id": `${SITE_URL}/#organization`,
    },
    inLanguage: "en",
  };
}

export function collectionPageSchema({
  path,
  name,
  description,
}: {
  path: string;
  name: string;
  description: string;
}) {
  return {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    "@id": `${absoluteUrl(path)}#collectionpage`,
    url: absoluteUrl(path),
    name,
    description,
    primaryImageOfPage: absoluteUrl(DEFAULT_OG_IMAGE),
    isPartOf: {
      "@id": `${SITE_URL}/#website`,
    },
    about: {
      "@id": `${SITE_URL}/#organization`,
    },
    inLanguage: "en",
  };
}

export function breadcrumbSchema(
  items: Array<{
    name: string;
    path: string;
  }>,
) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      item: absoluteUrl(item.path),
    })),
  };
}

export function faqSchema(
  items: Array<{
    question: string;
    answer: string;
  }>,
) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: items.map((item) => ({
      "@type": "Question",
      name: item.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: item.answer,
      },
    })),
  };
}

export function videoSchema({
  name,
  description,
  embedUrl,
  pagePath,
  thumbnailUrl = DEFAULT_OG_IMAGE,
}: {
  name: string;
  description: string;
  embedUrl: string;
  pagePath: string;
  thumbnailUrl?: string;
}) {
  return {
    "@context": "https://schema.org",
    "@type": "VideoObject",
    name,
    description,
    embedUrl,
    thumbnailUrl: [absoluteUrl(thumbnailUrl)],
    publisher: {
      "@id": `${SITE_URL}/#organization`,
    },
    mainEntityOfPage: absoluteUrl(pagePath),
  };
}

export function itemListSchema({
  name,
  items,
}: {
  name: string;
  items: Array<{
    name: string;
    url: string;
  }>;
}) {
  return {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name,
    itemListElement: items.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      url: absoluteUrl(item.url),
    })),
  };
}

export function personSchema({
  name,
  designation,
  organization,
  country,
  photo,
  path = "/speakers",
}: {
  name: string;
  designation?: string;
  organization?: string;
  country?: string;
  photo?: string;
  path?: string;
}) {
  return {
    "@type": "Person",
    "@id": `${absoluteUrl(path)}#${encodeURIComponent(name.toLowerCase())}`,
    name,
    url: absoluteUrl(path),
    ...(designation ? { jobTitle: designation } : {}),
    ...(organization
      ? {
          worksFor: {
            "@type": "Organization",
            name: organization,
          },
        }
      : {}),
    ...(country ? { homeLocation: { "@type": "Country", name: country } } : {}),
    ...(photo ? { image: absoluteUrl(photo) } : {}),
    mainEntityOfPage: absoluteUrl(path),
  };
}

const MONTH_MAP: Record<string, string> = {
  january: "01",
  february: "02",
  march: "03",
  april: "04",
  may: "05",
  june: "06",
  july: "07",
  august: "08",
  september: "09",
  october: "10",
  november: "11",
  december: "12",
};

function normalizeEventDate(dateText: string) {
  return dateText
    .replace(/^held on\s+/i, "")
    .replace(/(\d+)(st|nd|rd|th)/gi, "$1")
    .replace(/\s+/g, " ")
    .trim();
}

function toIsoDate(year: string, monthName: string, day: string) {
  const month = MONTH_MAP[monthName.toLowerCase()];

  if (!month) return undefined;

  return `${year}-${month}-${day.padStart(2, "0")}`;
}

export function parseEventDateRange(dateText: string) {
  const normalized = normalizeEventDate(dateText);

  let match = normalized.match(/^(\d{1,2})\s*[–-]\s*(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})$/);
  if (match) {
    const [, startDay, endDay, monthName, year] = match;
    return {
      startDate: toIsoDate(year, monthName, startDay),
      endDate: toIsoDate(year, monthName, endDay),
    };
  }

  match = normalized.match(/^(\d{1,2})\s*&\s*(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})$/);
  if (match) {
    const [, startDay, endDay, monthName, year] = match;
    return {
      startDate: toIsoDate(year, monthName, startDay),
      endDate: toIsoDate(year, monthName, endDay),
    };
  }

  match = normalized.match(/^(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})$/);
  if (match) {
    const [, day, monthName, year] = match;
    return {
      startDate: toIsoDate(year, monthName, day),
    };
  }

  match = normalized.match(/^([A-Za-z]+)\s+(\d{4})$/);
  if (match) {
    const [, monthName, year] = match;
    const month = MONTH_MAP[monthName.toLowerCase()];
    return month ? { startDate: `${year}-${month}-01` } : {};
  }

  return {};
}

export function eventSchema({
  path,
  name,
  description,
  image,
  startDate,
  endDate,
  locationName,
  locationAddress,
  eventStatus,
}: {
  path: string;
  name: string;
  description: string;
  image?: string;
  startDate?: string;
  endDate?: string;
  locationName?: string;
  locationAddress?: string;
  eventStatus:
    | "https://schema.org/EventScheduled"
    | "https://schema.org/EventCompleted";
}) {
  return {
    "@context": "https://schema.org",
    "@type": "Event",
    "@id": `${absoluteUrl(path)}#event`,
    name,
    description,
    url: absoluteUrl(path),
    ...(image ? { image: [absoluteUrl(image)] } : {}),
    ...(startDate ? { startDate } : {}),
    ...(endDate ? { endDate } : {}),
    eventStatus,
    eventAttendanceMode: "https://schema.org/OfflineEventAttendanceMode",
    organizer: {
      "@id": `${SITE_URL}/#organization`,
    },
    mainEntityOfPage: absoluteUrl(path),
    ...(locationName || locationAddress
      ? {
          location: {
            "@type": "Place",
            ...(locationName ? { name: locationName } : {}),
            ...(locationAddress
              ? {
                  address: locationAddress,
                }
              : {}),
          },
        }
      : {}),
  };
}
