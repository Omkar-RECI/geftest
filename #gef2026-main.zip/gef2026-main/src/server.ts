import "./lib/error-capture";

import { consumeLastCapturedError } from "./lib/error-capture";
import { renderErrorPage } from "./lib/error-page";

type ServerEntry = {
  fetch: (request: Request, env: unknown, ctx: unknown) => Promise<Response> | Response;
};

let serverEntryPromise: Promise<ServerEntry> | undefined;

const NON_CANONICAL_HOSTS = new Set([
  "globalentrepreneursforum.com",
  "www.globalentrepreneursforum.com",
  "www.gefofficial.com",
]);

const LEGACY_PATH_REDIRECTS: Record<string, string> = {
  "/gef-pune-2026": "/GEFPune2027",
};

const SECURITY_HEADERS = {
  "Content-Security-Policy": "frame-ancestors 'self'",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "SAMEORIGIN",
} as const;

function withSecurityHeaders(response: Response) {
  const headers = new Headers(response.headers);
  for (const [name, value] of Object.entries(SECURITY_HEADERS)) {
    headers.set(name, value);
  }

  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers,
  });
}

function redirectToCanonicalDomain(request: Request) {
  const url = new URL(request.url);

  if (!NON_CANONICAL_HOSTS.has(url.hostname.toLowerCase())) return undefined;

  url.protocol = "https:";
  url.hostname = "gefofficial.com";
  url.port = "";

  return Response.redirect(url, 301);
}

function redirectLegacyPath(request: Request) {
  const url = new URL(request.url);
  const target = LEGACY_PATH_REDIRECTS[url.pathname];

  if (!target) return undefined;

  url.pathname = target;
  return Response.redirect(url, 301);
}

async function getServerEntry(): Promise<ServerEntry> {
  if (!serverEntryPromise) {
    serverEntryPromise = import("@tanstack/react-start/server-entry").then(
      (m) => (m.default ?? m) as ServerEntry,
    );
  }
  return serverEntryPromise;
}

// h3 swallows in-handler throws into a normal 500 Response with body
// {"unhandled":true,"message":"HTTPError"} — try/catch alone never fires for those.
async function normalizeCatastrophicSsrResponse(response: Response): Promise<Response> {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;

  const body = await response.clone().text();
  if (!body.includes('"unhandled":true') || !body.includes('"message":"HTTPError"')) {
    return response;
  }

  console.error(consumeLastCapturedError() ?? new Error(`h3 swallowed SSR error: ${body}`));
  return new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" },
  });
}

export default {
  async fetch(request: Request, env: unknown, ctx: unknown) {
    try {
      const canonicalRedirect = redirectToCanonicalDomain(request);
      if (canonicalRedirect) return withSecurityHeaders(canonicalRedirect);

      const legacyPathRedirect = redirectLegacyPath(request);
      if (legacyPathRedirect) return withSecurityHeaders(legacyPathRedirect);

      const handler = await getServerEntry();
      const response = await handler.fetch(request, env, ctx);
      return withSecurityHeaders(await normalizeCatastrophicSsrResponse(response));
    } catch (error) {
      console.error(error);
      return withSecurityHeaders(new Response(renderErrorPage(), {
        status: 500,
        headers: { "content-type": "text/html; charset=utf-8" },
      }));
    }
  },
};
