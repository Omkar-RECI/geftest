import { useEffect } from "react";

export const REGISTRATION_URL = "https://tktplz.events/gje6gw-global-entreprenures-forum?page=embed-btn";
const REGISTRATION_PREVIEW_SCRIPT = "https://cdn1.godcstatic.com/diy_registration_staging/preview.js";
const REGISTRATION_IFRAME_SCRIPT = "https://cdn1.godcstatic.com/diy_registration/diy-iframe.min.js";
const OVERLAY_ID = "myDIV";
const OVERLAY_OPEN_CLASS = "gef-registration-overlay-open";

const registrationOverlayStyles = `
  body.${OVERLAY_OPEN_CLASS} header {
    position: fixed !important;
    top: 0;
    left: 0;
    right: 0;
    z-index: 10001 !important;
  }

  body.${OVERLAY_OPEN_CLASS} #${OVERLAY_ID} {
    top: 80px !important;
    height: calc(100dvh - 80px) !important;
    z-index: 10000 !important;
  }

  body.${OVERLAY_OPEN_CLASS} #${OVERLAY_ID} iframe {
    height: 100% !important;
    max-height: none !important;
    border-radius: 0 !important;
  }
`;

function loadExternalScript(source: string) {
  return new Promise<void>((resolve, reject) => {
    const existingScript = document.querySelector<HTMLScriptElement>(`script[src="${source}"]`);
    if (existingScript) {
      if (existingScript.dataset.loaded === "true") {
        resolve();
        return;
      }

      existingScript.addEventListener("load", () => resolve(), { once: true });
      existingScript.addEventListener("error", () => reject(new Error(`Unable to load ${source}`)), { once: true });
      return;
    }

    const script = document.createElement("script");
    script.src = source;
    script.async = false;
    script.addEventListener(
      "load",
      () => {
        script.dataset.loaded = "true";
        resolve();
      },
      { once: true },
    );
    script.addEventListener("error", () => reject(new Error(`Unable to load ${source}`)), { once: true });
    document.body.appendChild(script);
  });
}

export function RegistrationEmbedScript() {
  useEffect(() => {
    let overlayObserver: MutationObserver | undefined;
    let syncTimer: number | undefined;
    let autoOpenTimer: number | undefined;
    let isMounted = true;

    const syncOverlayState = () => {
      const overlay = document.getElementById(OVERLAY_ID);
      const isOpen = Boolean(overlay && !overlay.classList.contains("hidden"));
      document.body.classList.toggle(OVERLAY_OPEN_CLASS, isOpen);
    };

    const watchOverlay = () => {
      const overlay = document.getElementById(OVERLAY_ID);
      if (!overlay || overlayObserver) {
        syncOverlayState();
        return;
      }

      overlayObserver = new MutationObserver(syncOverlayState);
      overlayObserver.observe(overlay, { attributes: true, attributeFilter: ["class"] });
      syncOverlayState();
    };

    const scheduleOverlaySync = () => {
      window.clearTimeout(syncTimer);
      syncTimer = window.setTimeout(watchOverlay, 0);
    };

    const openRegistration = () => {
      const button = document.querySelector<HTMLButtonElement>("[data-action-id='reg-button']");
      const overlay = document.getElementById(OVERLAY_ID);
      const iframe = overlay?.querySelector<HTMLIFrameElement>("#childIframe");
      if (!button || !overlay || !iframe || !overlay.classList.contains("hidden")) return;

      iframe.src = button.dataset.url ?? REGISTRATION_URL;
      overlay.classList.remove("hidden");
      button.classList.add("hidden");
      syncOverlayState();
    };

    const closeRegistration = () => {
      const overlay = document.getElementById(OVERLAY_ID);
      const iframe = overlay?.querySelector<HTMLIFrameElement>("#childIframe");

      overlay?.classList.add("hidden");
      if (iframe) iframe.src = "";
      syncOverlayState();
    };

    const bodyObserver = new MutationObserver(watchOverlay);
    bodyObserver.observe(document.body, { childList: true });
    const registrationButtons = document.querySelectorAll<HTMLButtonElement>("[data-action-id='reg-button']");
    const handleRegistrationClick = () => {
      openRegistration();
      scheduleOverlaySync();
    };
    registrationButtons.forEach((button) => button.addEventListener("click", handleRegistrationClick));

    void (async () => {
      try {
        await loadExternalScript(REGISTRATION_PREVIEW_SCRIPT);
        await loadExternalScript(REGISTRATION_IFRAME_SCRIPT);
        if (!isMounted) return;
        watchOverlay();
        autoOpenTimer = window.setTimeout(openRegistration, 0);
      } catch {
        // The page keeps a direct Dreamcast fallback link if either provider script is unavailable.
      }
    })();

    return () => {
      isMounted = false;
      window.clearTimeout(syncTimer);
      window.clearTimeout(autoOpenTimer);
      closeRegistration();
      bodyObserver.disconnect();
      overlayObserver?.disconnect();
      registrationButtons.forEach((button) => button.removeEventListener("click", handleRegistrationClick));
      document.body.classList.remove(OVERLAY_OPEN_CLASS);
    };
  }, []);

  return <style>{registrationOverlayStyles}</style>;
}
