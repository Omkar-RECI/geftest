import { Link } from "@tanstack/react-router";
import { ChevronUp, Facebook, Instagram, Linkedin, Mail, MapPin, Phone, Youtube } from "lucide-react";
import { useEffect, useState } from "react";
import logo from "../../assets/gef/GEF-H-Logo.svg";
import {
  ORGANIZATION_ADDRESS_TEXT,
  ORGANIZATION_EMAIL,
  ORGANIZATION_PHONE,
  SOCIAL_PROFILES,
} from "../../lib/seo";

const SOCIAL_LINKS = [
  {
    label: "LinkedIn",
    href: SOCIAL_PROFILES.linkedin,
    Icon: Linkedin,
    bg: "#0A66C2",
  },
  {
    label: "Instagram",
    href: SOCIAL_PROFILES.instagram,
    Icon: Instagram,
    bg: "#E1306C",
  },
  {
    label: "YouTube",
    href: SOCIAL_PROFILES.youtube,
    Icon: Youtube,
    bg: "#FF0000",
  },
  {
    label: "Facebook",
    href: SOCIAL_PROFILES.facebook,
    Icon: Facebook,
    bg: "#1877F2",
  },
] as const;

export function Footer() {
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 320);
    };

    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <footer className="border-t border-[color:var(--hairline)] bg-[linear-gradient(180deg,#fff_0%,#fbf8f1_100%)]">
        <div className="h-px w-full bg-gradient-to-r from-transparent via-[color:var(--gold)] to-transparent" />

        <div className="gef-container py-4 md:py-5">
          <div className="rounded-[22px] border border-[color:var(--hairline)] bg-white px-4 py-4 shadow-[0_18px_44px_-38px_rgba(5,43,87,0.22)] md:px-6 md:py-5">
            <div className="grid gap-4 md:grid-cols-[minmax(0,1.05fr)_auto_minmax(250px,0.9fr)] md:items-center md:gap-6">
              <div className="min-w-0">
                <div className="flex flex-wrap items-end gap-x-5 gap-y-3">
                  <div>
                    <img src={logo} alt="GEF" className="h-16 w-auto md:h-[4.5rem]" width={210} height={64} />
                  </div>
                  <div className="border-l border-[color:var(--hairline)] pl-4 md:pl-5">
                    <div className="mb-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--navy)]">
                      Presenting Partner
                    </div>
                    <img
                      src="/Assets/Associated-Logos/PCU.svg"
                      alt="Pimpri Chinchwad University (PCU)"
                      className="h-16 w-auto object-contain md:h-[4.5rem]"
                      loading="lazy"
                    />
                  </div>
                </div>
              </div>

              <div className="md:justify-self-center">
                <div className="text-[11px] font-semibold uppercase tracking-[0.2em] text-[color:var(--navy)] md:text-center">
                  Connect With Us
                </div>
                <div className="mt-2 flex flex-wrap items-center gap-2.5 md:justify-center">
                  {SOCIAL_LINKS.map(({ label, href, Icon, bg }) => (
                    href ? (
                      <a
                        key={label}
                        href={href}
                        target="_blank"
                        rel="noopener noreferrer"
                        aria-label={label}
                        style={{ backgroundColor: bg }}
                        className="grid h-9 w-9 place-items-center rounded-full text-white shadow-sm transition-all hover:-translate-y-0.5 hover:scale-[1.03] hover:shadow-md"
                      >
                        <Icon className="h-[17px] w-[17px]" strokeWidth={2} />
                      </a>
                    ) : (
                      <span
                        key={label}
                        aria-hidden="true"
                        style={{ backgroundColor: bg }}
                        className="grid h-9 w-9 place-items-center rounded-full text-white/80 shadow-sm opacity-55"
                      >
                        <Icon className="h-[17px] w-[17px]" strokeWidth={2} />
                      </span>
                    )
                  ))}
                </div>
              </div>

              <div className="rounded-[18px] border border-[color:var(--hairline)] bg-[color:var(--off-white)] px-4 py-3">
                <div className="text-[11px] font-semibold uppercase tracking-[0.2em] text-[color:var(--navy)]">
                  Contact
                </div>
                <ul className="mt-2.5 space-y-2 text-sm text-[color:var(--ink-soft)]">
                  <li className="flex items-start gap-2">
                    <Mail className="mt-0.5 h-4 w-4 shrink-0 text-[color:var(--gold-dark)]" />
                    <span>{ORGANIZATION_EMAIL}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Phone className="mt-0.5 h-4 w-4 shrink-0 text-[color:var(--gold-dark)]" />
                    <span>{ORGANIZATION_PHONE}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[color:var(--gold-dark)]" />
                    <span>{ORGANIZATION_ADDRESS_TEXT}</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="mt-4 flex flex-col gap-2 border-t border-[color:var(--hairline)] pt-3 text-xs text-[color:var(--ink-muted)] md:flex-row md:items-center md:justify-between">
              <p>(c) {new Date().getFullYear()} Global Entrepreneurs Forum. All rights reserved.</p>
              <div className="flex flex-wrap gap-x-5 gap-y-2">
                <Link to="/privacy-policy" className="transition-colors hover:text-[color:var(--navy)]">Privacy Policy</Link>
                <Link to="/terms-of-use" className="transition-colors hover:text-[color:var(--navy)]">Terms of Use</Link>
                <Link to="/payment-refund-policy" className="transition-colors hover:text-[color:var(--navy)]">Payment & Refund Policy</Link>
              </div>
            </div>
          </div>
        </div>
      </footer>

      <button
        type="button"
        aria-label="Back to top"
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        className={`fixed right-4 z-40 grid h-11 w-11 place-items-center rounded-full border border-[color:var(--hairline)] bg-[color:var(--navy)] text-white shadow-[0_16px_32px_-18px_rgba(5,43,87,0.55)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-[color:var(--navy-deep)] sm:right-6 ${showBackToTop ? "pointer-events-auto bottom-20 opacity-100" : "pointer-events-none bottom-16 opacity-0"}`}
      >
        <ChevronUp className="h-5 w-5" strokeWidth={2.1} />
      </button>
    </>
  );
}
