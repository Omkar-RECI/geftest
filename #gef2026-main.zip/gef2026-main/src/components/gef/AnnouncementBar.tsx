import { X } from "lucide-react";
import { useEffect, useState } from "react";

const STORAGE_KEY = "gef-announcement-dismissed";
const MESSAGE = "Thank you for the incredible response. Stay tuned - the next Global Entrepreneur Forum chapter is on its way.";
const SHOW_ANNOUNCEMENT_BAR = false;

export function AnnouncementBar() {
  const [dismissed, setDismissed] = useState(true);

  useEffect(() => {
    try {
      setDismissed(window.localStorage.getItem(STORAGE_KEY) === "true");
    } catch {
      setDismissed(false);
    }
  }, []);

  if (!SHOW_ANNOUNCEMENT_BAR || dismissed) return null;

  const closeBar = () => {
    try {
      window.localStorage.setItem(STORAGE_KEY, "true");
    } catch {
      // Ignore storage failures and still close for this session.
    }
    setDismissed(true);
  };

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 border-t border-[color:var(--gold)]/40 bg-[color:var(--navy-deep)] text-white shadow-[0_-10px_30px_-18px_rgba(3,26,53,0.45)]">
      <div className="relative flex h-11 items-center overflow-hidden pr-12">
        <div className="gef-announcement-marquee whitespace-nowrap text-[11px] font-medium uppercase tracking-[0.18em] text-white/90 sm:text-xs">
          <span className="mx-6">{MESSAGE}</span>
          <span className="mx-6" aria-hidden="true">{MESSAGE}</span>
          <span className="mx-6" aria-hidden="true">{MESSAGE}</span>
        </div>
        <button
          type="button"
          onClick={closeBar}
          aria-label="Close announcement bar"
          className="absolute right-2 top-1/2 grid h-8 w-8 -translate-y-1/2 place-items-center rounded-full border border-white/15 bg-white/8 text-white/80 transition-colors hover:bg-white/14 hover:text-white"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
