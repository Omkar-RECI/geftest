import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { ChevronDown, Menu, X } from "lucide-react";
import logo from "../../assets/gef/GEF-H-Logo.svg";

const baseLinks = [
  { to: "/", label: "Home" },
  { to: "/about-gef", label: "About GEF" },
];

const eventLinks = [
  { to: "/upcoming-events", label: "Upcoming Events" },
  { to: "/past-editions", label: "Past Editions" },
];

const tailLinks = [
  { to: "/partners-sponsors", label: "Partners" },
  { to: "/speakers", label: "Speakers" },
  { to: "/media", label: "Media" },
];

export function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [visible, setVisible] = useState(true);
  const [eventsOpen, setEventsOpen] = useState(false);

  useEffect(() => {
    document.documentElement.style.setProperty("--gef-header-offset", visible ? "5rem" : "0px");
    window.dispatchEvent(new CustomEvent<boolean>("gef:header-visibility", { detail: visible }));
  }, [visible]);

  useEffect(() => {
    let previousScrollY = window.scrollY;

    const onScroll = () => {
      const currentScrollY = window.scrollY;
      setScrolled(currentScrollY > 8);

      if (currentScrollY < 16 || currentScrollY < previousScrollY) {
        setVisible(true);
      } else if (currentScrollY > previousScrollY) {
        setVisible(false);
      }

      previousScrollY = currentScrollY;
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      document.documentElement.style.removeProperty("--gef-header-offset");
    };
  }, []);

  useEffect(() => {
    if (!open) return;

    // Keep the navigation accessible and stop the page beneath the menu from scrolling.
    setVisible(true);
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [open]);

  return (
    <header
      className={`sticky top-0 z-50 w-full bg-white transition-[transform,box-shadow] duration-300 ease-out ${
        visible ? "translate-y-0" : "-translate-y-full"
      } ${
        scrolled
          ? "shadow-[0_1px_0_rgba(5,43,87,0.06),0_8px_24px_-12px_rgba(5,43,87,0.12)]"
          : "border-b border-[color:var(--hairline)]"
      }`}
    >
      <div className="gef-container flex h-20 items-center justify-between gap-5">
        <Link to="/" className="flex shrink-0 items-center gap-3" aria-label="GEF home">
          <img
            src={logo}
            alt="GEF - Global Entrepreneur Forum"
            className="h-14 w-auto"
            width={150}
            height={48}
          />
        </Link>

        <nav className="hidden items-center gap-4 lg:flex xl:gap-6">
          {baseLinks.map((l) => (
            <Link
              key={l.to + l.label}
              to={l.to}
              activeOptions={{ exact: l.to === "/" }}
              className="relative text-[14px] font-medium text-[color:var(--navy)] transition-colors hover:text-[color:var(--gold-dark)]"
              activeProps={{
                className:
                  "text-[color:var(--gold-dark)] after:absolute after:-bottom-2 after:left-0 after:h-0.5 after:w-full after:rounded-full after:bg-[color:var(--gold)]",
              }}
            >
              {l.label}
            </Link>
          ))}
          <div
            className="relative"
            onMouseEnter={() => setEventsOpen(true)}
            onMouseLeave={() => setEventsOpen(false)}
          >
            <button
              type="button"
              aria-expanded={eventsOpen}
              aria-haspopup="menu"
              onClick={() => setEventsOpen((isOpen) => !isOpen)}
              className="flex items-center gap-1 text-[14px] font-medium text-[color:var(--navy)] transition-colors hover:text-[color:var(--gold-dark)]"
            >
              Events
              <ChevronDown className={`h-4 w-4 transition-transform ${eventsOpen ? "rotate-180" : ""}`} />
            </button>
            <div
              className={`absolute left-1/2 top-[calc(100%+1rem)] w-52 -translate-x-1/2 rounded-2xl border border-[color:var(--hairline)] bg-white p-2 shadow-[0_18px_40px_-20px_rgba(5,43,87,0.26)] transition-all duration-200 ${
                eventsOpen ? "visible translate-y-0 opacity-100" : "invisible -translate-y-1 opacity-0"
              }`}
              role="menu"
            >
              {eventLinks.map((eventLink) => (
                <Link
                  key={eventLink.to}
                  to={eventLink.to}
                  onClick={() => setEventsOpen(false)}
                  className="block rounded-xl px-4 py-3 text-sm font-medium text-[color:var(--navy)] transition-colors hover:bg-[color:var(--gold-soft)] hover:text-[color:var(--gold-dark)]"
                  role="menuitem"
                >
                  {eventLink.label}
                </Link>
              ))}
            </div>
          </div>
          {tailLinks.map((l) => (
            <Link
              key={l.to + l.label}
              to={l.to}
              activeOptions={{ exact: l.to === "/" }}
              className="relative text-[14px] font-medium text-[color:var(--navy)] transition-colors hover:text-[color:var(--gold-dark)]"
              activeProps={{
                className:
                  "text-[color:var(--gold-dark)] after:absolute after:-bottom-2 after:left-0 after:h-0.5 after:w-full after:rounded-full after:bg-[color:var(--gold)]",
              }}
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="hidden shrink-0 items-center lg:flex">
          <Link
            to="/register"
            data-gef-register-link
            className="inline-flex items-center justify-center rounded-full border border-[#b67d16] bg-[linear-gradient(135deg,#f7dc86_0%,#d6a536_52%,#b77c16_100%)] px-4 py-2.5 text-[13px] font-bold text-[color:var(--navy-deep)] shadow-[0_12px_24px_-14px_rgba(151,98,10,0.8)] transition-all hover:-translate-y-0.5 hover:brightness-105 hover:shadow-[0_16px_30px_-14px_rgba(151,98,10,0.9)] xl:px-5 xl:py-3 xl:text-sm"
          >
            Register Now
          </Link>
        </div>
        <button
          aria-label="Open menu"
          onClick={() => setOpen(true)}
          className="grid h-11 w-11 place-items-center rounded-full border border-[color:var(--hairline)] lg:hidden"
        >
          <Menu className="h-5 w-5 text-[color:var(--navy)]" />
        </button>
      </div>

      {open &&
        createPortal(
        <div className="fixed inset-0 z-[100] flex min-h-[100dvh] flex-col bg-white lg:hidden" role="dialog" aria-modal="true" aria-label="Site navigation">
          <div className="flex h-20 shrink-0 items-center justify-between border-b border-[color:var(--hairline)] bg-white px-5">
            <Link to="/" onClick={() => setOpen(false)} className="flex items-center gap-3">
              <img src={logo} alt="GEF" className="h-14 w-auto" width={176} height={56} />
            </Link>
            <button
              aria-label="Close menu"
              onClick={() => {
                setEventsOpen(false);
                setOpen(false);
              }}
              className="grid h-11 w-11 place-items-center rounded-full border border-[color:var(--hairline)]"
            >
              <X className="h-5 w-5 text-[color:var(--navy)]" />
            </button>
          </div>
          <nav className="flex flex-1 flex-col gap-1 overflow-y-auto px-5 pb-[calc(env(safe-area-inset-bottom)+1.5rem)] pt-4">
            {baseLinks.map((l) => (
              <Link
                key={l.to + l.label}
                to={l.to}
                activeOptions={{ exact: l.to === "/" }}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-4 text-lg font-medium text-[color:var(--navy)] hover:bg-[color:var(--off-white)]"
                activeProps={{ className: "bg-[color:var(--gold-soft)] text-[color:var(--gold-dark)]" }}
              >
                {l.label}
              </Link>
            ))}
            <div className="rounded-xl border border-[color:var(--hairline)] bg-[color:var(--off-white)] p-1">
              <button
                type="button"
                aria-expanded={eventsOpen}
                onClick={() => setEventsOpen((isOpen) => !isOpen)}
                className="flex w-full items-center justify-between rounded-lg px-3 py-4 text-left text-lg font-medium text-[color:var(--navy)]"
              >
                Events
                <ChevronDown className={`h-5 w-5 transition-transform ${eventsOpen ? "rotate-180" : ""}`} />
              </button>
              {eventsOpen ? (
                <div className="border-t border-[color:var(--hairline)] px-2 py-1">
                  {eventLinks.map((eventLink) => (
                    <Link
                      key={eventLink.to}
                      to={eventLink.to}
                      onClick={() => {
                        setEventsOpen(false);
                        setOpen(false);
                      }}
                      className="block rounded-lg px-3 py-3 text-base font-medium text-[color:var(--ink-soft)] hover:bg-white hover:text-[color:var(--gold-dark)]"
                    >
                      {eventLink.label}
                    </Link>
                  ))}
                </div>
              ) : null}
            </div>
            {tailLinks.map((l) => (
              <Link
                key={l.to + l.label}
                to={l.to}
                activeOptions={{ exact: l.to === "/" }}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-4 text-lg font-medium text-[color:var(--navy)] hover:bg-[color:var(--off-white)]"
                activeProps={{ className: "bg-[color:var(--gold-soft)] text-[color:var(--gold-dark)]" }}
              >
                {l.label}
              </Link>
            ))}
            <Link
              to="/register"
              onClick={() => setOpen(false)}
              className="mt-4 inline-flex items-center justify-center rounded-full border border-[#b67d16] bg-[linear-gradient(135deg,#f7dc86_0%,#d6a536_52%,#b77c16_100%)] px-5 py-3.5 text-base font-bold text-[color:var(--navy-deep)] shadow-[0_12px_24px_-14px_rgba(151,98,10,0.8)]"
            >
              Register Now
            </Link>
          </nav>
        </div>,
        document.body,
      )}
    </header>
  );
}
