import { Crown } from "lucide-react";

type PlatinumPassVisualCardProps = {
  className?: string;
};

export function PlatinumPassVisualCard({ className = "" }: PlatinumPassVisualCardProps) {
  return (
    <div className={`relative w-full [perspective:1200px] ${className}`}>
      <div className="relative aspect-[1.58/1] rotate-[-3deg] overflow-hidden rounded-[26px] border border-white/30 bg-[linear-gradient(135deg,#082957_0%,#0e4f91_56%,#061b3c_100%)] p-6 text-white shadow-[0_30px_60px_-25px_rgba(0,0,0,0.65)] transition-transform duration-500 hover:rotate-0 md:p-7">
        <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full border border-white/20" />
        <div aria-hidden="true" className="absolute right-[12%] top-[19%] h-[46%] aspect-square rounded-full border border-white/15 opacity-60">
          <div className="absolute inset-y-0 left-1/2 w-[42%] -translate-x-1/2 rounded-[50%] border-x border-white/15" />
          <div className="absolute inset-x-0 top-1/2 h-[42%] -translate-y-1/2 rounded-[50%] border-y border-white/15" />
          <div className="absolute inset-x-0 top-1/2 h-px -translate-y-1/2 bg-white/15" />
          <div className="absolute inset-y-0 left-1/2 w-px -translate-x-1/2 bg-white/15" />
        </div>
        <div className="absolute bottom-0 left-0 h-[18%] w-full bg-[linear-gradient(165deg,#f6f7f4_0%,#c8ced2_45%,#ffffff_100%)]" />
        <div className="absolute bottom-[18%] left-0 h-px w-full bg-white/60" />
        <div className="relative flex items-start justify-between">
          <div className="text-[9px] font-bold uppercase leading-[1.15] tracking-[0.2em] text-white/95">Global Entrepreneurs<br />Forum<br />Pune 2027</div>
          <Crown className="h-6 w-6 text-[color:var(--gold-light)]" />
        </div>
        <div className="relative mt-[16%]">
          <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-white/65">Curated access</p>
          <p className="mt-1 text-[clamp(1.6rem,4vw,2.65rem)] font-normal leading-none tracking-[-0.04em] text-white" style={{ fontFamily: "var(--font-display)" }}>PLATINUM</p>
          <p className="mt-1 text-sm font-semibold uppercase tracking-[0.24em] text-white">Pass</p>
        </div>
        <div className="absolute bottom-2.5 left-6 right-6 flex items-center justify-between text-[9px] font-bold uppercase tracking-[0.14em] text-[color:var(--navy-deep)] md:left-7 md:right-7"><span>Limited allocation</span><span>GEF / 27</span></div>
      </div>
    </div>
  );
}
