import type { SpeakerProfile } from "../../content/speakers";

type SpeakerProfileCardProps = {
  speaker: SpeakerProfile;
  isFirstRowCard?: boolean;
};

export function SpeakerProfileCard({
  speaker,
  isFirstRowCard = false,
}: SpeakerProfileCardProps) {
  const metaLines = [speaker.designation, speaker.organization, speaker.country].filter(
    (line): line is string => Boolean(line && line.trim()),
  );

  return (
    <article className="mx-auto flex h-full w-full max-w-[16rem] flex-col overflow-hidden rounded-[22px] border border-[color:var(--hairline)] bg-white text-center shadow-[0_18px_44px_-28px_rgba(5,43,87,0.18)] transition-transform duration-300 hover:-translate-y-1">
      <div className="aspect-[43/50] overflow-hidden bg-white">
        <img
          src={speaker.photo}
          alt={speaker.name}
          loading="lazy"
          className="h-full w-full object-contain object-center"
          width={258}
          height={300}
        />
      </div>
      <div className="flex flex-1 flex-col border-t border-[color:var(--hairline)] px-4 py-4 md:px-5">
        <h3
          className={`${isFirstRowCard ? "min-h-[3.3rem]" : "min-h-[1.65rem]"} text-lg font-semibold leading-snug text-[color:var(--navy)]`}
          style={{
            fontFamily: "var(--font-display)",
            display: "-webkit-box",
            WebkitLineClamp: isFirstRowCard ? 2 : 1,
            WebkitBoxOrient: "vertical",
            overflow: "hidden",
          }}
        >
          {speaker.name}
        </h3>
        <div className="mt-2 space-y-0.5 text-sm leading-relaxed text-[color:var(--ink-soft)]">
          {metaLines.map((line, index) => (
            <p
              key={`${speaker.name}-${line}-${index}`}
              className={`min-h-[1.35rem] ${
                index === 0
                  ? "font-medium text-[color:var(--gold-dark)]"
                  : index === metaLines.length - 1 && speaker.country === line
                    ? "uppercase tracking-[0.08em] text-[color:var(--ink-muted)]"
                    : ""
              }`}
            >
              {line}
            </p>
          ))}
        </div>
      </div>
    </article>
  );
}
