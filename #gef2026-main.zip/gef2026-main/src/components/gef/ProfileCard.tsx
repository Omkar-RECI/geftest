type ProfileCardProps = {
  name: string;
  photo: string;
  bio?: string;
  role?: string;
  org?: string;
  metaLines?: string[];
  className?: string;
  compactName?: boolean;
};

export function ProfileCard({
  name,
  photo,
  bio,
  role,
  org,
  metaLines,
  className = "",
  compactName = false,
}: ProfileCardProps) {
  return (
    <article
      className={`group mx-auto flex h-full w-full max-w-[16rem] flex-col overflow-hidden rounded-2xl border border-[color:var(--hairline)] bg-white text-center transition-all hover:-translate-y-1 hover:border-[color:var(--gold)] hover:shadow-[0_18px_44px_-22px_rgba(5,43,87,0.18)] ${className}`}
    >
      <div className="aspect-[43/50] overflow-hidden border-b border-[color:var(--hairline)] bg-white">
        <img
          src={photo}
          alt={name}
          loading="lazy"
          className="h-full w-full object-contain object-center transition-transform duration-700 group-hover:scale-[1.01]"
        />
      </div>
      <div className="flex flex-1 flex-col items-center p-4">
        <h3
          className={`${compactName ? "min-h-[1.65rem]" : "min-h-[3.3rem]"} text-lg font-semibold leading-snug text-[color:var(--navy)]`}
          style={{ fontFamily: "var(--font-display)" }}
        >
          {name}
        </h3>
        {metaLines?.length ? (
          <div className="mt-2 space-y-0.5 text-sm leading-relaxed text-[color:var(--ink-soft)]">
            {metaLines.map((line, index) => (
              <p
                key={`${name}-${line}-${index}`}
                className={`min-h-[1.35rem] ${
                  index === 0
                    ? "font-medium text-[color:var(--gold-dark)]"
                    : index === metaLines.length - 1 && /^[A-Z]{2,3}$/.test(line)
                      ? "uppercase tracking-[0.08em] text-[color:var(--ink-muted)]"
                      : ""
                }`}
              >
                {line}
              </p>
            ))}
          </div>
        ) : (
          <>
            {role ? (
          <div
            className="mt-1 min-h-[3.9rem] text-sm font-medium leading-relaxed text-[color:var(--gold-dark)]"
            style={{
              display: "-webkit-box",
              WebkitLineClamp: 3,
              WebkitBoxOrient: "vertical",
              overflow: "hidden",
            }}
          >
            {role}
          </div>
            ) : null}
            {org ? (
              <div className="text-xs uppercase tracking-[0.14em] text-[color:var(--ink-muted)]">{org}</div>
            ) : null}
            {bio ? (
              <p
          className="mt-4 min-h-[4.2rem] text-sm leading-relaxed text-[color:var(--ink-soft)]"
          style={{
            display: "-webkit-box",
            WebkitLineClamp: 3,
            WebkitBoxOrient: "vertical",
            overflow: "hidden",
          }}
          >
            {bio}
              </p>
            ) : null}
          </>
        )}
      </div>
    </article>
  );
}
