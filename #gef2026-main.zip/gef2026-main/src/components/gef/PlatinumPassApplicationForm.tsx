import emailjs from "@emailjs/browser";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { SectionHeading } from "./CTA";

const MAX_ABOUT_WORDS = 500;

function countWords(value: string) {
  const trimmed = value.trim();
  return trimmed ? trimmed.split(/\s+/).length : 0;
}

export function PlatinumPassApplicationForm() {
  const [sent, setSent] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [captchaToken, setCaptchaToken] = useState<string | null>(null);
  const [ReCAPTCHAComponent, setReCAPTCHAComponent] = useState<any>(null);
  const [about, setAbout] = useState("");
  const recaptchaRef = useRef<any>(null);
  const recaptchaSiteKey = import.meta.env.VITE_RECAPTCHA_SITE_KEY;

  useEffect(() => {
    let mounted = true;

    import("react-google-recaptcha")
      .then((module) => {
        const importedModule = module as any;
        const Component = importedModule?.default?.default ?? importedModule?.default ?? importedModule;

        if (mounted) setReCAPTCHAComponent(() => Component);
      })
      .catch((error) => {
        console.error("Failed to load Google reCAPTCHA.", error);
        if (mounted) setErrorMessage("reCAPTCHA could not load. Please refresh the page and try again.");
      });

    return () => {
      mounted = false;
    };
  }, []);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (countWords(about) > MAX_ABOUT_WORDS) {
      setErrorMessage("Please keep About yourself to 500 words or fewer.");
      return;
    }

    if (!captchaToken) {
      setErrorMessage("Please verify that you are not a robot.");
      return;
    }

    if (isSending) return;

    const serviceId = import.meta.env.VITE_EMAILJS_SERVICE_ID;
    const templateId = import.meta.env.VITE_EMAILJS_PARTNERSHIP_TEMPLATE_ID;
    const publicKey = import.meta.env.VITE_EMAILJS_PUBLIC_KEY;

    if (!serviceId || !templateId || !publicKey) {
      console.error("EmailJS configuration is missing for the Platinum Pass application form.");
      setErrorMessage("We could not submit your application right now. Please try again.");
      return;
    }

    setIsSending(true);
    setErrorMessage("");
    const formData = new FormData(event.currentTarget);
    const templateParams = {
      name: String(formData.get("name") || "").trim(),
      organization: String(formData.get("organization") || "").trim(),
      company_website: String(formData.get("company_website") || "").trim(),
      designation: String(formData.get("designation") || "").trim(),
      email: String(formData.get("email") || "").trim(),
      phone: String(formData.get("phone") || "").trim(),
      message: about.trim(),
      partnership_interest: "Platinum Pass Application",
      partnership_interest_subject: "Platinum Pass Application",
      application_type: "GEF Platinum Pass",
      "g-recaptcha-response": captchaToken,
    };

    try {
      await emailjs.send(serviceId, templateId, templateParams, {
        publicKey,
        blockHeadless: true,
        limitRate: { id: "gef-partnership-inquiry", throttle: 10_000 },
      });
      setSent(true);
      setCaptchaToken(null);
      recaptchaRef.current?.reset();
    } catch (error) {
      console.error("EmailJS Platinum Pass application submission failed.", error);
      setErrorMessage("We could not submit your application right now. Please try again.");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <section id="platinum-pass-application" className="gef-section scroll-mt-24 !pt-2 !pb-14 md:!pt-4 md:!pb-20">
      <div className="gef-container max-w-3xl">
        <SectionHeading
          eyebrow="Applications Open"
          title="Apply for the GEF Platinum Pass."
          subtitle="Complete the application below. The GEF team will review each submission and share the next steps with selected applicants."
          align="center"
        />

        {sent ? (
          <div className="mt-8 rounded-2xl border border-[color:var(--gold)] bg-[color:var(--gold-soft)] p-8 text-center">
            <h3 className="text-2xl text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>
              Application received.
            </h3>
            <p className="mt-2 text-[color:var(--ink-soft)]">
              Thank you. The GEF team will review your Platinum Pass application and contact you with the next steps.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-8 grid gap-5 rounded-[28px] border border-[color:var(--hairline)] bg-white p-6 shadow-[0_22px_60px_-40px_rgba(5,43,87,0.2)] md:p-8">
            <div className="grid gap-5 md:grid-cols-2">
              <Field label="Name" required>
                <input name="name" className="gef-input" required maxLength={100} autoComplete="name" />
              </Field>
              <Field label="Organization / Company" required>
                <input name="organization" className="gef-input" required maxLength={120} autoComplete="organization" />
              </Field>
              <Field label="Company website">
                <input name="company_website" type="url" className="gef-input" maxLength={200} placeholder="https://" autoComplete="url" />
              </Field>
              <Field label="Designation" required>
                <input name="designation" className="gef-input" required maxLength={100} autoComplete="organization-title" />
              </Field>
              <Field label="Email" required>
                <input name="email" type="email" className="gef-input" required maxLength={150} autoComplete="email" />
              </Field>
              <Field label="Phone" required>
                <input name="phone" type="tel" className="gef-input" required maxLength={30} autoComplete="tel" />
              </Field>
            </div>

            <Field label="About yourself" required>
              <textarea
                name="message"
                className="gef-input min-h-36"
                required
                value={about}
                onChange={(event) => {
                  setAbout(event.target.value);
                  if (errorMessage) setErrorMessage("");
                }}
              />
              <p className={`mt-2 text-right text-xs ${countWords(about) > MAX_ABOUT_WORDS ? "text-red-700" : "text-[color:var(--ink-muted)]"}`}>
                {countWords(about)} / {MAX_ABOUT_WORDS} words
              </p>
            </Field>

            <p className="text-xs leading-5 text-[color:var(--ink-muted)]">
              Your information will only be used to review your Platinum Pass application and respond to you.
            </p>

            {recaptchaSiteKey && ReCAPTCHAComponent ? (
              <div className="overflow-x-auto">
                <ReCAPTCHAComponent
                  ref={recaptchaRef}
                  sitekey={recaptchaSiteKey}
                  onChange={(token: string | null) => {
                    setCaptchaToken(token);
                    setErrorMessage("");
                  }}
                  onExpired={() => setCaptchaToken(null)}
                  onErrored={() => {
                    setCaptchaToken(null);
                    setErrorMessage("reCAPTCHA could not load. Please try again.");
                  }}
                />
              </div>
            ) : recaptchaSiteKey ? (
              <p className="text-sm text-[color:var(--ink-muted)]">Loading verification...</p>
            ) : (
              <p className="text-sm text-red-700">reCAPTCHA configuration is unavailable.</p>
            )}

            {errorMessage ? <p className="text-sm text-red-700">{errorMessage}</p> : null}

            <button type="submit" className="gef-btn gef-btn-primary w-full md:w-auto" disabled={isSending || !captchaToken}>
              {isSending ? "Submitting application..." : "Submit application"}
            </button>
          </form>
        )}
      </div>
    </section>
  );
}

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium uppercase tracking-[0.12em] text-[color:var(--ink-muted)]">
        {label}
        {required ? " *" : ""}
      </span>
      {children}
    </label>
  );
}
