import { Link } from "@tanstack/react-router";

export function FinalCTA({
  className = "",
  primaryLabel = "Register Now",
  primaryDisabled = false,
}: {
  className?: string;
  primaryLabel?: string;
  primaryDisabled?: boolean;
}) {
  const heading = "Be part of the GEF Pune 2027.";
  const sub =
    "Join entrepreneurs, investors, institutions, and ecosystem leaders for two days of connections, capital, and market opportunity in Pune.";

  return (
    <section className={`gef-section ${className}`.trim()}>
      <div className="gef-container">
        <div
          className="relative overflow-hidden rounded-[28px] p-8 md:p-12"
          style={{ background: "var(--gradient-navy)" }}
        >
          <div
            className="pointer-events-none absolute inset-0 opacity-40"
            style={{
              background:
                "radial-gradient(60% 60% at 80% 0%, rgba(228,196,106,0.35), transparent 60%), radial-gradient(40% 40% at 0% 100%, rgba(228,196,106,0.18), transparent 60%)",
            }}
          />
          <div className="relative mx-auto max-w-3xl text-center">
            <span className="gef-eyebrow text-[color:var(--gold-light)]">GEF Pune 2027</span>
            <h2 className="mt-4 text-[clamp(2rem,4vw,3.25rem)] font-normal leading-[1.1] text-white">
              {heading}
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-base text-white/75 md:text-lg">{sub}</p>
            <div className="mt-7 flex flex-nowrap items-center justify-center gap-2 sm:gap-3">
              {primaryDisabled ? (
                <button type="button" disabled className="gef-btn gef-btn-primary !px-4 text-sm whitespace-nowrap opacity-65 sm:text-base">
                  {primaryLabel}
                </button>
              ) : (
                <Link to="/register" className="gef-btn gef-btn-primary !px-4 text-sm whitespace-nowrap sm:text-base">
                  {primaryLabel}
                </Link>
              )}
              <Link
                to="/GEFPune2027"
                onClick={() => window.scrollTo({ top: 0, behavior: "auto" })}
                className="gef-btn gef-btn-ghost !px-4 text-sm whitespace-nowrap sm:text-base"
              >
                Explore the Event
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function PageHero({
  eyebrow,
  title,
  subtitle,
  children,
  className = "",
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  children?: React.ReactNode;
  className?: string;
}) {
  return (
    <section
      className={`relative overflow-hidden bg-[color:var(--off-white)] pt-16 pb-10 md:pt-20 md:pb-14 ${className}`.trim()}
    >
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-px"
        style={{ background: "linear-gradient(90deg, transparent, var(--gold), transparent)" }}
      />
      <div
        className="pointer-events-none absolute -right-32 -top-32 h-[420px] w-[420px] rounded-full opacity-[0.07]"
        style={{ background: "var(--gradient-navy)" }}
      />
      <div className="gef-container relative">
        {eyebrow ? <span className="gef-eyebrow">{eyebrow}</span> : null}
        <h1 className="mt-4 max-w-3xl text-[clamp(2.25rem,5vw,4.25rem)] font-normal leading-[1.05] text-[color:var(--navy)]">
          {title}
        </h1>
        {subtitle ? (
          <p className="mt-5 max-w-2xl text-lg text-[color:var(--ink-soft)] md:text-xl">{subtitle}</p>
        ) : null}
        {children ? <div className="mt-8 flex flex-wrap gap-3">{children}</div> : null}
      </div>
    </section>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = "left",
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  align?: "left" | "center";
}) {
  return (
    <div className={align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}>
      {eyebrow ? <span className="gef-eyebrow">{eyebrow}</span> : null}
      <h2 className="mt-4 text-[clamp(1.75rem,3vw,2.75rem)] font-normal leading-[1.1]">{title}</h2>
      {subtitle ? <p className="mt-4 text-base text-[color:var(--ink-soft)] md:text-lg">{subtitle}</p> : null}
    </div>
  );
}
