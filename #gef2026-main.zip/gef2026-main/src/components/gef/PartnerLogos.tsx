import { PARTNER_GROUPS, type PartnerLogo } from "../../data/gef";
import logo from "../../assets/gef/GEF-H-Logo.svg";

export function PartnerLogoTile({ l, showName = true, compact = false }: { l: PartnerLogo; showName?: boolean; compact?: boolean }) {
  return (
    <a
      href={l.href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={l.name}
      className={`group flex items-center justify-center rounded-xl border border-[color:var(--hairline)] bg-white transition-all duration-300 hover:border-[color:var(--gold)] hover:shadow-[0_10px_28px_-14px_rgba(5,43,87,0.2)] ${
        compact ? "h-20 px-5 hover:scale-[1.04]" : "h-24 gap-3 px-4 hover:-translate-y-0.5"
      }`}
    >
      <img
        src={logo}
        alt=""
        aria-hidden="true"
        className={`w-auto transition-all duration-300 group-hover:opacity-100 ${
          compact
            ? showName
              ? "h-8 opacity-80 group-hover:h-9"
              : "h-9 opacity-80 group-hover:h-10"
            : showName
              ? "h-7 opacity-70"
              : "h-9 opacity-80 group-hover:h-10"
        }`}
      />
      {showName ? (
        <span className="text-sm font-medium text-[color:var(--navy)] transition-colors group-hover:text-[color:var(--gold-dark)]">
          {l.name}
        </span>
      ) : null}
    </a>
  );
}

export function PartnerLogos({ centered = true }: { centered?: boolean }) {
  return (
    <div className={`mt-10 space-y-10 ${centered ? "text-center" : ""}`}>
      {PARTNER_GROUPS.map((g) => (
        <div key={g.group}>
          <div className={`mb-4 text-xs uppercase tracking-[0.18em] text-[color:var(--ink-muted)] ${centered ? "text-center" : ""}`}>
            {g.group}
          </div>
          {(() => {
            const isOrganizedBy = g.group === "Organized By";
            const isLogoOnlyGroup =
              isOrganizedBy || g.group === "Ecosystem Partners" || g.group === "Community Partners";
            const isStandardLogoRow = g.group === "Ecosystem Partners" || g.group === "Community Partners";
            const gridClass = isOrganizedBy
              ? "mx-auto flex max-w-md flex-wrap items-center justify-center gap-4"
              : isStandardLogoRow
                ? "grid grid-cols-2 gap-3 sm:grid-cols-4 md:grid-cols-4"
              : `grid gap-3 sm:grid-cols-3 md:grid-cols-4 ${
                  g.logos.length <= 2 ? "mx-auto max-w-2xl grid-cols-2 sm:grid-cols-2 md:grid-cols-2" : "grid-cols-2"
                }`;

            return (
              <div className={gridClass}>
                {g.logos.map((l) => (
                  <div key={l.name} className={isOrganizedBy ? "w-[150px]" : ""}>
                    <PartnerLogoTile l={l} showName={!isLogoOnlyGroup} compact={isLogoOnlyGroup} />
                  </div>
                ))}
              </div>
            );
          })()}
        </div>
      ))}
    </div>
  );
}
