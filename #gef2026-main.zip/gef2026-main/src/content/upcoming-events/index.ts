export type UpcomingEventArchiveItem = {
  slug: string;
  name: string;
  year: string;
  date: string;
  city: string;
  venue: string;
  image: string;
  dateBadge: string;
  hasEventPage: boolean;
  summary: string;
};

export const UPCOMING_EVENTS_ARCHIVE: UpcomingEventArchiveItem[] = [
  {
    slug: "GEFPune2027",
    name: "GEF Pune 2027",
    year: "2027",
    date: "16 & 17 January 2027",
    city: "Pune, India",
    venue: "The Orchid Hotel, Balewadi",
    image: "/Assets/Events/GEF_Pune 2026/Pune2026-cover (1).webp",
    dateBadge: "JAN 2027",
    hasEventPage: true,
    summary:
      "From Rural Bharat to Global Markets: GEF Pune 2027 edition focused on connection, capital, market access, and the Viksit Bharat 2047 vision.",
  },
  {
    slug: "gef-phuket-april-2027",
    name: "GEF Phuket April 2027",
    year: "2027",
    date: "April 2027",
    city: "Phuket, Thailand",
    venue: "Venue to be announced",
    image: "/Assets/Events/GEF_Phuket_2027/phuket_COver_Event.webp",
    dateBadge: "APR 2027",
    hasEventPage: false,
    summary:
      "A future GEF edition is being planned for Phuket with cross-border networking, investment dialogue, and curated global ecosystem participation.",
  },
  {
    slug: "gef-dubai-sep-2027",
    name: "GEF Dubai Sep 2027",
    year: "2027",
    date: "September 2027",
    city: "Dubai, UAE",
    venue: "Venue to be announced",
    image: "https://images.unsplash.com/photo-1518684079-3c830dcef090?auto=format&fit=crop&w=1600&q=80",
    dateBadge: "SEP 2027",
    hasEventPage: false,
    summary:
      "Dubai returns as a future GEF destination, continuing the India-MENA entrepreneurship and business opportunity corridor with a new edition in development.",
  },
];
