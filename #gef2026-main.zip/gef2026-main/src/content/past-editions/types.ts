export type PastEditionYear = "2025" | "2026";

export type Stat = {
  value: string;
  label: string;
};

export type AgendaItem = {
  time: string;
  duration?: string;
  title: string;
  type: string;
  location?: string;
  speaker?: string;
  tracks?: string[];
};

export type AgendaDay = {
  day: string;
  items: AgendaItem[];
};

export type SimpleSpeaker = {
  name: string;
  role: string;
  org: string;
};

export type PersonCard = {
  name: string;
  role: string;
  org: string;
  bio: string;
  photo: string;
  metaLines?: string[];
};

export type SupportedByGroup = {
  group: string;
  items: string[];
};

export type MediaCoverageItem = {
  pub: string;
  headline: string;
  date: string;
};

export type GalleryPreviewItem = {
  src: string;
  alt: string;
};

export type MediaPreviewImage = {
  src: string;
  alt: string;
};

export type SupportedByLogo = {
  src: string;
  alt: string;
};

export type PastEditionArchiveItem = {
  slug: string;
  name: string;
  year: PastEditionYear;
  city: string;
  date: string;
  venue: string;
  image: string;
  summary: string;
};

export type PastEditionGenericContent = PastEditionArchiveItem & {
  template: "generic";
  stats: Stat[];
  speakers: SimpleSpeaker[];
  agenda: AgendaDay[];
};

export type PastEditionHighlightIconKey =
  | "globe2"
  | "briefcaseBusiness"
  | "mic2"
  | "star"
  | "users"
  | "building2";

export type PastEditionDetailedContent = PastEditionArchiveItem & {
  template: "detailed";
  comingSoonTabs?: Array<"Overview" | "Leadership" | "Speakers" | "Agenda" | "Supported By" | "Media">;
  heroEyebrow: string;
  heroDescription: string;
  impactStats: Stat[];
  about: {
    eyebrow: string;
    title: string;
    subtitle: string;
    body: string;
    featuredVideoUrl?: string;
  };
  highlights: {
    title: string;
    desc: string;
    icon: PastEditionHighlightIconKey;
  }[];
  overview: {
    eyebrow: string;
    title: string;
    paragraphs: string[];
    cards: {
      title: string;
      desc: string;
    }[];
  };
  leadershipCards: PersonCard[];
  speakerCards: SpeakerProfile[];
  agenda: AgendaDay[];
  supportedBy: SupportedByGroup[];
  supportedByLogos?: SupportedByLogo[];
  media: {
    pressCoverage: MediaCoverageItem[];
    featuredVideoUrl?: string;
    interviews: string[];
    galleryImages?: MediaPreviewImage[];
    pressImages?: MediaPreviewImage[];
  };
  galleryPreview: GalleryPreviewItem[];
  mediaCoveragePreview: MediaCoverageItem[];
  mediaCoverageVideos?: string[];
  showBottomPreviews?: boolean;
};

export type PastEditionContent = PastEditionGenericContent | PastEditionDetailedContent;
import type { SpeakerProfile } from "../speakers";
