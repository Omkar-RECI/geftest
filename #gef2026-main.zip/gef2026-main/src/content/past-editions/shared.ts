import { IMPACT_STATS } from "../../data/gef";
import { SPEAKER_PROFILES } from "../speakers";
import type { PersonCard, Stat } from "./types";

type ImpactStatLabel = (typeof IMPACT_STATS)[number]["label"];

const SHARED_LEADERSHIP_CARDS: PersonCard[] = [
  {
    name: "Sachin Itkar",
    role: "",
    org: "",
    bio: "Ecosystem Builder & Policy Strategist",
    photo: "/Assets/Leadership/Sachin_GEF1.jpg",
    metaLines: ["Ecosystem Builder & Policy Strategist"],
  },
  {
    name: "Sagar Babar",
    role: "",
    org: "",
    bio: "Entrepreneur | Technologist | Business Coach",
    photo: "/Assets/Leadership/Sagar_GEF1.jpg",
    metaLines: ["Entrepreneur | Technologist | Business Coach"],
  },
];

export function buildPastEditionImpactStats(
  valuesByLabel: Partial<Record<ImpactStatLabel, string>>,
): Stat[] {
  return IMPACT_STATS.map((item) => ({
    label: item.label,
    value: valuesByLabel[item.label] ?? item.value,
  }));
}

export function getSharedLeadershipCards(): PersonCard[] {
  return SHARED_LEADERSHIP_CARDS;
}

export function getPastEditionSpeakerCards(
  market: "pune" | "dubai",
): (typeof SPEAKER_PROFILES)[number][] {
  const filteredProfiles = SPEAKER_PROFILES.filter((profile) =>
    market === "dubai" ? profile.country === "UAE" : !profile.country,
  );

  return filteredProfiles;
}
