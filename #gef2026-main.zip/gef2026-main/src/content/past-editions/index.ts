import { GEC_DUBAI_2025_CONTENT } from "./gec-dubai-2025";
import { GEC_PUNE_2025_CONTENT } from "./gec-pune-2025";
import type { PastEditionArchiveItem, PastEditionContent } from "./types";

export type {
  AgendaDay,
  AgendaItem,
  GalleryPreviewItem,
  MediaCoverageItem,
  PastEditionArchiveItem,
  PastEditionContent,
  PastEditionDetailedContent,
  PastEditionGenericContent,
  PastEditionHighlightIconKey,
  PersonCard,
  SimpleSpeaker,
  Stat,
  SupportedByGroup,
} from "./types";

// This small registry is the only shared lookup point. Each event still owns
// its full content in its own file, which keeps future maintenance easier.
export const PAST_EDITIONS_CONTENT: PastEditionContent[] = [GEC_PUNE_2025_CONTENT, GEC_DUBAI_2025_CONTENT];

export const PAST_EDITIONS_ARCHIVE: PastEditionArchiveItem[] = PAST_EDITIONS_CONTENT.map((edition) => ({
  slug: edition.slug,
  name: edition.name,
  year: edition.year,
  city: edition.city,
  date: edition.date,
  venue: edition.venue,
  image: edition.image,
  summary: edition.summary,
}));

export function getPastEditionContent(slug: string) {
  return PAST_EDITIONS_CONTENT.find((edition) => edition.slug === slug);
}
