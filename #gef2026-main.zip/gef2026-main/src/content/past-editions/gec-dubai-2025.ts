import type { PastEditionDetailedContent } from "./types";
import {
  getPastEditionSpeakerCards,
  getSharedLeadershipCards,
} from "./shared";

// Keep Dubai 2025 content local to its own file so the event can be expanded
// later without mixing archive data into shared homepage or listing files.
export const GEC_DUBAI_2025_CONTENT: PastEditionDetailedContent = {
  template: "detailed",
  slug: "gec-dubai-2025",
  name: "GEC Dubai 2025",
  year: "2025",
  city: "Dubai, UAE",
  date: "16-18 August 2025",
  venue: "Hotel Conrad, Sheikh Zayed Road",
  image: "https://images.unsplash.com/photo-1518684079-3c830dcef090?auto=format&fit=crop&w=1600&q=80",
  summary:
    "A three-day Dubai edition connecting entrepreneurs, corporates, global speakers, and participating countries through expert sessions, networking, and curated field visits.",
  comingSoonTabs: [],
  heroEyebrow: "Past Edition",
  heroDescription:
    "Three power-packed days of expert insights, networking opportunities, and field visits connecting entrepreneurs, corporates, investors, and cross-border growth enablers in the MENA region.",
  impactStats: [
    { value: "500+", label: "Delegates" },
    { value: "200+", label: "Startups & Entrepreneurs" },
    { value: "100+", label: "Corporates" },
    { value: "40+", label: "Global Speakers" },
    { value: "20+", label: "Countries Participating" },
    { value: "3", label: "Days of Networking & Business Learning" },
  ],
  about: {
    eyebrow: "About The Event",
    title: "Three days of insight, access, and cross-border connection.",
    subtitle:
      "GEC Dubai 2025 brought entrepreneurs, global speakers, corporates, and participating countries together at Hotel Conrad, Dubai, alongside curated visits to the UAE's innovation and industrial hubs.",
    body:
      "The program combined in-house sessions on entrepreneurship, trade, technology, sustainability, and investment with networking lounges, B2B connections, and field visits that gave delegates a practical view of the UAE's business ecosystem.",
    featuredVideoUrl: "https://www.youtube.com/embed/L6F4ILfmfog?rel=0&playsinline=1",
  },
  highlights: [
    {
      title: "India-MENA Business Corridor",
      desc: "The edition emphasized practical cross-border dialogue between founders, capital, and market enablers.",
      icon: "globe2",
    },
    {
      title: "Investor & Founder Exchange",
      desc: "Serious conversations focused on capital access, scale readiness, and regional expansion opportunities.",
      icon: "briefcaseBusiness",
    },
    {
      title: "Strategic Networking",
      desc: "High-value connections formed across founders, institutions, business leaders, and ecosystem partners.",
      icon: "users",
    },
    {
      title: "Institutional Participation",
      desc: "The forum strengthened engagement with organizations shaping entrepreneurship and growth ecosystems.",
      icon: "building2",
    },
    {
      title: "Global Thought Leadership",
      desc: "Sessions reflected the wider GEF goal of connecting ideas, markets, and influential voices across regions.",
      icon: "mic2",
    },
    {
      title: "Platform Momentum",
      desc: "Dubai added another important chapter to GEF's long-term international growth journey.",
      icon: "star",
    },
  ],
  overview: {
    eyebrow: "Overview",
    title: "A three-day business learning and networking experience.",
    paragraphs: [
      "Day 1 brought delegates together at Hotel Conrad, Dubai for a full-day conference of keynote addresses, fireside chats, CEO roundtables, panel discussions, and curated networking. Sessions explored entrepreneurship, innovation, policy, trade corridors, sustainability, technology, health care, and investment.",
      "Day 2 moved into the UAE's innovation and industrial zones, with curated visits to leading parks, industrial hubs, and free zones including Dubai Internet City, Dubai Silicon Oasis, Sharjah Research Technology Park, and more. Delegates also met incubators, accelerators, and economic development authorities.",
      "Day 3 offered an optional, limited-entry field visit and expert workshop at DP World, Bharat Mart, JAFZA, Jebel Ali Free Zone, and Hamriyah Free Zone, focused on logistics, maritime trade, warehousing, market expansion, compliance, and policy integration.",
    ],
    cards: [
      {
        title: "Expert In-House Sessions",
        desc: "Keynotes, fireside chats, CEO roundtables, and panels created practical dialogue on entrepreneurship, trade, innovation, investment, and sustainable growth.",
      },
      {
        title: "India-Gulf Collaboration",
        desc: "Global CEOs, investors, policymakers, trade commissioners, and innovation leaders explored cross-border partnerships and regional business opportunities.",
      },
      {
        title: "Curated UAE Field Visits",
        desc: "Delegates experienced innovation parks, industrial hubs, free zones, and the wider UAE ecosystem through focused visits and direct interactions.",
      },
      {
        title: "B2B Networking Access",
        desc: "Networking lounges and curated business connections supported international delegates, regional success stories, and collaborative case studies.",
      },
    ],
  },
  leadershipCards: getSharedLeadershipCards(),
  speakerCards: getPastEditionSpeakerCards("dubai"),
  agenda: [
    {
      day: "16 August 2025 - Day 1: In-House Sessions",
      items: [
        { time: "08:30-09:30", title: "Welcome, Networking and Tea", type: "Networking" },
        { time: "09:30-11:00", title: "Inauguration Session and Keynote Speeches", type: "Inauguration" },
        { time: "11:00-11:30", title: "Fireside Chat: Success Stories Unplugged - Entrepreneurs Journey That Inspires", type: "Fireside Chat" },
        { time: "11:30-11:45", title: "Networking Tea Break", type: "Networking" },
        { time: "11:45-12:30", title: "CEO Roundtable: Shaping Ports & Infrastructure - India-Gulf Leadership Dialogue on Trade Corridors", type: "CEO Roundtable" },
        { time: "12:30-13:15", title: "Panel Discussion: Gulf Meets Maharashtra - Bridging Borders and Building Opportunities", type: "Panel Discussion" },
        { time: "13:15-14:15", title: "Lunch & Networking", type: "Networking" },
        { time: "14:15-15:15", title: "Open Dialogue: Building Your Business in the Gulf - Essential Insights for Entrepreneurs", type: "Open Dialogue" },
        { time: "15:15-16:00", title: "Panel Discussion: Sustainability / Bioenergy - Future, Challenges, Innovation and Investment Pathways", type: "Panel Discussion" },
        { time: "16:00-16:45", title: "Panel Discussion: AI in Business - Leveraging Technology for Competitive Advantage and Growth (Real Estate, Health Care and Retail)", type: "Panel Discussion" },
        { time: "16:45-17:00", title: "Networking Tea Break", type: "Networking" },
        { time: "17:00-17:30", title: "Fireside Chat: Entrepreneurial Wisdom and Forward Thinking", type: "Fireside Chat" },
        { time: "17:30-18:00", title: "Valedictory", type: "Closing" },
      ],
    },
    {
      day: "17 August 2025 - Day 2: Field Visits",
      items: [
        { time: "09:00-09:30", title: "Gathering for Field Excursion at Dedicated Spot", type: "Field Visit" },
        { time: "09:30-13:30", title: "Industrial Ports and Innovations Hubs of the UAE - transportation charges borne by participants at actual cost", type: "Field Visit" },
        { time: "14:00 onwards", title: "Drop-off at Central Dubai Locations", type: "Logistics" },
      ],
    },
    {
      day: "18 August 2025 - Day 3: DP World & JAFZA Field Visit (Optional, Limited Entry)",
      items: [
        { time: "09:00-13:00", title: "Visit DP World & JAFZA / Jebel Ali Free Zone, a global trade hub", type: "Field Visit" },
        { time: "09:00-13:00", title: "Explore logistics, warehousing, Bharat Mart opportunities, and a curated workshop for delegates - reserved for selected delegates with prior registration", type: "Expert Workshop" },
      ],
    },
  ],
  supportedBy: [],
  supportedByLogos: [
    {
      src: "/Assets/Events/GEC_Dubai 2025/Supported By/maharashtra_logo.png",
      alt: "Government of Maharashtra",
    },
    {
      src: "/Assets/Events/GEC_Dubai 2025/Supported By/Screenshot 2026-09-02 153139.png",
      alt: "Government of India Ministry of Micro, Small and Medium Enterprises",
    },
    {
      src: "/Assets/Events/GEC_Dubai 2025/Supported By/Screenshot 2026-09-02 153156.png",
      alt: "Maharashtra Industrial Development Corporation",
    },
    {
      src: "/Assets/Events/GEC_Dubai 2025/Supported By/Screenshot 2026-09-02 153208.png",
      alt: "Maharashtra Institution for Transformation",
    },
  ],
  media: {
    pressCoverage: [],
    interviews: [],
    galleryImages: [
      { src: "/Assets/Events/GEC_Dubai 2025/Gallery/1.JPG", alt: "GEC Dubai 2025 gallery preview image 1" },
      { src: "/Assets/Events/GEC_Dubai 2025/Gallery/2.JPG", alt: "GEC Dubai 2025 gallery preview image 2" },
      { src: "/Assets/Events/GEC_Dubai 2025/Gallery/3.JPG", alt: "GEC Dubai 2025 gallery preview image 3" },
    ],
  },
  galleryPreview: [],
  mediaCoveragePreview: [],
  mediaCoverageVideos: [
    "https://www.youtube.com/embed/toHTuWcfwnI?rel=0&playsinline=1",
    "https://www.youtube.com/embed/n4YsS90x5_A?rel=0&playsinline=1",
    "https://www.youtube.com/embed/8O23PrCf9xk?rel=0&playsinline=1",
    "https://www.youtube.com/embed/vxeRbZZXClA?rel=0&playsinline=1",
    "https://www.youtube.com/embed/FZ7xsZ8npsU?rel=0&playsinline=1",
    "https://www.youtube.com/embed/Uiv7WBfrBqQ?rel=0&playsinline=1",
  ],
  showBottomPreviews: false,
};
