// Central GEF data + event mode flag.
// Flip EVENT_MODE to false for evergreen/normal mode.

export const EVENT_MODE = true;

export const ACTIVE_EVENT = {
  slug: "GEFPune2027",
  name: "GEF Pune 2027",
  shortName: "Pune 2027",
  date: "16 & 17 January 2027",
  dateBadge: "JAN 2027",
  city: "Pune, India",
  venue: "The Orchid Hotel, Balewadi",
  theme: "From Rural Bharat to Global Markets",
  tagline:
    "Powering Viksit Bharat 2047 through Connect, Capital, and Market access.",
};

export const IMPACT_STATS = [
  { value: "3000+", label: "Entrepreneurs" },
  { value: "120+", label: "Speakers" },
  { value: "100+", label: "Investors & Vcs" },
  { value: "50+", label: "Partners" },
  { value: "30+", label: "Diplomats & Global Thought Leaders" },
  { value: "25+", label: "Countries Represented by Delegates" },
];

export const WHY_ATTEND = [
  { title: "Expand Your Network", desc: "Build meaningful connections across industries and borders." },
  { title: "Discover Collaborations", desc: "Meet partners, mentors, and institutions that accelerate growth." },
  { title: "Gain Actionable Insights", desc: "Learn from global leaders, innovators, and changemakers." },
  { title: "Unlock New Opportunities", desc: "Explore investments, business partnerships, and market access." },
  { title: "Accelerate Growth", desc: "Access ideas, resources, and strategies to scale your enterprise." },
  { title: "Be Part of the Ecosystem", desc: "Join a year-round community committed to innovation and sustainable impact." },
];

export const WHO_CAN_ATTEND = [
  "Entrepreneurs",
  "Startup Founders",
  "Investors",
  "SMEs & Business Owners",
  "Corporate Leaders",
  "Policymakers & Institutions",
  "Students & Professionals",
  "Media & Ecosystem Partners",
];

export const VALUE_PILLARS = [
  { title: "Global Entrepreneurship Platform", desc: "A neutral, trusted forum connecting builders worldwide." },
  { title: "Cross-Border Opportunities", desc: "Real conversations on trade, capital, and market access." },
  { title: "Ecosystem Collaboration", desc: "Founders, investors, institutions and policy at one table." },
];

export const DIFFERENTIATORS = [
  { title: "Cross-Border Opportunity", desc: "Markets, capital, and partnerships across geographies." },
  { title: "Policy + Business Dialogue", desc: "Where founders and decision-makers meet candidly." },
  { title: "Investor & Growth Access", desc: "Curated rooms with serious investors and senior operators." },
  { title: "Diaspora & Institutional Network", desc: "A trusted bridge across diaspora and ecosystem leaders." },
];

export const LEADERSHIP = [
  {
    name: "A. R. Mehta",
    role: "Founder & Chairman",
    org: "Global Entrepreneur Forum",
    bio: "Three decades building cross-border businesses across India, the Gulf and the UK. Founder of the GEF platform.",
    photo: "/Assets/Events/GEC_Pune 2025/Speakers/Sample_Img.webp",
  },
  {
    name: "Priya Sharma",
    role: "President",
    org: "GEF Council",
    bio: "Investor and operator advising late-stage founders on global expansion, capital strategy and policy.",
    photo: "/Assets/Events/GEC_Pune 2025/Speakers/Sample_Img.webp",
  },
  {
    name: "Rajiv Khanna",
    role: "Convener - India",
    org: "GEF India Chapter",
    bio: "Veteran ecosystem builder convening India's founder-investor-policy dialogue at GEF.",
    photo: "/Assets/Events/GEC_Pune 2025/Speakers/Sample_Img.webp",
  },
  {
    name: "Layla Al-Hashimi",
    role: "Convener - MENA",
    org: "GEF Dubai Chapter",
    bio: "Bridges family offices, sovereign capital and global founders across the India-MENA corridor.",
    photo: "/Assets/Events/GEC_Pune 2025/Speakers/Sample_Img.webp",
  },
  {
    name: "David Okafor",
    role: "Investor Council Chair",
    org: "GEF",
    bio: "Leads the GEF Investor Council - curating serious capital allocators across global markets.",
    photo: "/Assets/Events/GEC_Pune 2025/Speakers/Sample_Img.webp",
  },
  {
    name: "Meera Iyer",
    role: "Director - Partnerships",
    org: "GEF",
    bio: "Drives institutional, ecosystem and community partnerships across GEF editions worldwide.",
    photo: "/Assets/Events/GEC_Pune 2025/Speakers/Sample_Img.webp",
  },
];

export type LeadershipMember = (typeof LEADERSHIP)[number];

export type PartnerLogo = { name: string; href: string };
export const PARTNER_GROUPS: { group: string; logos: PartnerLogo[] }[] = [
  {
    group: "Organized By",
    logos: [
      { name: "GEF Council", href: "https://example.com/gef-council" },
      { name: "GEF Foundation", href: "https://example.com/gef-foundation" },
    ],
  },
  {
    group: "Ecosystem Partners",
    logos: [
      { name: "TiE Global", href: "https://tie.org" },
      { name: "NASSCOM", href: "https://nasscom.in" },
      { name: "Indus Chamber", href: "https://example.com/indus" },
      { name: "Asia Forum", href: "https://example.com/asia-forum" },
    ],
  },
  {
    group: "Community Partners",
    logos: [
      { name: "Founders Network", href: "https://example.com/founders" },
      { name: "Investors Circle", href: "https://example.com/investors" },
      { name: "Diaspora Connect", href: "https://example.com/diaspora" },
      { name: "Women in Business", href: "https://example.com/wib" },
    ],
  },
];

export type GalleryItem = {
  src: string;
  alt: string;
  event: "Pune 2025" | "Dubai 2025";
};

export const GALLERY: GalleryItem[] = [
  { src: "/Assets/Gallary/1.webp", alt: "GEF Pune 2025 gallery image 1", event: "Pune 2025" },
  { src: "/Assets/Gallary/2.webp", alt: "GEF Pune 2025 gallery image 2", event: "Pune 2025" },
  { src: "/Assets/Gallary/3.JPG", alt: "GEF Pune 2025 gallery image 3", event: "Pune 2025" },
  { src: "/Assets/Gallary/4.webp", alt: "GEF Pune 2025 gallery image 4", event: "Pune 2025" },
  { src: "/Assets/Gallary/5.webp", alt: "GEF Pune 2025 gallery image 5", event: "Pune 2025" },
  { src: "/Assets/Gallary/6.webp", alt: "GEF Pune 2025 gallery image 6", event: "Pune 2025" },
  { src: "/Assets/Gallary/7.JPG", alt: "GEF Pune 2025 gallery image 7", event: "Pune 2025" },
  { src: "/Assets/Gallary/8.webp", alt: "GEF Pune 2025 gallery image 8", event: "Pune 2025" },
  { src: "/Assets/Gallary/9.webp", alt: "GEF Pune 2025 gallery image 9", event: "Pune 2025" },
  
  
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/11.JPG", alt: "GEF Dubai 2025 gallery image 5", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/12.JPG", alt: "GEF Dubai 2025 gallery image 6", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/51.JPG", alt: "GEF Dubai 2025 gallery image 12", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/13.JPG", alt: "GEF Dubai 2025 gallery image 7", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/15.JPG", alt: "GEF Dubai 2025 gallery image 9", event: "Dubai 2025" },
  
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/73.JPG", alt: "GEF Dubai 2025 gallery image 18", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/14.JPG", alt: "GEF Dubai 2025 gallery image 8", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/16.JPG", alt: "GEF Dubai 2025 gallery image 10", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/17.JPG", alt: "GEF Dubai 2025 gallery image 11", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/10.JPG", alt: "GEF Dubai 2025 gallery image 4", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/52.JPG", alt: "GEF Dubai 2025 gallery image 13", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/53.JPG", alt: "GEF Dubai 2025 gallery image 14", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/55.JPG", alt: "GEF Dubai 2025 gallery image 15", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/71.JPG", alt: "GEF Dubai 2025 gallery image 16", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/72.JPG", alt: "GEF Dubai 2025 gallery image 17", event: "Dubai 2025" },
  
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/74.JPG", alt: "GEF Dubai 2025 gallery image 19", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/75.JPG", alt: "GEF Dubai 2025 gallery image 20", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/76.JPG", alt: "GEF Dubai 2025 gallery image 21", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/97.JPG", alt: "GEF Dubai 2025 gallery image 22", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/98.JPG", alt: "GEF Dubai 2025 gallery image 23", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/99.JPG", alt: "GEF Dubai 2025 gallery image 24", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/100.JPG", alt: "GEF Dubai 2025 gallery image 25", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/1.JPG", alt: "GEF Dubai 2025 gallery image 1", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/2.JPG", alt: "GEF Dubai 2025 gallery image 2", event: "Dubai 2025" },
  { src: "/Assets/Events/GEC_Dubai 2025/Gallery/3.JPG", alt: "GEF Dubai 2025 gallery image 3", event: "Dubai 2025" },
];

export type PressCoverageItem = {
  src: string;
  alt: string;
  event: "Pune 2025" | "Dubai 2025";
};

export const PRESS_COVERAGE_ITEMS: PressCoverageItem[] = [
  { src: "/Assets/Events/GEC_Pune 2025/Media/1.jpeg", alt: "GEC Pune 2025 press coverage clipping 1", event: "Pune 2025" },
  { src: "/Assets/Events/GEC_Pune 2025/Media/2.jpeg", alt: "GEC Pune 2025 press coverage clipping 2", event: "Pune 2025" },
  { src: "/Assets/Events/GEC_Pune 2025/Media/3.jpeg", alt: "GEC Pune 2025 press coverage clipping 3", event: "Pune 2025" },
  { src: "/Assets/Events/GEC_Pune 2025/Media/6.jfif", alt: "GEC Pune 2025 press coverage clipping 4", event: "Pune 2025" },
];

export const MEDIA_COVERAGE = [
  { pub: "Business Standard", headline: "GEC Pune 2025 brings together global entrepreneurs and investors", date: "March 2025" },
  { pub: "Khaleej Times", headline: "GEC Dubai 2025 spotlights cross-border business opportunity", date: "November 2025" },
  { pub: "YourStory", headline: "Inside the Global Entrepreneur Forum ecosystem", date: "April 2025" },
  { pub: "Entrepreneur Middle East", headline: "GEF Dubai positions India-MENA corridor for growth", date: "December 2025" },
];

export type TestimonialVideo = {
  name: string;
  role: string;
  embedUrl: string;
};

export type TestimonialQuote = {
  title: string;
  quote: string;
  attribution: string;
};

export const TESTIMONIAL_VIDEOS: TestimonialVideo[] = [
  {
    name: "Nagraj",
    role: "Video reflection",
    embedUrl: "https://www.youtube.com/embed/FUfxphS2BU0?rel=0&playsinline=1",
  },
  {
    name: "Mahesh Kithare",
    role: "Video reflection",
    embedUrl: "https://www.youtube.com/embed/zeTkJCb2AvY?rel=0&playsinline=1",
  },
];

export const TESTIMONIAL_QUOTES: TestimonialQuote[] = [
  {
    title: "Founder perspective",
    quote:
      "GEF creates the kind of room where introductions become real conversations and real conversations turn into next steps.",
    attribution: "Community voice",
  },
  {
    title: "Investor perspective",
    quote:
      "The value is in the mix of decision-makers, founders, and institutions sharing one platform with clear business intent.",
    attribution: "Ecosystem reflection",
  },
  {
    title: "Partner perspective",
    quote:
      "It feels less like a one-day event and more like an ecosystem designed to keep collaboration moving after the stage lights go down.",
    attribution: "GEF network insight",
  },
];

export const PARTNERSHIP_OPPORTUNITIES = [
  "Strategic Partner",
  "Sponsorship Partner",
  "Knowledge Partner",
  "Ecosystem Partner",
  "Community Partner",
  "Media Partner",
  "Exhibition / Showcase Partner",
  "Speaker / Program Collaboration",
];

export const FAQS = [
  { q: "Who can attend GEF events?", a: "Entrepreneurs, investors, business leaders, policymakers, institutions, students, and ecosystem partners are welcome to participate." },
  { q: "How do I register?", a: "Click the Register Now button on the active event page and complete the short form. Our team will confirm your delegate access." },
  { q: "Is payment required?", a: "Delegate categories vary by event. Pricing and complimentary access categories are listed on the active event page." },
  { q: "Can sponsors participate?", a: "Yes. Visit Partners & Sponsors to explore sponsorship and partnership opportunities, or write to us directly." },
  { q: "Can media attend?", a: "Accredited media are welcome. Please submit a media inquiry through the Contact page." },
  { q: "Who do I contact?", a: "Reach the GEF team via the Contact page or email info@gefofficial.com." },
];
