import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect } from "react";
import { ArrowRight, ExternalLink } from "lucide-react";
import { breadcrumbSchema, createSeoHead, webpageSchema } from "../lib/seo";
import { PlatinumPassVisualCard } from "../components/gef/PlatinumPassVisualCard";

const REGISTRATION_EMBED_URL =
  "https://tktplz.events/embed/gje6gw-global-entreprenures-forum?embed=true&page=embed";
const REGISTRATION_FALLBACK_URL = "https://tktplz.events/gje6gw-global-entreprenures-forum?page=embed-btn";
const DREAMCAST_EVENT_BANNER_URL =
  "https://cdn1.godcstatic.com/diy_reg_live_events/media/09-2026/u-gje1yc/1788964913.png";
const IFRAME_RESIZER_URL = "https://cdn.jsdelivr.net/npm/@iframe-resizer/parent@5.3.2";

declare global {
  interface Window {
    iframeResize?: (
      options: { license: string; waitForLoad: boolean; checkOrigin: boolean; log: boolean },
      target: string,
    ) => Array<{ disconnect?: () => void }>;
  }
}

function loadIframeResizer() {
  return new Promise<void>((resolve, reject) => {
    if (window.iframeResize) {
      resolve();
      return;
    }

    const existingScript = document.querySelector<HTMLScriptElement>(
      'script[src="' + IFRAME_RESIZER_URL + '"]',
    );
    if (existingScript) {
      existingScript.addEventListener("load", () => resolve(), { once: true });
      existingScript.addEventListener("error", () => reject(new Error("Unable to load iframe resizer")), { once: true });
      return;
    }

    const script = document.createElement("script");
    script.src = IFRAME_RESIZER_URL;
    script.async = true;
    script.addEventListener("load", () => resolve(), { once: true });
    script.addEventListener("error", () => reject(new Error("Unable to load iframe resizer")), { once: true });
    document.body.appendChild(script);
  });
}

export const Route = createFileRoute("/register")({
  head: () => {
    const seo = createSeoHead({
      title: "Register for GEF Pune 2027 | Global Entrepreneurs Forum",
      description:
        "Register for GEF Pune 2027, taking place on 16 and 17 January 2027 in Pune, India.",
      path: "/register",
      keywords: [
        "GEF Pune 2027 registration",
        "Global Entrepreneurs Forum registration",
        "GEF registration",
        "entrepreneur event registration Pune",
      ],
    });

    return {
      ...seo,
      links: [
        ...seo.links,
        { rel: "preconnect", href: "https://tktplz.events" },
        { rel: "preconnect", href: "https://cdn.jsdelivr.net", crossOrigin: "anonymous" },
      ],
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@graph": [
              webpageSchema({
                path: "/register",
                name: "GEF Pune 2027 Registration",
                description: "Official registration page for GEF Pune 2027.",
              }),
              breadcrumbSchema([
                { name: "Home", path: "/" },
                { name: "Register", path: "/register" },
              ]),
            ],
          }),
        },
      ],
    };
  },
  component: RegistrationPage,
});

function RegistrationPage() {
  useEffect(() => {
    let resizers: Array<{ disconnect?: () => void }> | undefined;
    let isMounted = true;
    let isFrameLoaded = false;
    let isLibraryLoaded = false;
    const frame = document.getElementById("childIframe");

    const initializeResizer = () => {
      if (
        !isMounted ||
        resizers ||
        !isFrameLoaded ||
        !isLibraryLoaded ||
        !window.matchMedia("(min-width: 769px)").matches ||
        !window.iframeResize
      ) {
        return;
      }

      // The vendor-supported resizer keeps the GEF page as the only desktop scroll area.
      resizers = window.iframeResize(
        { license: "GPLv3", waitForLoad: true, checkOrigin: false, log: false },
        "#childIframe",
      );
    };

    const handleFrameLoad = () => {
      isFrameLoaded = true;
      frame instanceof HTMLIFrameElement &&
        frame.contentWindow?.postMessage({ type: "parentUrl", url: window.location.href }, "*");
      initializeResizer();
    };

    frame?.addEventListener("load", handleFrameLoad);

    void loadIframeResizer()
      .then(() => {
        isLibraryLoaded = true;
        initializeResizer();
      })
      .catch(() => {
        // The frame remains usable at its responsive fallback height if resizing cannot load.
      });

    return () => {
      isMounted = false;
      frame?.removeEventListener("load", handleFrameLoad);
      resizers?.forEach((resizer) => resizer.disconnect?.());
    };
  }, []);

  return (
    <section className="gef-section !pt-4 !pb-[calc(env(safe-area-inset-bottom)+1.5rem)] sm:!pt-6 sm:!pb-8 md:!pt-10 md:!pb-10">
      <div className="gef-container">
        <div className="mx-auto max-w-4xl overflow-hidden rounded-2xl border border-[color:var(--hairline)] bg-white shadow-[0_18px_44px_-34px_rgba(5,43,87,0.2)] sm:rounded-[20px]">
          <img
            src={DREAMCAST_EVENT_BANNER_URL}
            alt="Global Entrepreneurs Forum, 16 and 17 January 2027, Pune"
            className="block aspect-[1670/626] w-full object-cover"
            fetchPriority="high"
          />
        </div>

        <div className="mx-auto mt-3 max-w-6xl overflow-hidden rounded-2xl border border-[color:var(--hairline)] bg-white shadow-[0_22px_56px_-38px_rgba(5,43,87,0.2)] sm:mt-5 sm:rounded-[24px]">
          <iframe
            allow="camera; microphone; clipboard-read; clipboard-write"
            id="childIframe"
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox"
            src={REGISTRATION_EMBED_URL}
            title="GEF Pune 2027 secure event registration"
            width="100%"
            frameBorder="0"
            className="block h-[34rem] w-full sm:h-[38rem] md:h-[400px]"
          />
        </div>

        <p className="mx-auto mt-4 max-w-md text-center text-sm leading-6 text-[color:var(--ink-soft)] sm:mt-5">
          If the registration form does not load,
          <a
            className="mt-3 inline-flex min-h-11 items-center justify-center gap-2 rounded-full border border-[color:var(--navy)] px-4 py-2 font-semibold text-[color:var(--navy)] transition-colors hover:bg-[color:var(--navy)] hover:text-white sm:ml-2 sm:mt-0 sm:min-h-0 sm:border-0 sm:p-0 sm:underline sm:decoration-[color:var(--gold)] sm:underline-offset-4"
            href={REGISTRATION_FALLBACK_URL}
            target="_blank"
            rel="noreferrer"
          >
            open secure registration in a new tab <ExternalLink className="inline h-3.5 w-3.5" />
          </a>
          .
        </p>

        <div className="relative mx-auto mt-8 max-w-4xl overflow-hidden rounded-[28px] bg-[linear-gradient(125deg,#02152e_0%,#073665_58%,#062142_100%)] px-6 py-8 text-white shadow-[0_26px_60px_-34px_rgba(5,43,87,0.7)] sm:px-9 sm:py-10">
          <div className="pointer-events-none absolute -right-16 -top-20 h-64 w-64 rounded-full border border-[color:var(--gold)]/30" />
          <div className="pointer-events-none absolute -bottom-24 left-1/3 h-48 w-48 rounded-full bg-[color:var(--gold)]/10 blur-3xl" />
          <div className="relative grid gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-end">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded-full border border-[color:var(--gold)]/50 bg-[color:var(--gold)]/10 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.2em] text-[color:var(--gold-light)]">
                  Curated Access
                </span>
                <span className="rounded-full border border-white/20 bg-white/10 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-white/80">
                  100 selected leaders
                </span>
              </div>
              <h2 className="mt-5 text-[clamp(2rem,4vw,3rem)] font-normal leading-[0.98] text-white" style={{ fontFamily: "var(--font-display)" }}>
                GEF Platinum <span className="text-[color:var(--gold-light)]">Pass</span>
              </h2>
              <p className="mt-4 max-w-xl text-sm leading-7 text-white/75 sm:text-base">
                A more personal GEF Pune 2027 experience, created for leaders who value considered access and high-value conversations.
              </p>
              <Link to="/platinum-pass" className="gef-btn mt-6 border-0 bg-[color:var(--gold)] text-[color:var(--navy-deep)] hover:bg-[color:var(--gold-light)]">
                Explore Platinum Pass <ArrowRight className="h-4 w-4" />
              </Link>
            </div>

            <PlatinumPassVisualCard className="mx-auto max-w-[20rem]" />
          </div>
        </div>
      </div>
    </section>
  );
}
