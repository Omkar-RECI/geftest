import { createFileRoute } from "@tanstack/react-router";
import { SectionHeading } from "../components/gef/CTA";
import { breadcrumbSchema, createSeoHead, webpageSchema } from "../lib/seo";

export const Route = createFileRoute("/terms-of-use")({
  head: () => {
    const seo = createSeoHead({
      title: "Terms of Use | Global Entrepreneurs Forum (GEF)",
      description: "Terms of Use for the Global Entrepreneurs Forum website, a flagship initiative of RECI India Foundation.",
      path: "/terms-of-use",
    });

    return {
      ...seo,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@graph": [
              webpageSchema({
                path: "/terms-of-use",
                name: "GEF Terms of Use",
                description: "Terms governing use of the Global Entrepreneurs Forum website.",
              }),
              breadcrumbSchema([
                { name: "Home", path: "/" },
                { name: "Terms of Use", path: "/terms-of-use" },
              ]),
            ],
          }),
        },
      ],
    };
  },
  component: TermsOfUsePage,
});

const SECTIONS = [
  {
    title: "Acceptance of these terms",
    body: "By accessing or using this website, you agree to these Terms of Use. This website is operated for Global Entrepreneurs Forum (GEF), a flagship initiative of RECI India Foundation. If you do not agree, please do not use the website.",
  },
  {
    title: "Website content",
    body: "GEF provides information about forums, events, speakers, partners, media and related initiatives for general informational purposes. We aim to keep content accurate and current, but event programmes, speakers, venues, schedules and other details may change without notice.",
  },
  {
    title: "Appropriate use",
    body: "You must use this website lawfully and must not interfere with its security or operation, attempt unauthorised access, submit false information, misuse contact channels, or reproduce site content in a way that suggests endorsement by GEF or RECI India Foundation.",
  },
  {
    title: "Intellectual property",
    body: "Unless stated otherwise, the GEF name, logos, website design, text, graphics, photographs and other materials are owned by or used with permission by GEF or their respective rights holders. They may not be copied, modified, distributed or commercially used without prior written permission.",
  },
  {
    title: "Events and registrations",
    body: "Event participation, registration, payment, cancellation and attendance may be subject to separate event-specific terms and the policies of the relevant registration provider. Registration availability does not guarantee admission until confirmed through the applicable event process.",
  },
  {
    title: "Third-party links",
    body: "This website may link to third-party websites, including RECI India Foundation, social channels and registration providers. These sites are outside GEF's control. Their content, availability, security and privacy practices are governed by their own terms.",
  },
  {
    title: "Liability and contact",
    body: "To the extent permitted by applicable law, GEF and RECI India Foundation are not liable for indirect loss arising from use of, or inability to use, this website. Questions about these terms can be sent to info@gefofficial.com. We may revise these terms by posting an updated version on this page.",
  },
];

function TermsOfUsePage() {
  return (
    <main>
      <section className="gef-section !pt-10 !pb-12 md:!pt-14 md:!pb-16">
        <div className="gef-container max-w-4xl">
          <SectionHeading eyebrow="GEF Legal" title="Terms of Use" />
          <p className="mt-4 text-sm text-[color:var(--ink-muted)]">Last updated: 12 September 2026</p>
          <div className="mt-8 rounded-[24px] border border-[color:var(--hairline)] bg-white p-6 shadow-[0_18px_44px_-38px_rgba(5,43,87,0.22)] md:p-9">
            <p className="text-base leading-8 text-[color:var(--ink-soft)]">
              These terms establish the ground rules for using the Global Entrepreneurs Forum website and related digital services.
            </p>
            <div className="mt-8 space-y-7">
              {SECTIONS.map((section) => (
                <section key={section.title}>
                  <h2 className="text-xl text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>
                    {section.title}
                  </h2>
                  <p className="mt-2 text-sm leading-7 text-[color:var(--ink-soft)]">{section.body}</p>
                </section>
              ))}
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
