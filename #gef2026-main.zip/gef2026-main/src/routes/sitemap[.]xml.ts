import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";
import { PAST_EDITIONS_ARCHIVE } from "../content/past-editions";
import { UPCOMING_EVENTS_ARCHIVE } from "../content/upcoming-events";
import { SITE_URL } from "../lib/seo";

const BASE_URL = SITE_URL;
const LAST_MOD = "2026-09-01";

type SitemapEntry = {
  path: string;
  lastmod?: string;
  changefreq?: "daily" | "weekly" | "monthly";
  priority?: string;
};

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const entries: SitemapEntry[] = [
          { path: "/", priority: "1.0", changefreq: "weekly" },
          { path: "/about-gef", priority: "0.9", changefreq: "weekly" },
          { path: "/upcoming-events", priority: "0.9", changefreq: "weekly" },
          { path: "/past-editions", priority: "0.9", changefreq: "weekly" },
          { path: "/speakers", priority: "0.8", changefreq: "weekly" },
          { path: "/partners-sponsors", priority: "0.8", changefreq: "weekly" },
          { path: "/media", priority: "0.8", changefreq: "weekly" },
          { path: "/contact", priority: "0.7", changefreq: "monthly" },
          { path: "/privacy-policy", priority: "0.4", changefreq: "yearly" },
          { path: "/terms-of-use", priority: "0.4", changefreq: "yearly" },
          { path: "/payment-refund-policy", priority: "0.4", changefreq: "yearly" },
          { path: "/platinum-pass", priority: "0.8", changefreq: "weekly" },
          ...PAST_EDITIONS_ARCHIVE.map((event) => ({
            path: `/past-editions/${event.slug}`,
            priority: "0.8",
            changefreq: "monthly" as const,
          })),
          ...UPCOMING_EVENTS_ARCHIVE.filter((event) => event.hasEventPage).map((event) => ({
            path: `/${event.slug}`,
            priority: "0.9",
            changefreq: "weekly" as const,
          })),
        ];
        const urls = entries
          .map(
            ({ path, lastmod = LAST_MOD, changefreq = "weekly", priority = "0.7" }) =>
              `  <url><loc>${BASE_URL}${path}</loc><lastmod>${lastmod}</lastmod><changefreq>${changefreq}</changefreq><priority>${priority}</priority></url>`,
          )
          .join("\n");
        const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>`;
        return new Response(xml, {
          headers: { "Content-Type": "application/xml", "Cache-Control": "public, max-age=3600" },
        });
      },
    },
  },
});
