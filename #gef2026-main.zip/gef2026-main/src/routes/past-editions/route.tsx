import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/past-editions")({
  component: PastEditionsLayout,
});

function PastEditionsLayout() {
  return <Outlet />;
}
