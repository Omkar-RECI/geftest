import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  BriefcaseBusiness,
  Building2,
  Calendar,
  Download,
  Globe2,
  MapPin,
  Mic2,
  Star,
  Users,
  type LucideIcon,
} from "lucide-react";
import { GALLERY, MEDIA_COVERAGE } from "../../data/gef";
import {
  getPastEditionContent,
  type AgendaDay,
  type AgendaItem,
  type PastEditionContent,
  type PastEditionDetailedContent,
  type PastEditionGenericContent,
  type PastEditionHighlightIconKey,
  type PersonCard,
  type Stat,
} from "../../content/past-editions";
import { PartnerLogos } from "../../components/gef/PartnerLogos";
import { SectionHeading } from "../../components/gef/CTA";
import { SPEAKER_PROFILES, type SpeakerProfile } from "../../content/speakers";
import { useAlignedProfileNames } from "../../hooks/useAlignedProfileNames";
import {
  absoluteUrl,
  breadcrumbSchema,
  createSeoHead,
  eventSchema,
  parseEventDateRange,
  videoSchema,
  webpageSchema,
} from "../../lib/seo";

export const Route = createFileRoute("/past-editions/$slug")({
  loader: ({ params }) => {
    const event = getPastEditionContent(params.slug);
    if (!event) throw notFound();
    return { event };
  },
  head: ({ loaderData }) => {
    const e = loaderData?.event;
    if (!e) {
      return createSeoHead({
        title: "Past Edition | Global Entrepreneurs Forum (GEF)",
        description: "Global Entrepreneurs Forum past edition archive.",
        path: "/past-editions",
      });
    }

    const path = `/past-editions/${e.slug}`;
    const eventDates = parseEventDateRange(e.date);
    const isPuneEdition = e.slug === "GEC-Pune-2025";
    const isDubaiEdition = e.slug === "gec-dubai-2025";
    const seo = createSeoHead({
      title: isPuneEdition
        ? "GEC Pune 2025 | Global Entrepreneurs Conclave | Pune"
        : isDubaiEdition
          ? "GEC Dubai 2025 | Global Entrepreneurs Conclave Dubai"
          : `${e.name} | Global Entrepreneurs Forum Past Edition`,
      description: isPuneEdition
        ? "Explore GEC Pune 2025, featuring entrepreneurs, startups, investors, corporates, and ecosystem leaders for networking, investment, business partnerships, and global opportunities."
        : isDubaiEdition
          ? "Explore GEC Dubai 2025, connecting entrepreneurs, investors, policymakers, and business leaders from India, the UAE, and global markets for partnerships and growth."
          : `${e.name} in ${e.city}: ${e.summary}`,
      path,
      image: e.image,
      type: "article",
      keywords: [
        e.name,
        `${e.city} entrepreneur event`,
        "GEF past edition",
        "event speakers",
        "event media",
        ...(isPuneEdition
          ? ["GEC Pune 2025", "Global Entrepreneurs Conclave Pune", "entrepreneurship event Pune", "startup event Pune"]
          : []),
        ...(isDubaiEdition
          ? ["GEC Dubai 2025", "Global Entrepreneurs Conclave Dubai", "entrepreneurship event Dubai", "India UAE business networking"]
          : []),
      ],
    });

    const graph = [
      webpageSchema({
        path,
        name: e.name,
        description: e.summary,
      }),
      breadcrumbSchema([
        { name: "Home", path: "/" },
        { name: "Past Editions", path: "/past-editions" },
        { name: e.name, path },
      ]),
      eventSchema({
        path,
        name: e.name,
        description: e.summary,
        image: e.image,
        startDate: eventDates.startDate,
        endDate: eventDates.endDate,
        locationName: e.venue,
        locationAddress: `${e.venue}, ${e.city}`,
        eventStatus: "https://schema.org/EventCompleted",
      }),
    ];

    if (e.template === "detailed" && e.about.featuredVideoUrl) {
      graph.push(
        videoSchema({
          name: `${e.name} featured video`,
          description: e.summary,
          embedUrl: e.about.featuredVideoUrl,
          pagePath: path,
          thumbnailUrl: absoluteUrl(e.image),
        }),
      );
    }

    return {
      ...seo,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@graph": graph,
          }),
        },
      ],
    };
  },
  notFoundComponent: () => (
    <div className="gef-container py-32 text-center">
      <h1 className="text-4xl">Edition not found</h1>
      <Link to="/past-editions" className="gef-btn gef-btn-secondary mt-6">
        Back to Past Editions
      </Link>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="gef-container py-32 text-center">
      <h1 className="text-4xl">Something went wrong</h1>
      <p className="mt-2 text-[color:var(--ink-soft)]">{error.message}</p>
    </div>
  ),
  component: PastEventDetail,
});

const GENERIC_TABS = ["Overview", "Speakers", "Agenda", "Partners", "Media", "Gallery"] as const;
type GenericTab = (typeof GENERIC_TABS)[number];

const DETAILED_TABS = ["Overview", "Leadership", "Speakers", "Agenda", "Supported By", "Media"] as const;
type DetailedTab = (typeof DETAILED_TABS)[number];

const HIGHLIGHT_ICONS: Record<PastEditionHighlightIconKey, LucideIcon> = {
  globe2: Globe2,
  briefcaseBusiness: BriefcaseBusiness,
  mic2: Mic2,
  star: Star,
  users: Users,
  building2: Building2,
};

function PastEventDetail() {
  const { event } = Route.useLoaderData() as { event: PastEditionContent };

  if (event.template === "detailed") {
    return <DetailedPastEditionPage event={event} />;
  }

  return <GenericPastEditionPage event={event} />;
}

function GenericPastEditionPage({ event }: { event: PastEditionGenericContent }) {
  const [tab, setTab] = useState<GenericTab>("Overview");

  const scrollToTabSection = () => {
    const section = document.getElementById("past-edition-tab-content");
    if (!section) return;

    section.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <>
      <section className="relative overflow-hidden bg-[color:var(--navy-deep)]">
        <img src={event.image} alt={`${event.name} cover`} className="absolute inset-0 h-full w-full object-cover opacity-40" width={1600} height={1000} />
        <div className="absolute inset-0" style={{ background: "var(--gradient-hero-overlay)" }} />
        <div className="gef-container relative pb-10 pt-8 md:pb-14 md:pt-10">
          <Link to="/past-editions" className="inline-flex items-center gap-2 text-sm text-white/80 hover:text-white">
            <ArrowLeft className="h-4 w-4" /> Past Editions
          </Link>
          <span className="gef-eyebrow mt-4 text-[color:var(--gold-light)]">{event.date}</span>
          <h1 className="mt-3 max-w-3xl text-[clamp(1.9rem,5vw,3.7rem)] font-normal leading-[1.05] text-white">{event.name}</h1>
          <div className="mt-4 flex flex-wrap gap-x-6 gap-y-2 text-sm text-white/80">
            <span className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-[color:var(--gold-light)]" />
              {event.city}
            </span>
            <span className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-[color:var(--gold-light)]" />
              {event.venue}
            </span>
          </div>
          <p className="mt-4 max-w-2xl text-white/80 md:text-lg">{event.summary}</p>
        </div>
      </section>

      <section className="border-b border-[color:var(--hairline)] bg-white">
        <div className="gef-container grid grid-cols-2 gap-4 py-8 sm:grid-cols-4">
          {event.stats.map((s: Stat) => (
            <div key={s.label}>
              <div className="text-2xl text-[color:var(--gold-dark)]" style={{ fontFamily: "var(--font-display)" }}>
                {s.value}
              </div>
              <div className="mt-1 text-xs uppercase tracking-[0.15em] text-[color:var(--ink-muted)]">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="sticky top-20 z-30 border-b border-[color:var(--hairline)] bg-white/90 backdrop-blur">
        <div className="gef-container">
          <div className="flex gap-2 overflow-x-auto py-3">
            {GENERIC_TABS.map((t) => (
              <button
                key={t}
                onClick={() => {
                  setTab(t);
                  window.setTimeout(scrollToTabSection, 0);
                }}
                className={`rounded-full px-4 py-2 text-sm font-medium whitespace-nowrap transition-colors ${
                  tab === t ? "bg-[color:var(--navy)] text-white" : "text-[color:var(--ink-soft)] hover:bg-[color:var(--off-white)]"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section id="past-edition-tab-content" className="gef-section !py-6 md:!py-8">
        <div className="gef-container">
          {tab === "Overview" && (
            <div className="max-w-3xl">
              <h2 className="text-3xl font-normal text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>
                About {event.name}
              </h2>
              <p className="mt-5 text-[color:var(--ink-soft)] md:text-lg">{event.summary}</p>
              <p className="mt-5 text-[color:var(--ink-soft)] md:text-lg">
                {event.name} brought together founders, investors, and ecosystem partners from across markets for two days of curated conversations, networking and showcases - anchored around cross-border opportunity.
              </p>
            </div>
          )}

          {tab === "Speakers" && (
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {event.speakers.map((speaker) => (
                <div key={speaker.name} className="gef-card flex items-start gap-4">
                  <div className="grid h-14 w-14 shrink-0 place-items-center rounded-full text-base font-semibold text-[color:var(--navy)]" style={{ background: "var(--gold-soft)", fontFamily: "var(--font-display)" }}>
                    {speaker.name
                      .split(" ")
                      .map((part) => part[0])
                      .slice(0, 2)
                      .join("")}
                  </div>
                  <div className="min-w-0">
                    <div className="truncate font-semibold text-[color:var(--navy)]">{speaker.name}</div>
                    <div className="text-sm text-[color:var(--ink-soft)]">{speaker.role}</div>
                    <div className="text-xs text-[color:var(--ink-muted)]">{speaker.org}</div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === "Agenda" && (
            <div className="space-y-10">
              {event.agenda.map((day: AgendaDay) => (
                <div key={day.day}>
                  <h3 className="text-2xl font-normal text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>
                    {day.day}
                  </h3>
                  <ul className="mt-5 divide-y divide-[color:var(--hairline)] rounded-2xl border border-[color:var(--hairline)] bg-white overflow-hidden">
                    {day.items.map((item: AgendaItem) => (
                      <li key={`${day.day}-${item.time}-${item.title}`} className="p-5 md:p-6 transition-colors hover:bg-[color:var(--off-white)]/40">
                        <div className="grid grid-cols-1 gap-3 md:grid-cols-[140px_1fr] lg:grid-cols-[160px_1fr_200px] lg:items-start">
                          <div>
                            <div className="font-mono text-sm font-semibold text-[color:var(--gold-dark)]">{item.time}</div>
                            {item.duration ? (
                              <div className="mt-0.5 text-xs text-[color:var(--ink-muted)]">{item.duration} Min</div>
                            ) : null}
                          </div>
                          <div>
                            <div className="flex flex-wrap items-center gap-2">
                              <h4 className="font-semibold text-[color:var(--navy)] text-base leading-snug">{item.title}</h4>
                              {item.location ? (
                                <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium ${
                                  item.location.includes("Crystal")
                                    ? "bg-amber-100 text-amber-900 border border-amber-200"
                                    : item.location.includes("Breakout")
                                    ? "bg-sky-100 text-sky-900 border border-sky-200"
                                    : "bg-slate-100 text-slate-700"
                                }`}>
                                  {item.location}
                                </span>
                              ) : null}
                            </div>
                            <div className="mt-1 text-xs uppercase tracking-[0.14em] text-[color:var(--ink-muted)] font-medium">{item.type}</div>
                            {item.tracks && item.tracks.length > 0 ? (
                              <div className="mt-3.5 space-y-2 rounded-xl bg-[color:var(--off-white)] p-3.5 border border-[color:var(--hairline)]">
                                <div className="text-xs font-semibold uppercase tracking-wider text-[color:var(--navy)] opacity-80">Track Sessions</div>
                                <ul className="space-y-1.5 text-xs text-[color:var(--ink-soft)]">
                                  {item.tracks.map((track, idx) => (
                                    <li key={idx} className="flex items-start gap-2">
                                      <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-[color:var(--gold-dark)]" />
                                      <span>{track}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            ) : null}
                          </div>
                          {item.speaker ? (
                            <div className="text-xs text-[color:var(--ink-soft)] md:text-sm">{item.speaker}</div>
                          ) : null}
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          )}

          {tab === "Partners" && <PartnerLogos />}

          {tab === "Media" && (
            <div className="grid gap-5 md:grid-cols-2">
              {MEDIA_COVERAGE.map((item) => (
                <article key={item.headline} className="gef-card">
                  <div className="text-xs uppercase tracking-[0.15em] text-[color:var(--gold-dark)]">{item.pub}</div>
                  <h3 className="mt-2 text-lg font-semibold text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)", fontWeight: 500 }}>
                    {item.headline}
                  </h3>
                  <div className="mt-3 text-xs text-[color:var(--ink-muted)]">{item.date}</div>
                </article>
              ))}
            </div>
          )}

          {tab === "Gallery" && (
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
              {GALLERY.map((image) => (
                <div key={image.src} className="group relative aspect-square overflow-hidden rounded-xl">
                  <img src={image.src} alt={image.alt} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" width={1200} height={1200} />
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      <ArchiveStayUpdatedCTA />
    </>
  );
}

function ArchiveStayUpdatedCTA() {
  return (
    <section className="gef-section">
      <div className="gef-container">
        <div className="relative overflow-hidden rounded-[28px] p-10 md:p-16" style={{ background: "var(--gradient-navy)" }}>
          <div
            className="pointer-events-none absolute inset-0 opacity-40"
            style={{
              background:
                "radial-gradient(60% 60% at 80% 0%, rgba(228,196,106,0.35), transparent 60%), radial-gradient(40% 40% at 0% 100%, rgba(228,196,106,0.18), transparent 60%)",
            }}
          />
          <div className="relative mx-auto max-w-3xl text-center">
            <span className="gef-eyebrow text-[color:var(--gold-light)]">GEF Pune 2027</span>
            <h2 className="mt-5 text-[clamp(2rem,4vw,3.25rem)] font-normal leading-[1.1] text-white">Be part of the GEF Pune 2027.</h2>
            <p className="mx-auto mt-5 max-w-2xl text-base text-white/75 md:text-lg">
              Join the next flagship GEF gathering in Pune with entrepreneurs, investors, institutions, and ecosystem leaders.
            </p>
            <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
              <Link to="/register" className="gef-btn gef-btn-primary">
                Register Now
              </Link>
              <Link to="/GEFPune2027" className="gef-btn gef-btn-ghost">
                Explore the Event
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function ComingSoonPanel({
  title,
  note = "Stay connected and check this space for updates.",
}: {
  title: string;
  note?: string;
}) {
  return (
    <div className="rounded-[28px] border border-dashed border-[color:var(--gold)]/45 bg-[color:var(--off-white)] px-6 py-12 text-center md:px-10 md:py-16">
      <div className="gef-eyebrow">Coming Soon</div>
      <h3
        className="mt-4 text-[clamp(1.6rem,3vw,2.4rem)] font-normal text-[color:var(--navy)]"
        style={{ fontFamily: "var(--font-display)" }}
      >
        {title}
      </h3>
      <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-[color:var(--ink-soft)] md:text-base">{note}</p>
    </div>
  );
}

function DetailedPastEditionPage({ event }: { event: PastEditionDetailedContent }) {
  const [tab, setTab] = useState<DetailedTab>("Overview");
  const [agendaDayIndex, setAgendaDayIndex] = useState(0);
  const [headerVisible, setHeaderVisible] = useState(true);
  const activeTabIsComingSoon = event.comingSoonTabs?.includes(tab) ?? false;
  const profileTabRef = useRef<HTMLDivElement>(null);
  useAlignedProfileNames(profileTabRef, tab);

  useEffect(() => {
    const handleHeaderVisibility = (event: Event) => {
      setHeaderVisible((event as CustomEvent<boolean>).detail);
    };
    const headerOffset = getComputedStyle(document.documentElement).getPropertyValue("--gef-header-offset").trim();
    setHeaderVisible(headerOffset !== "0px");
    window.addEventListener("gef:header-visibility", handleHeaderVisibility);
    return () => window.removeEventListener("gef:header-visibility", handleHeaderVisibility);
  }, []);

  const scrollToTabSection = () => {
    const section = document.getElementById("past-edition-tab-content");
    if (!section) return;

    const headerHeight = headerVisible ? (document.querySelector("header")?.getBoundingClientRect().height ?? 80) : 0;
    const tabBarHeight = document.getElementById("past-edition-sections")?.getBoundingClientRect().height ?? 64;
    const targetTop = section.getBoundingClientRect().top + window.scrollY - headerHeight - tabBarHeight - 16;
    window.scrollTo({ top: Math.max(0, targetTop), behavior: "smooth" });
  };

  return (
    <>
      <section className="relative overflow-hidden bg-[color:var(--navy-deep)]">
        <img src={event.image} alt={`${event.name} cover`} className="absolute inset-0 h-full w-full object-cover opacity-35" width={1600} height={1000} />
        <div className="absolute inset-0" style={{ background: "var(--gradient-hero-overlay)" }} />
        <div className="gef-container relative pb-10 pt-8 md:pb-14 md:pt-10">
          <Link to="/past-editions" className="inline-flex items-center gap-2 text-sm text-white/80 hover:text-white">
            <ArrowLeft className="h-4 w-4" /> Past Editions
          </Link>
          <span className="gef-eyebrow mt-4 text-[color:var(--gold-light)]">{event.heroEyebrow}</span>
          <h1 className="mt-3 max-w-4xl text-[clamp(2.1rem,5vw,4.1rem)] font-normal leading-[1.02] text-white">{event.name}</h1>
          <div className="mt-4 flex flex-wrap gap-x-6 gap-y-2 text-sm text-white/80 md:text-base">
            <span className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-[color:var(--gold-light)]" />
              {event.date}
            </span>
            <span className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-[color:var(--gold-light)]" />
              {event.city}
            </span>
            <span className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-[color:var(--gold-light)]" />
              {event.venue}
            </span>
          </div>
          <p className="mt-4 max-w-3xl text-base text-white/82 md:text-lg">{event.heroDescription}</p>
        </div>
      </section>

      <section className="border-b border-[color:var(--hairline)] bg-white">
        <div
          className={`gef-container grid gap-4 py-8 ${
            event.impactStats.length >= 6 ? "grid-cols-2 md:grid-cols-3 xl:grid-cols-6" : "grid-cols-2 sm:grid-cols-3"
          }`}
        >
          {event.impactStats.map((item) => (
            <div key={item.label} className="text-center xl:text-left">
              <div className="text-2xl text-[color:var(--gold-dark)] md:text-3xl" style={{ fontFamily: "var(--font-display)" }}>
                {item.value}
              </div>
              <div className="mt-1 text-xs uppercase tracking-[0.15em] text-[color:var(--ink-muted)]">
                {item.label}
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="gef-section !py-6 md:!py-8">
        {event.about.featuredVideoUrl ? (
          <div className="gef-container grid gap-10 lg:grid-cols-[1.1fr_1fr] lg:items-start">
            <div>
              <SectionHeading eyebrow={event.about.eyebrow} title={event.about.title} subtitle={event.about.subtitle} />
              <p className="mt-6 text-[color:var(--ink-soft)] md:text-lg">{event.about.body}</p>
            </div>
            <div className="overflow-hidden rounded-[26px] border border-[color:var(--hairline)] bg-[color:var(--navy)] shadow-[0_18px_50px_-24px_rgba(5,43,87,0.35)]">
              <div className="aspect-video">
                <iframe
                  title={`${event.name} featured video`}
                  src={event.about.featuredVideoUrl}
                  className="h-full w-full"
                  loading="lazy"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  referrerPolicy="strict-origin-when-cross-origin"
                />
              </div>
            </div>
          </div>
        ) : (
          <div className="gef-container">
            <div className="max-w-4xl">
              <SectionHeading eyebrow={event.about.eyebrow} title={event.about.title} subtitle={event.about.subtitle} />
              <p className="mt-6 text-[color:var(--ink-soft)] md:text-lg">{event.about.body}</p>
            </div>
          </div>
        )}
      </section>

      <section className="gef-section bg-[color:var(--off-white)]">
        <div ref={profileTabRef} className="gef-container">
          <SectionHeading eyebrow="Key Highlights" title={`What made the ${event.city.split(",")[0]} edition stand out.`} />
          {event.highlights.length ? (
            <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {event.highlights.map((highlight) => {
                const Icon = HIGHLIGHT_ICONS[highlight.icon];
                return (
                  <div key={highlight.title} className="gef-card">
                    <div className="grid h-11 w-11 place-items-center rounded-full bg-[color:var(--gold-soft)]">
                      <Icon className="h-5 w-5 text-[color:var(--gold-dark)]" />
                    </div>
                    <h3 className="mt-5 text-lg font-semibold text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)", fontWeight: 500 }}>
                      {highlight.title}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-[color:var(--ink-soft)]">{highlight.desc}</p>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="mt-10">
              <ComingSoonPanel title="Detailed highlights are coming soon" />
            </div>
          )}
        </div>
      </section>

      <section
        id="past-edition-sections"
        className="sticky z-30 border-b border-[color:var(--hairline)] bg-white/92 backdrop-blur transition-[top] duration-300 ease-out"
        style={{ top: headerVisible ? "5rem" : "0px" }}
      >
        <div className="gef-container">
          <div className="flex gap-3 overflow-x-auto py-4">
            {DETAILED_TABS.map((t) => (
              <button
                key={t}
                onClick={() => {
                  setTab(t);
                  if (t === "Agenda") setAgendaDayIndex(0);
                  window.setTimeout(scrollToTabSection, 0);
                }}
                className={`rounded-full border px-5 py-2.5 text-sm font-medium whitespace-nowrap transition-all md:px-6 md:text-[15px] ${
                  tab === t
                    ? "border-[color:var(--navy)] bg-[color:var(--navy)] text-white shadow-[0_12px_28px_-18px_rgba(5,43,87,0.55)]"
                    : "border-[color:var(--hairline)] bg-[color:var(--off-white)] text-[color:var(--ink-soft)] hover:border-[color:var(--gold)] hover:bg-white hover:text-[color:var(--navy)]"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section id="past-edition-tab-content" className="gef-section !py-6 md:!py-8">
        <div className="gef-container">
          {activeTabIsComingSoon ? (
            <ComingSoonPanel
              title={`${tab} coming soon`}
            />
          ) : null}

          {!activeTabIsComingSoon && tab === "Overview" && (
            <div className="grid gap-10 lg:grid-cols-[1.15fr_0.85fr]">
              <div>
                <SectionHeading eyebrow={event.overview.eyebrow} title={event.overview.title} />
                <div className="mt-6 space-y-4 text-[color:var(--ink-soft)] md:text-lg">
                  {event.overview.paragraphs.map((paragraph) => (
                    <p key={paragraph}>{paragraph}</p>
                  ))}
                </div>
              </div>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1">
                {event.overview.cards.map((item) => (
                  <div key={item.title} className="rounded-2xl border border-[color:var(--hairline)] bg-white p-5">
                    <div className="text-lg text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>
                      {item.title}
                    </div>
                    <p className="mt-2 text-sm leading-relaxed text-[color:var(--ink-soft)]">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {!activeTabIsComingSoon && tab === "Leadership" && (
            <div>
              <SectionHeading eyebrow="Leadership" title={`People behind the ${event.city.split(",")[0]} edition.`} />
              <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5">
                {event.leadershipCards.map((leader) => (
                  <PastEditionProfileCard
                    key={leader.name}
                    profile={toDirectoryProfile(leader)}
                  />
                ))}
              </div>
            </div>
          )}

          {!activeTabIsComingSoon && tab === "Speakers" && (
            <div>
              <SectionHeading eyebrow="Speakers" title={`Speaker lineup from ${event.name}.`} />
                <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5">
                {event.speakerCards.map((speaker) => (
                  <PastEditionProfileCard
                    key={speaker.name}
                    profile={toDirectoryProfile(speaker)}
                  />
                ))}
              </div>
            </div>
          )}

          {!activeTabIsComingSoon && tab === "Agenda" && (
            <div>
              {/* Compact sticky Day 1 / Day 2 pill tabs */}
              {event.agenda.length > 1 && (
                <div
                  className="sticky z-20 -mx-4 mb-6 flex gap-2 border-b border-[color:var(--hairline)] bg-white/95 px-4 py-2.5 backdrop-blur transition-[top] duration-300 ease-out sm:-mx-6 sm:px-6 md:-mx-8 md:px-8"
                  style={{
                    top: headerVisible
                      ? `calc(5rem + ${document.getElementById("past-edition-sections")?.getBoundingClientRect().height ?? 64}px)`
                      : `${document.getElementById("past-edition-sections")?.getBoundingClientRect().height ?? 64}px`,
                  }}
                >
                  {event.agenda.map((day: AgendaDay, idx: number) => {
                    const isActive = agendaDayIndex === idx;
                    const dayNum = idx + 1;
                    const datePart = day.day.includes(" - ") ? day.day.split(" - ")[1] : day.day;
                    return (
                      <button
                        key={day.day}
                        onClick={() => setAgendaDayIndex(idx)}
                        className={`rounded-full border px-4 py-1.5 text-sm font-medium whitespace-nowrap transition-all duration-200 ${
                          isActive
                            ? "border-[color:var(--navy)] bg-[color:var(--navy)] text-white shadow-[0_6px_18px_-10px_rgba(5,43,87,0.55)]"
                            : "border-[color:var(--hairline)] bg-[color:var(--off-white)] text-[color:var(--ink-soft)] hover:border-[color:var(--gold)] hover:bg-white hover:text-[color:var(--navy)]"
                        }`}
                      >
                        <span className="font-semibold">Day {dayNum}</span>
                        <span className={`ml-1.5 text-xs ${isActive ? "text-white/70" : "text-[color:var(--ink-muted)]"}`}>
                          {datePart}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
              {/* Active day agenda list */}
              {(() => {
                const day = event.agenda[agendaDayIndex];
                if (!day) return null;
                return (
                  <ul className="divide-y divide-[color:var(--hairline)] rounded-2xl border border-[color:var(--hairline)] bg-white overflow-hidden">
                    {day.items.map((item: AgendaItem) => (
                      <li key={`${day.day}-${item.time}-${item.title}`} className="p-5 md:p-6 transition-colors hover:bg-[color:var(--off-white)]/40">
                        <div className="grid grid-cols-1 gap-3 md:grid-cols-[140px_1fr] lg:grid-cols-[160px_1fr_200px] lg:items-start">
                          <div>
                            <div className="font-mono text-sm font-semibold text-[color:var(--gold-dark)]">{item.time}</div>
                            {item.duration ? (
                              <div className="mt-0.5 text-xs text-[color:var(--ink-muted)]">{item.duration} Min</div>
                            ) : null}
                          </div>
                          <div>
                            <div className="flex flex-wrap items-center gap-2">
                              <h4 className="font-semibold text-[color:var(--navy)] text-base leading-snug">{item.title}</h4>
                              {item.location ? (
                                <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium ${
                                  item.location.includes("Crystal")
                                    ? "bg-amber-100 text-amber-900 border border-amber-200"
                                    : item.location.includes("Breakout")
                                    ? "bg-sky-100 text-sky-900 border border-sky-200"
                                    : "bg-slate-100 text-slate-700"
                                }`}>
                                  {item.location}
                                </span>
                              ) : null}
                            </div>
                            <div className="mt-1 text-xs uppercase tracking-[0.14em] text-[color:var(--ink-muted)] font-medium">{item.type}</div>
                            {item.tracks && item.tracks.length > 0 ? (
                              <div className="mt-3.5 space-y-2 rounded-xl bg-[color:var(--off-white)] p-3.5 border border-[color:var(--hairline)]">
                                <div className="text-xs font-semibold uppercase tracking-wider text-[color:var(--navy)] opacity-80">Track Sessions</div>
                                <ul className="space-y-1.5 text-xs text-[color:var(--ink-soft)]">
                                  {item.tracks.map((track, tIdx) => (
                                    <li key={tIdx} className="flex items-start gap-2">
                                      <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-[color:var(--gold-dark)]" />
                                      <span>{track}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            ) : null}
                          </div>
                          {item.speaker ? (
                            <div className="text-xs text-[color:var(--ink-soft)] md:text-sm">{item.speaker}</div>
                          ) : null}
                        </div>
                      </li>
                    ))}
                  </ul>
                );
              })()}
            </div>
          )}

          {!activeTabIsComingSoon && tab === "Supported By" && (
            <div>
              <SectionHeading eyebrow="Supported By" title={`Organizations that backed the ${event.city.split(",")[0]} edition.`} />
              {event.supportedByLogos?.length ? (
                <div className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  {event.supportedByLogos.map((logo) => (
                    <div
                      key={logo.src}
                      className="group flex h-24 items-center justify-center rounded-xl border border-[color:var(--hairline)] bg-white p-4 transition-all duration-300 hover:-translate-y-0.5 hover:border-[color:var(--gold)] hover:shadow-[0_10px_28px_-14px_rgba(5,43,87,0.2)]"
                    >
                      <img
                        src={logo.src}
                        alt={logo.alt}
                        loading="lazy"
                        className="h-full w-full object-contain transition-transform duration-300 group-hover:scale-[1.04]"
                      />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="mt-10 space-y-8">
                  {event.supportedBy.map((group) => (
                    <div key={group.group}>
                      <div className="mb-3 text-xs uppercase tracking-[0.18em] text-[color:var(--ink-muted)]">{group.group}</div>
                      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                        {group.items.map((item) => (
                          <div key={item} className="grid h-20 place-items-center rounded-xl border border-[color:var(--hairline)] bg-white px-4 text-center text-sm font-medium text-[color:var(--ink-soft)]">
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {!activeTabIsComingSoon && tab === "Media" && (
            <div className="space-y-12">
              {event.media.galleryImages?.length ? (
                <div>
                  <div className="flex flex-wrap items-end justify-between gap-4">
                    <SectionHeading eyebrow="Gallery" title={`Inside ${event.name}.`} />
                    <Link to="/media#gallery" className="gef-btn gef-btn-secondary">
                      Explore More <ArrowRight className="h-4 w-4" />
                    </Link>
                  </div>
                  <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {event.media.galleryImages.slice(0, 3).map((image) => (
                      <div key={image.src} className="group overflow-hidden rounded-2xl border border-[color:var(--hairline)] bg-white">
                        <div className="relative aspect-video overflow-hidden bg-[color:var(--off-white)]">
                          <img
                            src={image.src}
                            alt={image.alt}
                            loading="lazy"
                            className="h-full w-full object-contain transition-transform duration-700 group-hover:scale-[1.02]"
                            width={1200}
                            height={675}
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-[rgba(5,43,87,0.45)] to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div>
                  <SectionHeading eyebrow="Press Coverage" title={`How the ${event.city.split(",")[0]} edition was covered.`} />
                  <div className="mt-8 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
                    {event.media.pressCoverage.map((item) => (
                      <article key={item.headline} className="rounded-2xl border border-[color:var(--hairline)] bg-white p-5">
                        <div className="text-xs uppercase tracking-[0.15em] text-[color:var(--gold-dark)]">{item.pub}</div>
                        <h3 className="mt-2 text-lg text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>
                          {item.headline}
                        </h3>
                        <div className="mt-3 text-xs text-[color:var(--ink-muted)]">{item.date}</div>
                      </article>
                    ))}
                  </div>
                </div>
              )}

              {event.media.pressImages?.length ? (
                <div>
                  <div className="flex flex-wrap items-end justify-between gap-4">
                    <SectionHeading eyebrow="Press Coverage" title={`News coverage from ${event.name}.`} />
                    <Link to="/media#press-coverage" className="gef-btn gef-btn-secondary">
                      Explore More <ArrowRight className="h-4 w-4" />
                    </Link>
                  </div>
                  <div className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                    {event.media.pressImages.slice(0, 4).map((image) => (
                      <div key={image.src} className="group overflow-hidden rounded-2xl border border-[color:var(--hairline)] bg-white shadow-[0_16px_36px_-24px_rgba(5,43,87,0.28)]">
                        <div className="relative aspect-[4/5] overflow-hidden bg-[color:var(--off-white)]">
                          <img
                            src={image.src}
                            alt={image.alt}
                            loading="lazy"
                            className="h-full w-full object-contain transition-transform duration-700 group-hover:scale-[1.02]"
                            width={1200}
                            height={1500}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : event.media.pressCoverage.length ? (
                <div>
                  <div className="flex flex-wrap items-end justify-between gap-4">
                    <SectionHeading eyebrow="Press Coverage" title={`News coverage from ${event.name}.`} />
                    <Link to="/media#press-coverage" className="gef-btn gef-btn-secondary">
                      Explore More <ArrowRight className="h-4 w-4" />
                    </Link>
                  </div>
                  <div className="mt-8 grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
                    {event.media.pressCoverage.slice(0, 4).map((item) => (
                      <article key={`${item.pub}-${item.headline}`} className="rounded-2xl border border-[color:var(--hairline)] bg-white p-5 shadow-[0_16px_36px_-24px_rgba(5,43,87,0.18)]">
                        <div className="text-xs uppercase tracking-[0.15em] text-[color:var(--gold-dark)]">{item.pub}</div>
                        <h3 className="mt-2 text-lg text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>
                          {item.headline}
                        </h3>
                        <div className="mt-3 text-xs text-[color:var(--ink-muted)]">{item.date}</div>
                      </article>
                    ))}
                  </div>
                </div>
              ) : null}

              {event.mediaCoverageVideos?.length ? (
                <div>
                  <SectionHeading eyebrow="Video Coverage" title={`Watch moments from ${event.name}.`} />
                  <div className="mt-8 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
                    {event.mediaCoverageVideos.map((videoUrl, index) => (
                      <div
                        key={`${videoUrl}-${index}`}
                        className="overflow-hidden rounded-[22px] border border-[color:var(--hairline)] bg-[color:var(--navy)] shadow-[0_18px_44px_-24px_rgba(5,43,87,0.3)]"
                      >
                        <div className="aspect-video">
                          <iframe
                            title={`${event.name} video coverage ${index + 1}`}
                            src={videoUrl}
                            className="h-full w-full"
                            loading="lazy"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                            referrerPolicy="strict-origin-when-cross-origin"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : null}
            </div>
          )}
        </div>
      </section>

      {event.showBottomPreviews !== false ? (
        <>
          <section className="gef-section bg-[color:var(--off-white)]">
            <div className="gef-container">
              <div className="flex flex-wrap items-end justify-between gap-4">
                <SectionHeading eyebrow="Gallery Preview" title={`Moments from ${event.name}.`} />
                <Link to="/media" className="gef-btn gef-btn-secondary">
                  View Full Event Gallery <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
              {event.galleryPreview.length ? (
                <div className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-3">
                  {event.galleryPreview.map((image, index) => (
                    <div
                      key={`${image.src}-${index}`}
                      className={`group relative overflow-hidden rounded-2xl ${index === 0 ? "aspect-square md:col-span-2 md:row-span-2" : "aspect-square"}`}
                    >
                      <img src={image.src} alt={image.alt} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" width={1200} height={1200} />
                      <div className="absolute inset-0 bg-gradient-to-t from-[rgba(5,43,87,0.55)] to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="mt-10">
                  <ComingSoonPanel title="Gallery preview coming soon" />
                </div>
              )}
            </div>
          </section>

          <section className="gef-section">
            <div className="gef-container">
              <SectionHeading eyebrow="Media Coverage Preview" title={`Selected coverage from the ${event.city.split(",")[0]} edition.`} />
              {event.mediaCoverageVideos?.length ? (
                <div className="mt-10 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
                  {event.mediaCoverageVideos.map((videoUrl, index) => (
                    <div
                      key={`${videoUrl}-${index}`}
                      className="overflow-hidden rounded-[22px] border border-[color:var(--hairline)] bg-[color:var(--navy)] shadow-[0_18px_44px_-24px_rgba(5,43,87,0.3)]"
                    >
                      <div className="aspect-video">
                        <iframe
                          title={`${event.name} media coverage video ${index + 1}`}
                          src={videoUrl}
                          className="h-full w-full"
                          loading="lazy"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                          allowFullScreen
                          referrerPolicy="strict-origin-when-cross-origin"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              ) : null}
              {event.mediaCoveragePreview.length ? (
                <div className="mt-10 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
                  {event.mediaCoveragePreview.map((item) => (
                    <article key={`${item.pub}-${item.headline}`} className="gef-card">
                      <div className="text-xs uppercase tracking-[0.15em] text-[color:var(--gold-dark)]">{item.pub}</div>
                      <h3 className="mt-2 text-lg text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>
                        {item.headline}
                      </h3>
                      <div className="mt-3 text-xs text-[color:var(--ink-muted)]">{item.date}</div>
                    </article>
                  ))}
                </div>
              ) : (
                <div className="mt-10">
                  <ComingSoonPanel title="Media coverage preview coming soon" />
                </div>
              )}
            </div>
          </section>
        </>
      ) : null}

      <ArchiveStayUpdatedCTA />
    </>
  );
}

function toDirectoryProfile(person: PersonCard): SpeakerProfile {
  const directoryProfile = SPEAKER_PROFILES.find((profile) => profile.name === person.name);

  return {
    name: person.name,
    designation: directoryProfile?.designation ?? person.role,
    organization: directoryProfile?.organization ?? person.org,
    country: directoryProfile?.country,
    photo: directoryProfile?.photo ?? person.photo,
  };
}

function PastEditionProfileCard({
  profile,
}: {
  profile: SpeakerProfile;
}) {
  const metaLines = [profile.designation, profile.organization, profile.country].filter(
    (line): line is string => Boolean(line && line.trim()),
  );

  return (
    <article data-profile-card className="mx-auto flex h-full w-full max-w-[16rem] flex-col overflow-hidden rounded-[22px] border border-[color:var(--hairline)] bg-white text-center shadow-[0_18px_44px_-28px_rgba(5,43,87,0.18)] transition-transform duration-300 hover:-translate-y-1">
      <div className="aspect-[43/50] overflow-hidden bg-white">
        <img src={profile.photo} alt={profile.name} loading="lazy" className="h-full w-full object-contain object-center" width={258} height={300} />
      </div>
      <div className="flex flex-1 flex-col border-t border-[color:var(--hairline)] px-4 py-4 md:px-5">
        <h3
          data-profile-name
          className="min-h-[1.65rem] text-lg font-semibold leading-snug text-[color:var(--navy)]"
          style={{ fontFamily: "var(--font-display)" }}
        >
          {profile.name}
        </h3>
        <div className="mt-2 space-y-0.5 text-sm leading-relaxed text-[color:var(--ink-soft)]">
          {metaLines.map((line, index) => (
            <p
              key={`${profile.name}-${line}-${index}`}
              className={`min-h-[1.35rem] ${
                index === 0
                  ? "font-medium text-[color:var(--gold-dark)]"
                  : index === metaLines.length - 1 && profile.country === line
                    ? "uppercase tracking-[0.08em] text-[color:var(--ink-muted)]"
                    : ""
              }`}
            >
              {line}
            </p>
          ))}
        </div>
      </div>
    </article>
  );
}
