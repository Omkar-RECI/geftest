import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight, Calendar, MapPin } from "lucide-react";
import { PAST_EDITIONS_ARCHIVE } from "../../content/past-editions";
import { FinalCTA } from "../../components/gef/CTA";
import {
  breadcrumbSchema,
  collectionPageSchema,
  createSeoHead,
  itemListSchema,
} from "../../lib/seo";

export const Route = createFileRoute("/past-editions/")({
  head: () => {
    const seo = createSeoHead({
      title: "Past Global Entrepreneurs Forum Events | GEF Event Archive",
      description:
        "Explore past Global Entrepreneurs Forum events, including entrepreneurship conferences, speakers, investor interactions, startup showcases, networking, and global business collaborations.",
      path: "/past-editions",
      keywords: [
        "GEF past editions",
        "Global Entrepreneurs Forum archive",
        "GEC archive",
        "entrepreneurship event archive",
        "Pune 2025",
        "Dubai 2025",
      ],
    });

    return {
      ...seo,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@graph": [
              collectionPageSchema({
                path: "/past-editions",
                name: "GEF Past Editions",
                description:
                  "Archive of previous Global Entrepreneurs Forum and Global Entrepreneurs Conclave editions.",
              }),
              breadcrumbSchema([
                { name: "Home", path: "/" },
                { name: "Past Editions", path: "/past-editions" },
              ]),
              itemListSchema({
                name: "Past GEF Editions",
                items: PAST_EDITIONS_ARCHIVE.map((event) => ({
                  name: event.name,
                  url: `/past-editions/${event.slug}`,
                })),
              }),
            ],
          }),
        },
      ],
    };
  },
  component: PastEditions,
});

const FILTERS = ["All", "2026", "2025"] as const;

function PastEditions() {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");
  const filteredEvents = filter === "All" ? PAST_EDITIONS_ARCHIVE : PAST_EDITIONS_ARCHIVE.filter((e) => e.year === filter);

  return (
    <>
      <div className="sr-only">
        <h1>Past Editions of Global Entrepreneurs Forum</h1>
        <p>
          Official archive of past Global Entrepreneurs Forum and Global Entrepreneurs
          Conclave editions.
        </p>
      </div>
      <section className="gef-section !pt-8 md:!pt-10">
        <div className="gef-container">
          <div className="flex flex-wrap gap-2">
            {FILTERS.map((year) => (
              <button
                key={year}
                onClick={() => setFilter(year)}
                className={`rounded-full px-4 py-2 text-sm transition-colors ${
                  filter === year
                    ? "bg-[color:var(--navy)] text-white"
                    : "border border-[color:var(--hairline)] bg-white text-[color:var(--ink-soft)] hover:border-[color:var(--gold)]"
                }`}
              >
                {year}
              </button>
            ))}
          </div>
          <div className="mt-8 grid gap-8 md:grid-cols-2 xl:grid-cols-3">
            {filteredEvents.map((e) => (
              <Link
                key={e.slug}
                to="/past-editions/$slug"
                params={{ slug: e.slug }}
                className="group block overflow-hidden rounded-[24px] border border-[color:var(--hairline)] bg-white transition-all hover:-translate-y-1 hover:border-[color:var(--gold)] hover:shadow-[var(--shadow-lift)]"
              >
                <div className="relative aspect-[16/10] overflow-hidden">
                  <img
                    src={e.image}
                    alt={`${e.name} event cover`}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    width={1600}
                    height={1000}
                  />
                </div>
                <div className="p-7">
                  <h2 className="text-2xl font-normal text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>
                    {e.name}
                  </h2>
                  <div className="mt-3 flex flex-wrap gap-x-5 gap-y-2 text-sm text-[color:var(--ink-soft)]">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="h-4 w-4 text-[color:var(--gold-dark)]" />
                      {e.date}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <MapPin className="h-4 w-4 text-[color:var(--gold-dark)]" />
                      {e.city}
                    </span>
                  </div>
                  <p className="mt-4 text-sm leading-relaxed text-[color:var(--ink-soft)]">{e.summary}</p>
                  <span className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-[color:var(--gold-dark)]">
                    View Details <ArrowRight className="h-4 w-4" />
                  </span>
                </div>
              </Link>
            ))}
          </div>
          {filteredEvents.length === 0 ? (
            <div className="mt-8 rounded-2xl border border-[color:var(--hairline)] bg-white p-8 text-center text-[color:var(--ink-soft)]">
              {filter === "2026" ? "2026 editions are coming soon. Stay tuned for the next GEF chapter." : `No past editions found for ${filter}.`}
            </div>
          ) : null}
        </div>
      </section>
      <FinalCTA />
    </>
  );
}
