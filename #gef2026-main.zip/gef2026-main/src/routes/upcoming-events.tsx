import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Calendar, MapPin } from "lucide-react";
import { FinalCTA } from "../components/gef/CTA";
import { UPCOMING_EVENTS_ARCHIVE } from "../content/upcoming-events";
import {
  breadcrumbSchema,
  collectionPageSchema,
  createSeoHead,
  itemListSchema,
} from "../lib/seo";

export const Route = createFileRoute("/upcoming-events")({
  head: () => {
    const seo = createSeoHead({
      title: "Upcoming Entrepreneurship Events in India | Global Entrepreneurs Forum",
      description:
        "Explore upcoming Global Entrepreneurs Forum events, entrepreneurship conferences, business networking opportunities, speakers, partnerships, and investor connections in India.",
      path: "/upcoming-events",
      keywords: [
        "GEF upcoming events",
        "Global Entrepreneurs Forum events",
        "Global Entrepreneur Forum events",
        "entrepreneur events",
        "entrepreneurship conference India",
        "business networking events India",
        "Pune 2027",
        "future GEF editions",
      ],
    });

    return {
      ...seo,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@graph": [
              collectionPageSchema({
                path: "/upcoming-events",
                name: "Upcoming GEF Events",
                description:
                  "Explore announced upcoming Global Entrepreneurs Forum editions and planned event destinations.",
              }),
              breadcrumbSchema([
                { name: "Home", path: "/" },
                { name: "Upcoming Events", path: "/upcoming-events" },
              ]),
              itemListSchema({
                name: "Upcoming GEF Events",
                items: UPCOMING_EVENTS_ARCHIVE.map((event) => ({
                  name: event.name,
                  url: event.hasEventPage ? `/${event.slug}` : "/upcoming-events",
                })),
              }),
            ],
          }),
        },
      ],
    };
  },
  component: UpcomingEvents,
});

function UpcomingEvents() {
  const [featuredEvent, ...otherEvents] = UPCOMING_EVENTS_ARCHIVE;

  return (
    <>
      <div className="sr-only">
        <h1>Upcoming Events by Global Entrepreneurs Forum</h1>
        <p>
          Official upcoming events page for Global Entrepreneurs Forum, featuring announced
          editions and future event destinations.
        </p>
      </div>
      <section className="gef-section !pt-8 !pb-8 md:!pt-10 md:!pb-10">
        <div className="gef-container">
          <Link
            to={`/${featuredEvent.slug}`}
            aria-label={`Open the ${featuredEvent.name} event page`}
            className="group block rounded-[28px] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[color:var(--gold-dark)]"
          >
            <article className="overflow-hidden rounded-[28px] border border-[color:var(--hairline)] bg-white shadow-[0_26px_70px_-42px_rgba(5,43,87,0.22)] transition-all duration-300 group-hover:-translate-y-1 group-hover:border-[color:var(--gold)] group-hover:shadow-[0_32px_80px_-42px_rgba(5,43,87,0.3)]">
              <div className="grid items-stretch gap-0 lg:grid-cols-[1.05fr_0.95fr]">
              <div className="flex flex-col justify-center p-6 md:p-8 lg:p-10">
                <span className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[color:var(--gold-dark)]">
                  {featuredEvent.dateBadge}
                </span>
                <h1
                  className="mt-3 text-[clamp(2rem,3.4vw,3rem)] font-normal leading-[1.06] text-[color:var(--navy)]"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {featuredEvent.name}
                </h1>

                <div className="mt-5 flex flex-col gap-3 text-sm text-[color:var(--ink-soft)] md:text-[15px]">
                  <span className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-[color:var(--gold-dark)]" />
                    {featuredEvent.date}
                  </span>
                  <span className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-[color:var(--gold-dark)]" />
                    {featuredEvent.city}
                  </span>
                  <span className="text-[color:var(--ink-soft)]">{featuredEvent.venue}</span>
                </div>

                <p className="mt-6 text-sm leading-7 text-[color:var(--ink-soft)] md:text-base">
                  {featuredEvent.summary}
                </p>

                <span className="mt-7 inline-flex items-center gap-2 text-sm font-semibold text-[color:var(--gold-dark)] md:text-base">
                  View Event Page <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </span>
              </div>

              <div className="relative min-h-[260px] overflow-hidden lg:min-h-full">
                <img
                  src={featuredEvent.image}
                  alt={`${featuredEvent.name} upcoming event cover`}
                  loading="eager"
                  className="absolute inset-0 h-full w-full object-cover"
                  width={1600}
                  height={1000}
                />
                <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(5,43,87,0.14)_0%,rgba(5,43,87,0.5)_100%)]" />
                <span className="absolute left-5 top-5 rounded-full bg-white/92 px-3 py-1 text-xs font-semibold uppercase tracking-[0.14em] text-[color:var(--navy)] shadow-sm">
                  Upcoming Event
                </span>
              </div>
              </div>
            </article>
          </Link>
        </div>
      </section>

      <section className="gef-section !pt-0 md:!pt-0">
        <div className="gef-container">
          <div className="mb-8 max-w-2xl">
            <span className="gef-eyebrow">More on the Horizon</span>
            <h2 className="mt-3 text-[clamp(1.6rem,2.6vw,2.25rem)] font-normal leading-[1.08] text-[color:var(--navy)]">
              More GEF destinations taking shape across the coming editions.
            </h2>
          </div>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {otherEvents.map((event) => (
              <article
                key={event.slug}
                className="group overflow-hidden rounded-[24px] border border-[color:var(--hairline)] bg-white transition-all hover:-translate-y-1 hover:border-[color:var(--gold)] hover:shadow-[var(--shadow-lift)]"
              >
                <div className="relative aspect-[16/10] overflow-hidden">
                  <img
                    src={event.image}
                    alt={`${event.name} upcoming event cover`}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    width={1600}
                    height={1000}
                  />
                  <span className="absolute left-5 top-5 rounded-full bg-white/92 px-3 py-1 text-xs font-semibold uppercase tracking-[0.14em] text-[color:var(--navy)] shadow-sm">
                    {event.dateBadge}
                  </span>
                </div>

                <div className="p-7">
                  <h2 className="text-2xl font-normal text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>
                    {event.name}
                  </h2>

                  <div className="mt-3 flex flex-wrap gap-x-5 gap-y-2 text-sm text-[color:var(--ink-soft)]">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="h-4 w-4 text-[color:var(--gold-dark)]" />
                      {event.date}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <MapPin className="h-4 w-4 text-[color:var(--gold-dark)]" />
                      {event.city}
                    </span>
                  </div>

                  <p className="mt-4 text-sm leading-relaxed text-[color:var(--ink-soft)]">{event.summary}</p>
                  <p className="mt-3 text-sm text-[color:var(--ink-soft)]">{event.venue}</p>

                  {event.hasEventPage ? (
                    <Link
                      to={`/${event.slug}`}
                      className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-[color:var(--gold-dark)]"
                    >
                      View Event Page <ArrowRight className="h-4 w-4" />
                    </Link>
                  ) : (
                    <button
                      type="button"
                      disabled
                      className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-[color:var(--ink-soft)]/70 disabled:cursor-not-allowed"
                    >
                      View Event Page <ArrowRight className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
      <FinalCTA />
    </>
  );
}
