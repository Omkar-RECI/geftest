import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Download } from "lucide-react";
import { GALLERY, PRESS_COVERAGE_ITEMS } from "../data/gef";
import { FinalCTA, SectionHeading } from "../components/gef/CTA";
import { breadcrumbSchema, collectionPageSchema, createSeoHead, videoSchema } from "../lib/seo";

export const Route = createFileRoute("/media")({
  head: () => {
    const seo = createSeoHead({
      title: "Global Entrepreneurs Forum Gallery | GEF Events & Highlights",
      description:
        "Explore photos and highlights from Global Entrepreneurs Forum events, featuring entrepreneurs, investors, speakers, business leaders, and ecosystem partners.",
      path: "/media",
      keywords: [
        "GEF media",
        "Global Entrepreneurs Forum photos",
        "Global Entrepreneur Forum photos",
        "GEF videos",
        "event highlights",
        "press coverage",
      ],
    });

    return {
      ...seo,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@graph": [
              collectionPageSchema({
                path: "/media",
                name: "Global Entrepreneurs Forum Media & Gallery",
                description:
                  "Official media page for Global Entrepreneurs Forum photos, videos, event highlights, and press coverage.",
              }),
              breadcrumbSchema([
                { name: "Home", path: "/" },
                { name: "Media", path: "/media" },
              ]),
              videoSchema({
                name: "GEF highlight film",
                description: "Official highlight film from the Global Entrepreneurs Forum media page.",
                embedUrl: "https://www.youtube.com/embed/L6F4ILfmfog?rel=0&playsinline=1",
                pagePath: "/media",
              }),
            ],
          }),
        },
      ],
    };
  },
  component: MediaPage,
});

const FILTERS = ["All", "Pune 2025", "Dubai 2025"] as const;

function MediaPage() {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");
  const [showAllGallery, setShowAllGallery] = useState(false);
  const [showAllPress, setShowAllPress] = useState(false);
  const filteredGallery = filter === "All" ? GALLERY : GALLERY.filter((g) => g.event === filter);
  const filteredPress = filter === "All" ? PRESS_COVERAGE_ITEMS : PRESS_COVERAGE_ITEMS.filter((item) => item.event === filter);
  const hasMoreGalleryItems = filteredGallery.length > 6;
  const hasMorePressItems = filteredPress.length > 6;
  const visibleGallery = showAllGallery ? filteredGallery : filteredGallery.slice(0, 6);
  const visiblePress = showAllPress ? filteredPress : filteredPress.slice(0, 6);

  useEffect(() => {
    setShowAllGallery(false);
    setShowAllPress(false);
  }, [filter]);

  const scrollToSection = (sectionId: string) => {
    const section = document.getElementById(sectionId);
    if (!section) return;

    section.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <>
      <div className="sr-only">
        <h1>Global Entrepreneurs Forum Media and Gallery</h1>
        <p>
          Official media and gallery page for Global Entrepreneurs Forum with event photos,
          videos, and press coverage.
        </p>
      </div>
      <section className="gef-section !pt-4 !pb-8 md:!pt-6 md:!pb-10 lg:!pt-8 lg:!pb-12">
        <div className="gef-container">
          <div className="text-left">
            <div className="gef-eyebrow">Highlight Film</div>
          </div>
          <div className="relative mx-auto mt-4 w-full max-w-4xl overflow-hidden rounded-2xl bg-[color:var(--navy)] shadow-[0_18px_50px_-22px_rgba(5,43,87,0.35)]">
            <iframe
              className="h-full w-full"
              src="https://www.youtube.com/embed/L6F4ILfmfog?autoplay=1&mute=1&loop=1&playlist=L6F4ILfmfog&controls=1&rel=0&playsinline=1"
              title="GEF highlight film"
              loading="lazy"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              referrerPolicy="strict-origin-when-cross-origin"
              style={{ aspectRatio: "16 / 9", maxHeight: "70vh" }}
            />
          </div>
        </div>
      </section>

      <section id="gallery" className="gef-section !py-10 md:!py-12 lg:!py-14 bg-[color:var(--off-white)]">
        <div className="gef-container">
          <SectionHeading eyebrow="Gallery" title="Inside the room." />
          <div className="mt-8 flex flex-wrap gap-2">
            {FILTERS.map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`rounded-full px-4 py-2 text-sm transition-colors ${
                  filter === f
                    ? "bg-[color:var(--navy)] text-white"
                    : "border border-[color:var(--hairline)] bg-white text-[color:var(--ink-soft)] hover:border-[color:var(--gold)]"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
          <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {visibleGallery.map((g) => (
              <div key={g.src} className="group overflow-hidden rounded-xl border border-[color:var(--hairline)] bg-white">
                <div className="relative aspect-video overflow-hidden">
                <img
                  src={g.src}
                  alt={g.alt}
                  loading="lazy"
                  className="h-full w-full object-contain transition-transform duration-700 group-hover:scale-[1.02]"
                  width={1200}
                  height={1200}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[rgba(5,43,87,0.7)] to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                </div>
              </div>
            ))}
          </div>
          {hasMoreGalleryItems ? (
            <div className="mt-8 flex justify-center">
              <button
                type="button"
                onClick={() =>
                  setShowAllGallery((current) => {
                    const next = !current;
                    if (!next) {
                      window.setTimeout(() => scrollToSection("gallery"), 0);
                    }
                    return next;
                  })
                }
                className="gef-btn gef-btn-secondary"
              >
                {showAllGallery ? "Show Less" : "Explore More"}
              </button>
            </div>
          ) : null}
        </div>
      </section>

      <section id="press-coverage" className="gef-section !py-10 md:!py-12 lg:!py-14">
        <div className="gef-container">
          <SectionHeading eyebrow="Press Coverage" title="In the news." />
          <div className="mt-8 flex flex-wrap gap-2">
            {FILTERS.map((f) => (
              <button
                key={`press-${f}`}
                onClick={() => setFilter(f)}
                className={`rounded-full px-4 py-2 text-sm transition-colors ${
                  filter === f
                    ? "bg-[color:var(--navy)] text-white"
                    : "border border-[color:var(--hairline)] bg-white text-[color:var(--ink-soft)] hover:border-[color:var(--gold)]"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
          {visiblePress.length ? (
            <>
              <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                {visiblePress.map((item) => (
                  <div key={item.src} className="group overflow-hidden rounded-xl border border-[color:var(--hairline)] bg-white shadow-[0_16px_36px_-24px_rgba(5,43,87,0.28)]">
                    <div className="relative aspect-[4/5] overflow-hidden bg-[color:var(--off-white)]">
                      <img
                        src={item.src}
                        alt={item.alt}
                        loading="lazy"
                        className="h-full w-full object-contain transition-transform duration-700 group-hover:scale-[1.02]"
                        width={1200}
                        height={1500}
                      />
                    </div>
                  </div>
                ))}
              </div>
              {hasMorePressItems ? (
                <div className="mt-8 flex justify-center">
                  <button
                    type="button"
                    onClick={() => setShowAllPress((current) => !current)}
                    className="gef-btn gef-btn-secondary"
                  >
                    {showAllPress ? "Show Less" : "Explore More"}
                  </button>
                </div>
              ) : null}
            </>
          ) : (
            <div className="mt-6 rounded-2xl border border-dashed border-[color:var(--hairline)] bg-white px-6 py-10 text-center text-sm text-[color:var(--ink-soft)]">
              Press coverage will be added here soon.
            </div>
          )}
        </div>
      </section>

      <section className="gef-section !py-10 md:!py-12 lg:!py-14 bg-[color:var(--off-white)]">
        <div className="gef-container grid gap-8 lg:grid-cols-2">
          <SectionHeading
            eyebrow="Press Kit"
            title="Brand assets & media resources."
            subtitle="Request the GEF press kit including official logo, brand guidelines, key facts and event imagery."
          />
          <div className="rounded-2xl border border-[color:var(--hairline)] bg-white p-6 md:p-8">
            <p className="text-sm text-[color:var(--ink-soft)]">
              For media inquiries, interview requests and brand assets, contact the GEF Media Team.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link to="/contact" className="gef-btn gef-btn-primary">
                Request Media Kit <Download className="h-4 w-4" />
              </Link>
              <Link to="/contact" className="gef-btn gef-btn-secondary">
                Contact Media Team
              </Link>
            </div>
          </div>
        </div>
      </section>

      <FinalCTA />
    </>
  );
}
