import { createFileRoute } from "@tanstack/react-router";
import { SectionHeading } from "../components/gef/CTA";
import { breadcrumbSchema, createSeoHead, webpageSchema } from "../lib/seo";

export const Route = createFileRoute("/payment-refund-policy")({
  head: () => {
    const seo = createSeoHead({
      title: "Payment & Refund Policy | Global Entrepreneurs Forum (GEF)",
      description: "Payment and refund policy information for Global Entrepreneurs Forum events.",
      path: "/payment-refund-policy",
    });

    return {
      ...seo,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@graph": [
              webpageSchema({
                path: "/payment-refund-policy",
                name: "GEF Payment & Refund Policy",
                description: "Payment, cancellation, transfer and refund terms for Global Entrepreneurs Forum events.",
              }),
              breadcrumbSchema([
                { name: "Home", path: "/" },
                { name: "Payment & Refund Policy", path: "/payment-refund-policy" },
              ]),
            ],
          }),
        },
      ],
    };
  },
  component: PaymentRefundPolicyPage,
});

function PaymentRefundPolicyPage() {
  return (
    <main>
      <section className="gef-section !pt-10 !pb-12 md:!pt-14 md:!pb-16">
        <div className="gef-container max-w-3xl">
          <SectionHeading eyebrow="GEF Legal" title="Payment & Refund Policy" />
          <div className="mt-8 rounded-[24px] border border-[color:var(--hairline)] bg-white p-6 shadow-[0_18px_44px_-38px_rgba(5,43,87,0.22)] md:p-9">
            <p className="text-base leading-8 text-[color:var(--ink-soft)]">
              This policy applies to paid registrations for Global Entrepreneurs Forum events, a flagship initiative of RECI India Foundation. Event-specific terms shown during registration form part of this policy and will prevail if they differ.
            </p>
            <div className="mt-8 space-y-7">
              <PolicySection title="Registration fees and payment">
                Registration fees, inclusions, applicable taxes and payment methods are displayed during checkout. A registration is confirmed only after successful payment and confirmation from the applicable registration platform. Payments are processed by the designated third-party payment or ticketing provider; GEF does not store card or banking credentials.
              </PolicySection>
              <PolicySection title="Cancellation by a participant">
                Cancellation or refund eligibility, if any, is governed by the event-specific terms shown at registration. Where no separate cancellation window is stated, confirmed registration fees are non-refundable, except where required by applicable law or where GEF cancels the event. Requests must be sent from the registered email address before the stated deadline.
              </PolicySection>
              <PolicySection title="Transfers and substitutions">
                A delegate substitution may be considered before the event, subject to the event-specific deadline, delegate category, verification requirements and written approval from GEF. Tickets may not be transferred, sold or used for commercial resale without prior written approval.
              </PolicySection>
              <PolicySection title="Event changes, postponement or cancellation">
                GEF may reasonably modify the programme, speakers, venue, format or schedule. If an event is postponed, registrations may be moved to the revised date. If GEF cancels a paid event, the available options, including a transfer, credit or refund where applicable, will be communicated to registered delegates in accordance with applicable law.
              </PolicySection>
              <PolicySection title="Refund processing">
                Approved refunds are returned to the original payment method where possible. Processing times depend on the payment provider and financial institution. Any non-refundable third-party charges will be disclosed where applicable before a refund is processed.
              </PolicySection>
              <PolicySection title="Travel and other costs">
                GEF is not responsible for travel, accommodation, visa, insurance or other personal costs incurred by a delegate, including where an event programme or schedule changes, except where required by applicable law.
              </PolicySection>
              <PolicySection title="Chargebacks and support">
                Please contact GEF first to resolve a payment concern before initiating a chargeback. For payment, cancellation, transfer or refund requests, email{" "}
                <a className="font-semibold text-[color:var(--navy)] underline decoration-[color:var(--gold)] underline-offset-4" href="mailto:info@gefofficial.com">
                  info@gefofficial.com
                </a>{" "}
                with your registration name, event name and confirmation reference.
              </PolicySection>
              <PolicySection title="Applicable law and policy updates">
                This policy is subject to applicable law. GEF may update it before an event to reflect operational, regulatory or event-specific requirements. The version published on this page applies from its stated update date, without limiting rights that cannot be excluded under applicable law.
              </PolicySection>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

function PolicySection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section>
      <h2 className="text-xl text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>
        {title}
      </h2>
      <p className="mt-2 text-sm leading-7 text-[color:var(--ink-soft)]">{children}</p>
    </section>
  );
}
