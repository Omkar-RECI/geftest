import { createFileRoute } from "@tanstack/react-router";
import { SectionHeading } from "../components/gef/CTA";
import { breadcrumbSchema, createSeoHead, webpageSchema } from "../lib/seo";

export const Route = createFileRoute("/privacy-policy")({
  head: () => {
    const seo = createSeoHead({
      title: "Privacy Policy | Global Entrepreneurs Forum (GEF)",
      description: "Privacy Policy for the Global Entrepreneurs Forum website, a flagship initiative of RECI India Foundation.",
      path: "/privacy-policy",
    });

    return {
      ...seo,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@graph": [
              webpageSchema({
                path: "/privacy-policy",
                name: "GEF Privacy Policy",
                description: "Privacy Policy for the Global Entrepreneurs Forum website.",
              }),
              breadcrumbSchema([
                { name: "Home", path: "/" },
                { name: "Privacy Policy", path: "/privacy-policy" },
              ]),
            ],
          }),
        },
      ],
    };
  },
  component: PrivacyPolicyPage,
});

const SECTIONS = [
  {
    title: "Who this policy applies to",
    body: "This Privacy Policy applies to gefofficial.com and Global Entrepreneurs Forum (GEF) digital communications. GEF is a flagship initiative of RECI India Foundation. It explains how we handle personal information when you browse our website, contact us, or use an event registration link made available through this website.",
  },
  {
    title: "Information we may collect",
    body: "We may receive information you choose to provide, such as your name, email address, telephone number, organisation and message when you contact GEF. Our website may also collect limited technical information such as device, browser, pages visited and approximate location through cookies or analytics tools, where enabled.",
  },
  {
    title: "How we use information",
    body: "We use information to respond to enquiries, manage event interest and registrations, improve website performance, communicate relevant GEF updates where permitted, and protect the website from misuse. We do not sell personal information.",
  },
  {
    title: "Event registration and third parties",
    body: "Event registration may be completed through an embedded third-party ticketing or registration service. Information submitted within that service is handled under that provider's terms and privacy practices, in addition to this policy. Please review the provider's notices before entering payment or registration details.",
  },
  {
    title: "Sharing and retention",
    body: "We share information only where reasonably necessary to operate GEF, work with authorised service providers, meet legal obligations, or protect our rights and users. We retain information only for as long as needed for the relevant purpose, legal requirements, or legitimate operational records.",
  },
  {
    title: "Your choices",
    body: "You may request access, correction, deletion, or withdrawal of consent for personal information held by GEF, subject to applicable law and legitimate record-keeping requirements. You can also manage most browser cookies through your browser settings.",
  },
  {
    title: "Security and updates",
    body: "We use reasonable organisational and technical safeguards, but no internet transmission or storage system can be guaranteed completely secure. We may update this policy as our website, events, or legal obligations change. The updated version will be posted on this page.",
  },
];

function PrivacyPolicyPage() {
  return (
    <main>
      <section className="gef-section !pt-10 !pb-12 md:!pt-14 md:!pb-16">
        <div className="gef-container max-w-4xl">
          <SectionHeading eyebrow="GEF Legal" title="Privacy Policy" />
          <p className="mt-4 text-sm text-[color:var(--ink-muted)]">Last updated: 12 September 2026</p>
          <div className="mt-8 rounded-[24px] border border-[color:var(--hairline)] bg-white p-6 shadow-[0_18px_44px_-38px_rgba(5,43,87,0.22)] md:p-9">
            <p className="text-base leading-8 text-[color:var(--ink-soft)]">
              Global Entrepreneurs Forum respects your privacy and handles information responsibly. For privacy questions or requests, contact us at{" "}
              <a className="font-semibold text-[color:var(--navy)] underline decoration-[color:var(--gold)] underline-offset-4" href="mailto:info@gefofficial.com">
                info@gefofficial.com
              </a>.
            </p>
            <div className="mt-8 space-y-7">
              {SECTIONS.map((section) => (
                <section key={section.title}>
                  <h2 className="text-xl text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>
                    {section.title}
                  </h2>
                  <p className="mt-2 text-sm leading-7 text-[color:var(--ink-soft)]">{section.body}</p>
                </section>
              ))}
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
