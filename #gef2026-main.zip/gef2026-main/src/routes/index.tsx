import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { ArrowRight, Globe2, Sparkles, Calendar, MapPin, ChevronLeft, ChevronRight, BriefcaseBusiness, Rocket, BadgeDollarSign, Building2, Store, GraduationCap, Landmark, Lightbulb, Handshake, type LucideIcon } from "lucide-react";
import gefLogo from "../assets/gef/GEF-H-Logo.svg";
import gefIconLogo from "../assets/gef/Gef_icon_logo.svg";
import platinumPassCard from "../assets/gef/platinum-pass-card.png";
import heroSlidePune27 from "../assets/gef/Heroslides/Pune27_1.jpeg";
import heroSlidePp27 from "../assets/gef/Heroslides/PP27.jpeg";
import heroSlide2 from "../assets/gef/Heroslides/2.jpg";
import heroSlide3 from "../assets/gef/Heroslides/3.jpg";
import heroSlide4 from "../assets/gef/Heroslides/4.jpg";
import heroSlide5 from "../assets/gef/Heroslides/5.jpg";
import {
  GALLERY,
  IMPACT_STATS,
  VALUE_PILLARS,
  WHY_ATTEND,
} from "../data/gef";
import { SPEAKER_PROFILES } from "../content/speakers";
import { FinalCTA, SectionHeading } from "../components/gef/CTA";
import { UPCOMING_EVENTS_ARCHIVE } from "../content/upcoming-events";
import { useAlignedProfileNames } from "../hooks/useAlignedProfileNames";
import {
  breadcrumbSchema,
  createSeoHead,
  itemListSchema,
  webpageSchema,
} from "../lib/seo";

export const Route = createFileRoute("/")({
  head: () => {
    const seo = createSeoHead({
      title: "Global Entrepreneurs Forum (GEF) | Entrepreneurship & Business Networking",
      description:
        "Global Entrepreneurs Forum connects entrepreneurs, investors, corporates, institutions, and ecosystem leaders for networking, innovation, investment, and global business opportunities.",
      path: "/",
      keywords: [
        "Global Entrepreneurs Forum",
        "GEF",
        "Global Entrepreneur Forum",
        "official GEF website",
        "entrepreneurship forum",
        "business networking",
        "global business opportunities",
        "startup ecosystem",
        "investment network",
        "business forum",
      ],
    });

    return {
      ...seo,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@graph": [
              webpageSchema({
                path: "/",
                name: "Global Entrepreneurs Forum (GEF) Official Website",
                description:
                  "Official homepage of Global Entrepreneurs Forum connecting entrepreneurs, investors, institutions, and ecosystem leaders.",
              }),
              breadcrumbSchema([{ name: "Home", path: "/" }]),
              itemListSchema({
                name: "Upcoming GEF Events",
                items: UPCOMING_EVENTS_ARCHIVE.map((event) => ({
                  name: event.name,
                  url: event.hasEventPage ? `/${event.slug}` : "/upcoming-events",
                })),
              }),
            ],
          }),
        },
      ],
    };
  },
  component: Home,
});

type HeroSlide = {
  src: string;
  alt: string;
  to?: "/register" | "/platinum-pass";
  linkLabel?: string;
};

const SLIDES: HeroSlide[] = [
  { src: heroSlidePune27, alt: "GEF Pune 2027 hero banner", to: "/register", linkLabel: "Register for GEF Pune 2027" },
  { src: heroSlidePp27, alt: "GEF Pune 2027 hero banner", to: "/platinum-pass", linkLabel: "Explore the GEF Platinum Pass" },
  { src: heroSlide2, alt: "Global Entrepreneur Forum hero banner 2" },
  { src: heroSlide3, alt: "Global Entrepreneur Forum hero banner 3" },
  { src: heroSlide4, alt: "Global Entrepreneur Forum hero banner 4" },
  { src: heroSlide5, alt: "Global Entrepreneur Forum hero banner 5" },
];

/* const LEGACY_SLIDES = [
  { src: heroLondon, alt: "GEF London 2026 — Global Entrepreneur Forum" },
  { src: heroPune, alt: "GEC Pune 2025" },
  { src: heroDubai, alt: "GEC GEF Dubai Edition 2025" },
]; */
/* const LEGACY_HOME_KEY_FIGURES = [
  { name: "Dr. Prasad Pradhaan", role: "Leader and Senior Partner - Banking & Financial Services Industries, GCC, PwC", photo: "/Assets/Speakers/DR_Prasad_Pradhan.jpg" },
  { name: "Dr. Sanjay Paithankar", role: "Managing Director, Right Health Group, Dubai", photo: "/Assets/Speakers/Sanjay Paithankar.jpg" },
  { name: "Pramod Attarde", role: "Chief Executive Officer, Apex Defi Labs, USA", photo: "/Assets/Speakers/Pramod Attarde.jpg" },
  { name: "Prajakta Jawalekar", role: "Advocate, Supreme Court of India", photo: "/Assets/Speakers/Prajakta.jpg" },
  { name: "Sanam Arora", role: "Strategy and Transformation in Investment Management; Chair, NISAU UK", photo: "/Assets/Speakers/Sanam Arora.jpg" },
  { name: "Satish Kumar Sivan", role: "Consul General of India, Dubai, UAE", photo: "/Assets/Speakers/Satish Kumar Sivan.jpg" },
  { name: "Lew Evans", role: "CEO & Founder, Nexus Resilience Group, Dubai, UAE", photo: "/Assets/Speakers/Lew Evans.jpg" },
  { name: "Amit Garg", role: "CEO, HiLabs", photo: "/Assets/Speakers/Amit Garg.jpg" },
  { name: "Madhusudan Peshwa", role: "Chairman and Managing Director, Patil Automation Ltd.", photo: "/Assets/Speakers/Madhusudan Peshwa.jpg" },
  { name: "Dr. Neelivethil Rajeev", role: "Managing Director - MENA & APAC Specialist, Dubai, UAE", photo: "/Assets/Speakers/Neeliventhi Rajeev.jpg" },
]; */

const speakerProfileByName = new Map(SPEAKER_PROFILES.map((profile) => [profile.name, profile]));

const getHomepageProfile = (name: string) => {
  const profile = speakerProfileByName.get(name);

  if (!profile) {
    throw new Error(`Missing speaker profile for homepage key figure: ${name}`);
  }

  return profile;
};

const KEY_FIGURES = [
  getHomepageProfile("Padma Vibhushan Dr. R. A. Mashelkar"),
  getHomepageProfile("Padma Shri Prataprao Pawar"),
  getHomepageProfile("Padma Shri Dr. G. D. Yadav"),
  getHomepageProfile("Dr. Anand Deshpande"),
  getHomepageProfile("Vinod Jadhav"),
  getHomepageProfile("Prakash Bhalerao"),
  getHomepageProfile("Anand Ganu"),
  getHomepageProfile("Sundeep Waslekar"),
  getHomepageProfile("Dr. Rajendra Jagdale"),
  getHomepageProfile("Dr. Arshi Ayub Zaveri"),
  getHomepageProfile("Ujjwala Haware"),
];

type EcosystemNode = {
  id: string;
  name: string;
  description: string;
  icon: LucideIcon;
  accent: string;
  accentSoft: string;
  accentBorder: string;
  x: number;
  y: number;
};

const ECOSYSTEM_NODES: EcosystemNode[] = [
  {
    id: "partners",
    name: "Partners",
    description: "Strategic and ecosystem partners who help ideas move faster through collaboration, access, and capability support.",
    icon: Handshake,
    accent: "#b8893e",
    accentSoft: "rgba(184, 137, 62, 0.16)",
    accentBorder: "rgba(184, 137, 62, 0.5)",
    x: 12,
    y: 39,
  },
  {
    id: "investors",
    name: "Investors",
    description: "Capital partners backing scalable ideas, strategic growth, and long-term entrepreneurial value.",
    icon: BadgeDollarSign,
    accent: "#8f6bb3",
    accentSoft: "rgba(143, 107, 179, 0.16)",
    accentBorder: "rgba(143, 107, 179, 0.5)",
    x: 32,
    y: 27,
  },
  {
    id: "academia",
    name: "Academia",
    description: "Universities and knowledge institutions that nurture research, talent, and future-ready entrepreneurship.",
    icon: GraduationCap,
    accent: "#4f98a2",
    accentSoft: "rgba(79, 152, 162, 0.16)",
    accentBorder: "rgba(79, 152, 162, 0.5)",
    x: 68,
    y: 27,
  },
  {
    id: "government",
    name: "Government",
    description: "Public institutions enabling policy support, ecosystem access, and stronger foundations for enterprise growth.",
    icon: Landmark,
    accent: "#5d84b8",
    accentSoft: "rgba(93, 132, 184, 0.16)",
    accentBorder: "rgba(93, 132, 184, 0.5)",
    x: 50,
    y: 15,
  },
  {
    id: "entrepreneurs",
    name: "Entrepreneurs",
    description: "Founders and business builders driving innovation, expansion, and market creation across sectors.",
    icon: BriefcaseBusiness,
    accent: "#cf8a63",
    accentSoft: "rgba(207, 138, 99, 0.16)",
    accentBorder: "rgba(207, 138, 99, 0.5)",
    x: 68,
    y: 51,
  },
  {
    id: "corporates",
    name: "Corporates",
    description: "Enterprise leaders opening doors to partnerships, distribution, technology, and large-scale opportunity.",
    icon: Building2,
    accent: "#7b92d1",
    accentSoft: "rgba(123, 146, 209, 0.16)",
    accentBorder: "rgba(123, 146, 209, 0.5)",
    x: 32,
    y: 51,
  },
  {
    id: "startups",
    name: "Startups",
    description: "High-potential ventures bringing fresh solutions, ambitious ideas, and fast-moving innovation to the ecosystem.",
    icon: Rocket,
    accent: "#69a884",
    accentSoft: "rgba(105, 168, 132, 0.16)",
    accentBorder: "rgba(105, 168, 132, 0.5)",
    x: 88,
    y: 39,
  },
  {
    id: "innovation",
    name: "Innovation",
    description: "Innovation enablers, incubators, and accelerators connecting founders to mentorship, experimentation, and long-term momentum.",
    icon: Sparkles,
    accent: "#c0a05a",
    accentSoft: "rgba(192, 160, 90, 0.16)",
    accentBorder: "rgba(192, 160, 90, 0.5)",
    x: 50,
    y: 63,
  },
];

const AUTOPLAY_MS = 8000;

function HeroSlider() {
  const loopedSlides = [SLIDES[SLIDES.length - 1], ...SLIDES, SLIDES[0]];
  const [i, setI] = useState(1);
  const [dragX, setDragX] = useState(0);
  const [dragging, setDragging] = useState(false);
  const [transitionEnabled, setTransitionEnabled] = useState(true);
  const isAnimatingRef = useRef(false);
  const didDragRef = useRef(false);
  const startX = useRef(0);
  const width = useRef(1);
  const trackRef = useRef<HTMLDivElement>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const total = SLIDES.length;
  const activeIndex = (i - 1 + total) % total;
  const go = (n: number) => {
    if (n === i) return;
    if (isAnimatingRef.current) return;
    isAnimatingRef.current = true;
    setTransitionEnabled(true);
    setI(n);
  };
  const next = () => go(i + 1);
  const prev = () => go(i - 1);

  // Autoplay — resets whenever i changes (incl. on user interaction)
  useEffect(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => next(), AUTOPLAY_MS);
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [i]);

  useEffect(() => {
    if (transitionEnabled) return;

    const frame = window.requestAnimationFrame(() => {
      setTransitionEnabled(true);
    });

    return () => window.cancelAnimationFrame(frame);
  }, [transitionEnabled]);

  // Touch / pointer swipe
  const onDown = (clientX: number) => {
    setDragging(true);
    didDragRef.current = false;
    startX.current = clientX;
    width.current = trackRef.current?.clientWidth || 1;
  };
  const onMove = (clientX: number) => {
    if (!dragging) return;
    const distance = clientX - startX.current;
    if (Math.abs(distance) > 8) didDragRef.current = true;
    setDragX(distance);
  };
  const onUp = () => {
    if (!dragging) return;
    const threshold = width.current * 0.15;
    if (dragX < -threshold) next();
    else if (dragX > threshold) prev();
    setDragging(false);
    setDragX(0);
  };

  const onTransitionEnd = () => {
    if (i === total + 1) {
      isAnimatingRef.current = false;
      setTransitionEnabled(false);
      setI(1);
      return;
    }

    if (i === 0) {
      isAnimatingRef.current = false;
      setTransitionEnabled(false);
      setI(total);
      return;
    }

    isAnimatingRef.current = false;
  };

  const offsetPct = dragging ? (dragX / width.current) * 100 : 0;

  return (
    <section aria-label="GEF hero" className="w-full bg-[color:var(--navy-deep)]">
      <div
        ref={trackRef}
        className="relative w-full overflow-hidden bg-[color:var(--navy-deep)]"
        style={{ aspectRatio: "1343 / 492" }}
          onTouchStart={(e) => onDown(e.touches[0].clientX)}
          onTouchMove={(e) => onMove(e.touches[0].clientX)}
          onTouchEnd={onUp}
          onPointerDown={(e) => {
            if (e.pointerType === "mouse") return;
            onDown(e.clientX);
          }}
          onPointerMove={(e) => onMove(e.clientX)}
          onPointerUp={onUp}
          onPointerCancel={onUp}
        >
          <div
            onTransitionEnd={onTransitionEnd}
            className={`flex h-full w-full ${
              dragging || !transitionEnabled ? "" : "transition-transform duration-[700ms] ease-[cubic-bezier(0.22,1,0.36,1)]"
            }`}
            style={{ transform: `translate3d(calc(${-i * 100}% + ${offsetPct}%),0,0)` }}
          >
            {loopedSlides.map((s, idx) => (
              <div key={`${s.src}-${idx}`} className="relative h-full w-full shrink-0">
                <img
                  src={s.src}
                  alt={s.alt}
                  draggable={false}
                  className="absolute inset-0 h-full w-full object-cover select-none"
                  width={1343}
                  height={492}
                  loading="eager"
                  decoding="async"
                  {...(idx === 1 ? { fetchPriority: "high" as const } : {})}
                />
                {s.to ? (
                  <Link
                    to={s.to}
                    aria-label={s.linkLabel}
                    title={s.linkLabel}
                    onClick={(event) => {
                      if (didDragRef.current) {
                        event.preventDefault();
                        didDragRef.current = false;
                      }
                    }}
                    className="absolute inset-0 z-[1] cursor-pointer"
                  />
                ) : null}
              </div>
            ))}
          </div>

          {/* Arrows */}
          <button
            type="button"
            aria-label="Previous slide"
            onClick={prev}
            className="absolute left-3 top-1/2 z-10 grid h-9 w-9 -translate-y-1/2 place-items-center rounded-full bg-white/85 text-[color:var(--navy)] shadow-md backdrop-blur transition hover:bg-white md:left-6 md:h-11 md:w-11"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button
            type="button"
            aria-label="Next slide"
            onClick={next}
            className="absolute right-3 top-1/2 z-10 grid h-9 w-9 -translate-y-1/2 place-items-center rounded-full bg-white/85 text-[color:var(--navy)] shadow-md backdrop-blur transition hover:bg-white md:right-6 md:h-11 md:w-11"
          >
            <ChevronRight className="h-5 w-5" />
          </button>

          {/* Dots */}
          <div className="absolute inset-x-0 bottom-3 z-10 flex items-center justify-center gap-2">
            {SLIDES.map((_, idx) => (
              <button
                key={idx}
                aria-label={`Go to slide ${idx + 1}`}
                onClick={() => go(idx + 1)}
                className={`h-1.5 rounded-full transition-all ${idx === activeIndex ? "w-8 bg-[color:var(--gold)]" : "w-3 bg-white/60 hover:bg-white"}`}
              />
            ))}
          </div>
      </div>
    </section>
  );
}

function AnimatedNumber({ value }: { value: string }) {
  const match = value.match(/^([\d,]+)(.*)$/);
  const target = match ? parseInt(match[1].replace(/,/g, ""), 10) : 0;
  const suffix = match ? match[2] : "";
  const [n, setN] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);

  useEffect(() => {
    if (!ref.current || !target) {
      setN(target);
      return;
    }
    const el = ref.current;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting && !started.current) {
            started.current = true;
            const dur = 1600;
            const t0 = performance.now();
            const tick = (t: number) => {
              const p = Math.min(1, (t - t0) / dur);
              const eased = 1 - Math.pow(1 - p, 3);
              setN(Math.round(target * eased));
              if (p < 1) requestAnimationFrame(tick);
            };
            requestAnimationFrame(tick);
          }
        });
      },
      { threshold: 0.3 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [target]);

  return (
    <span ref={ref}>
      {n.toLocaleString()}
      {suffix}
    </span>
  );
}

function ImpactBar() {
  return (
    <section className="relative overflow-hidden" style={{ background: "var(--gradient-navy)" }}>
      <div
        className="pointer-events-none absolute inset-0 opacity-60"
        style={{
          background:
            "radial-gradient(60% 80% at 20% 0%, rgba(228,196,106,0.18), transparent 60%), radial-gradient(50% 80% at 90% 100%, rgba(228,196,106,0.12), transparent 60%)",
        }}
      />
      <div className="gef-container relative grid grid-cols-3 gap-px overflow-hidden rounded-none py-0 lg:grid-cols-6">
        {IMPACT_STATS.map((s) => (
          <div
            key={s.label}
            className="group relative px-2 py-1.5 text-center transition-colors hover:bg-white/[0.04] md:px-3 md:py-2.5 lg:px-4 lg:py-3"
          >
            <div className="font-display text-[1.3rem] tracking-tight text-[color:var(--gold-light)] md:text-[1.85rem] lg:text-[2.1rem]">
              <AnimatedNumber value={s.value} />
            </div>
            <div className="mt-0.5 text-[7px] uppercase tracking-[0.11em] leading-snug text-white/70 transition-colors group-hover:text-[color:var(--gold-light)] md:mt-1.5 md:text-[9px] lg:text-[10px]">
              {s.label}
            </div>
            <div className="mx-auto mt-1 h-px w-4 bg-[color:var(--gold)]/0 transition-all duration-500 group-hover:w-7 group-hover:bg-[color:var(--gold)] md:mt-2 md:w-6 md:group-hover:w-10" />
          </div>
        ))}
      </div>
    </section>
  );
}

function AboutBlock() {
  const videoContainerRef = useRef<HTMLDivElement>(null);
  const videoFrameRef = useRef<HTMLIFrameElement>(null);
  const isVideoInViewRef = useRef(false);

  useEffect(() => {
    const container = videoContainerRef.current;
    if (!container) return;

    const sendCommand = (command: "playVideo" | "unMute" | "pauseVideo") => {
      videoFrameRef.current?.contentWindow?.postMessage(
        JSON.stringify({ event: "command", func: command, args: [] }),
        "https://www.youtube-nocookie.com",
      );
    };

    const observer = new IntersectionObserver(
      ([entry]) => {
        isVideoInViewRef.current = entry.isIntersecting;
        if (entry.isIntersecting) {
          sendCommand("unMute");
          sendCommand("playVideo");
        } else {
          sendCommand("pauseVideo");
        }
      },
      { threshold: 0.35 },
    );

    observer.observe(container);
    return () => observer.disconnect();
  }, []);

  return (
    <section className="gef-section !py-10 md:!py-12 lg:!py-14">
      <div className="gef-container grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
        <div>
          <SectionHeading
            eyebrow="About GEF"
            title="A trusted global forum for entrepreneurship."
            subtitle="The Global Entrepreneurs Forum (GEF) is a global platform that connects the people, institutions, and ideas shaping the future of entrepreneurship, innovation, investment, trade, and economic development. By fostering meaningful dialogue and strategic collaborations, GEF creates an ecosystem where ideas become partnerships, partnerships create opportunities, and opportunities drive lasting impact."
          />
          <div className="mt-6 grid gap-4 sm:grid-cols-3">
            {VALUE_PILLARS.map((p) => (
              <div
                key={p.title}
                className="rounded-xl border border-[color:var(--hairline)] p-4 transition-all duration-300 hover:-translate-y-0.5 hover:border-[color:var(--gold)] hover:shadow-[0_10px_24px_-18px_rgba(5,43,87,0.22)]"
              >
                <div className="text-sm font-semibold text-[color:var(--navy)]">{p.title}</div>
                <p className="mt-1 text-xs leading-relaxed text-[color:var(--ink-soft)]">{p.desc}</p>
              </div>
            ))}
          </div>
          <Link to="/about-gef" className="gef-btn gef-btn-secondary mt-6">
            Learn More About GEF <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div ref={videoContainerRef} className="group relative mx-auto w-full max-w-[21rem] overflow-hidden rounded-[24px] bg-[#071a32] shadow-[0_24px_60px_-30px_rgba(5,43,87,0.45)]">
          <iframe
            ref={videoFrameRef}
            src="https://www.youtube-nocookie.com/embed/49pMpSYwgds?autoplay=0&mute=0&enablejsapi=1&playsinline=1&controls=1&loop=1&playlist=49pMpSYwgds&rel=0"
            title="Global Entrepreneurs Forum - Pune 2027"
            loading="lazy"
            className="aspect-[9/16] w-full border-0"
            allow="autoplay; encrypted-media; picture-in-picture; web-share"
            allowFullScreen
            referrerPolicy="strict-origin-when-cross-origin"
            onLoad={() => {
              if (isVideoInViewRef.current) {
                for (const command of ["unMute", "playVideo"] as const) {
                  videoFrameRef.current?.contentWindow?.postMessage(
                    JSON.stringify({ event: "command", func: command, args: [] }),
                    "https://www.youtube-nocookie.com",
                  );
                }
              }
            }}
          />
          <div className="hidden">
            <div className="gef-eyebrow">Since 2022</div>
            <p className="mt-2 text-sm leading-relaxed text-[color:var(--navy)]">
              An evolving global platform — Pune, Dubai and beyond.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function EventHighlightBlock() {
  const puneEvent = UPCOMING_EVENTS_ARCHIVE.find((event) => event.slug === "GEFPune2027");
  if (!puneEvent) return null;

  return (
    <section className="gef-section !py-10 bg-[color:var(--off-white)] md:!py-12 lg:!py-14">
      <div className="gef-container">
        <div className="overflow-hidden rounded-[28px] border border-[color:var(--hairline)] bg-white p-8 md:grid md:grid-cols-2 md:gap-12 md:p-12">
          <div>
            <span className="gef-eyebrow">Flagship Event</span>
            <h2 className="mt-4 text-[clamp(1.75rem,3.5vw,3rem)] font-normal leading-[1.1]">
              {puneEvent.name}
            </h2>
            <p className="mt-3 text-[color:var(--ink-soft)] md:text-lg">
              <strong className="font-semibold text-[color:var(--navy)]">From Rural Bharat to Global Markets:</strong>
              <br />
              a GEF Pune edition focused on connection, capital, market access, and the Viksit Bharat 2047 vision.
            </p>
            <ul className="mt-6 space-y-3 text-sm">
              <li className="flex items-center gap-3 text-[color:var(--navy)]">
                <Calendar className="h-4 w-4 text-[color:var(--gold-dark)]" /> {puneEvent.date}
              </li>
              <li className="flex items-center gap-3 text-[color:var(--navy)]">
                <MapPin className="h-4 w-4 text-[color:var(--gold-dark)]" /> {puneEvent.venue} | {puneEvent.city}
              </li>
            </ul>
            <div className="mt-7 flex flex-wrap items-center gap-3">
              <Link to="/GEFPune2027" className="gef-btn gef-btn-secondary">
                Explore the Event <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/register" className="gef-btn gef-btn-primary">
                Register Now <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
          <div className="mt-10 md:mt-0">
            <div className="relative h-full overflow-hidden rounded-2xl bg-[linear-gradient(145deg,#06264c_0%,#0b3c70_55%,#08264a_100%)] p-4 shadow-[0_24px_60px_-30px_rgba(5,43,87,0.55)] sm:p-5">
              <div className="pointer-events-none absolute -right-16 -top-20 h-56 w-56 rounded-full border border-white/10" />
              <div className="pointer-events-none absolute -bottom-24 -left-16 h-56 w-56 rounded-full border border-[color:var(--gold)]/20" />
              <div className="relative mb-4 flex items-center justify-between gap-3 px-1">
                <div>
                  <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[color:var(--gold-light)]">
                    GEF Pune 2027
                  </span>
                  <h3 className="mt-1 text-xl font-semibold text-white sm:text-2xl">
                    Register your interest
                  </h3>
                  <p className="mt-1 text-xs leading-5 text-white/70 sm:text-sm">
                    Be part of the Global Entrepreneurs Forum.
                  </p>
                </div>
                <div aria-hidden="true" className="hidden h-11 w-11 shrink-0 place-items-center rounded-full border border-[color:var(--gold-light)]/40 bg-white/10 sm:grid">
                  <Sparkles className="h-5 w-5 text-[color:var(--gold-light)]" />
                </div>
              </div>
              <div className="relative mx-auto h-[400px] max-w-[26rem] overflow-hidden rounded-xl bg-[#08264a] shadow-[0_12px_32px_-18px_rgba(0,0,0,0.55)] ring-1 ring-white/20 lg:h-[360px]">
                <iframe
                  src="https://015gy1q5wg.in8.widgets.nopaperforms.com/register?&r=&q=&w=8bec0e785b8b0b79c035bd2cf568cb06&m=&cu=https://gefofficial.com/"
                  title="Register your interest for GEF Pune 2027"
                  width="100%"
                  height="400px"
                  loading="lazy"
                  frameBorder="0"
                  sandbox="allow-top-navigation allow-scripts allow-same-origin allow-downloads allow-popups allow-popups-to-escape-sandbox"
                  className="block h-[400px] w-full border-0 bg-white"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function WhyWhoBlock() {
  const icons = [Globe2, Handshake, Lightbulb, BadgeDollarSign, Rocket, Sparkles];
  return (
    <section className="gef-section !py-10 md:!py-12 lg:!py-14">
      <div className="gef-container">
        <SectionHeading
          eyebrow="Why Attend"
          title="Why attend GEF?"
        />
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {WHY_ATTEND.map((w, i) => {
              const Icon = icons[i] ?? Globe2;
              return (
              <div key={w.title} className="group gef-card transition-all duration-300 hover:-translate-y-1 hover:border-[color:var(--gold)] hover:shadow-[0_18px_44px_-24px_rgba(5,43,87,0.2)]">
                <div className="flex items-center gap-3">
                  <div className="group/icon grid h-10 w-10 shrink-0 place-items-center rounded-full transition-all duration-300 group-hover:scale-[1.06] group-hover:bg-[color:var(--navy)]" style={{ background: "var(--gold-soft)" }}>
                    <Icon className="h-5 w-5 text-[color:var(--gold-dark)] transition-all duration-300 group-hover/icon:scale-110 group-hover/icon:-translate-y-0.5 group-hover/icon:rotate-[-6deg]" />
                  </div>
                  <h3 className="text-lg font-semibold text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)", fontWeight: 500 }}>
                    {w.title}
                  </h3>
                </div>
                <p className="mt-4 text-sm leading-relaxed text-[color:var(--ink-soft)]">{w.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// Keep the delegate and platinum-pass section ready for a future home-page release.
const SHOW_PARTICIPATION_PATHS = true;

function ParticipationPaths() {
  return (
    <section className="relative overflow-hidden bg-[linear-gradient(135deg,#031c3b_0%,#062e5b_52%,#041f41_100%)] py-9 md:py-11 lg:py-12">
      <div className="pointer-events-none absolute -left-24 top-0 h-80 w-80 rounded-full bg-[color:var(--gold)]/15 blur-3xl" />
      <div className="pointer-events-none absolute right-0 top-1/3 h-px w-1/2 bg-gradient-to-l from-transparent via-[color:var(--gold)]/55 to-transparent" />
      <div className="gef-container">
        <div className="relative mx-auto max-w-5xl text-center">
          <span className="text-[11px] font-semibold uppercase tracking-[0.24em] text-[color:var(--gold-light)]">GEF Pune 2027</span>
          <h2 className="mt-3 text-[clamp(2rem,4vw,3.4rem)] font-normal leading-tight text-white md:whitespace-nowrap" style={{ fontFamily: "var(--font-display)" }}>Choose your GEF Pune experience.</h2>
          <p className="mx-auto mt-3 max-w-2xl text-sm leading-7 text-white/72 md:text-base">Join as a delegate or apply for a more curated leadership experience.</p>
        </div>
        <div className="relative mx-auto mt-6 grid max-w-5xl gap-5 lg:grid-cols-2">
          <article className="flex flex-col justify-center rounded-[26px] border border-white/20 bg-white/[0.08] p-6 text-white shadow-[0_20px_44px_-36px_rgba(0,0,0,0.42)] backdrop-blur-sm md:p-8">
            <div className="overflow-hidden rounded-[18px]">
              <img
                src={platinumPassCard}
                alt="GEF Pune 2027 Platinum Pass, offering curated access"
                className="aspect-[1.58/1] w-full rounded-[18px] object-cover object-center"
                loading="lazy"
              />
            </div>
            <Link to="/platinum-pass" className="gef-btn mt-4 self-start border-0 bg-[color:var(--gold-light)] text-[color:var(--navy-deep)] hover:bg-white">
              Apply Now <ArrowRight className="h-4 w-4" />
            </Link>
          </article>

          <article className="rounded-[26px] border border-white/20 bg-white/[0.08] p-6 text-white shadow-[0_20px_44px_-36px_rgba(0,0,0,0.42)] backdrop-blur-sm md:p-8">
            <div className="flex items-center gap-3">
              <div className="grid h-11 w-11 place-items-center rounded-full bg-white/12">
                <Calendar className="h-5 w-5 text-[color:var(--gold-light)]" />
              </div>
              <span className="text-xs font-semibold uppercase tracking-[0.18em] text-white/60">Event Access</span>
            </div>
            <h3 className="mt-5 text-3xl font-normal text-white" style={{ fontFamily: "var(--font-display)" }}>
              Delegate Registration
            </h3>
            <p className="mt-3 max-w-md text-sm leading-7 text-white/72">
              Join the GEF Pune 2027 programme, connect with the ecosystem, and take part in the event experience.
            </p>
            <Link to="/register" className="gef-btn mt-7 border border-white/30 bg-white text-[color:var(--navy)] hover:bg-[color:var(--gold-light)]">
              Register as a Delegate <ArrowRight className="h-4 w-4" />
            </Link>
          </article>
        </div>
      </div>
    </section>
  );
}

function KeyFiguresBlock() {
  const previewProfiles = KEY_FIGURES.slice(0, 10);
  const profileGridRef = useRef<HTMLDivElement>(null);
  useAlignedProfileNames(profileGridRef);
  const getProfileMetaLines = (person: (typeof KEY_FIGURES)[number]) =>
    [person.designation, person.organization, person.country].filter(
      (line): line is string => Boolean(line && line.trim()),
    );

  return (
    <section className="gef-section !pt-8 !pb-10 bg-[color:var(--off-white)] md:!pt-10 md:!pb-12 lg:!pt-12 lg:!pb-14">
      <div className="gef-container">
        <SectionHeading
          eyebrow="Global Presence"
          title="Influential voices who have been part of the GEF journey."
          align="center"
        />

        <div ref={profileGridRef} className="mt-8 grid grid-cols-2 gap-4 sm:gap-5 lg:grid-cols-5">
          {previewProfiles.map((person) => {
            const metaLines = getProfileMetaLines(person);

            return (
              <article
                key={person.name}
                data-profile-card
                className="mx-auto flex h-full w-full max-w-[16rem] flex-col overflow-hidden rounded-[22px] border border-[color:var(--hairline)] bg-white text-center shadow-[0_18px_44px_-28px_rgba(5,43,87,0.18)] transition-transform duration-300 hover:-translate-y-1"
              >
                <div className="aspect-[43/50] overflow-hidden bg-white">
                  <img
                    src={person.photo}
                    alt={person.name}
                    loading="lazy"
                    className="h-full w-full object-contain object-center"
                    width={258}
                    height={300}
                  />
                </div>
                <div className="flex flex-1 flex-col border-t border-[color:var(--hairline)] px-4 py-4 text-center md:px-5">
                  <h3
                    data-profile-name
                    className="min-h-[1.65rem] text-lg font-semibold leading-snug text-[color:var(--navy)]"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    {person.name}
                  </h3>
                  <div className="mt-2 space-y-0.5 text-sm leading-relaxed text-[color:var(--ink-soft)]">
                    {metaLines.map((line, metaIndex) => (
                      <p
                        key={`${person.name}-${line}-${metaIndex}`}
                        className={`min-h-[1.35rem] ${
                          metaIndex === 0
                            ? "font-medium text-[color:var(--gold-dark)]"
                            : metaIndex === metaLines.length - 1 && person.country === line
                              ? "uppercase tracking-[0.08em] text-[color:var(--ink-muted)]"
                              : ""
                        }`}
                      >
                        {line}
                      </p>
                    ))}
                  </div>
                </div>
              </article>
            );
          })}
        </div>

        <div className="mt-8 flex justify-center">
          <Link to="/speakers" className="gef-btn gef-btn-secondary">
            View All <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}

function AssociatedOrganizationsBlock() {
  return (
    <section className="gef-section !py-10 md:!py-12 lg:!py-14">
      <div className="gef-container">
        <div className="overflow-hidden rounded-[32px] border border-[color:var(--hairline)] bg-white px-6 py-7 shadow-[0_28px_70px_-42px_rgba(5,43,87,0.2)] md:px-8 md:py-8 lg:px-10 lg:py-10">
          <div className="mx-auto max-w-3xl text-center">
            <span className="gef-eyebrow">GEF Pune 2027</span>
            <h2 className="mt-3 text-[clamp(1.6rem,2.6vw,2.3rem)] font-normal leading-[1.08] text-[color:var(--navy)]">
              Presenting Partner &amp; Hosted By
            </h2>
          </div>

          <div className="mt-7 grid gap-7 md:mt-8 md:grid-cols-2 md:gap-10">
            <article className="flex min-h-40 flex-col items-center justify-center gap-4 rounded-2xl border border-[color:var(--hairline)] bg-[#fbfcfe] px-5 py-6">
              <h3 className="text-sm font-bold uppercase tracking-[0.12em] text-[color:var(--navy)]">
                Presenting Partner
              </h3>
              <img
                src="/Assets/Associated-Logos/PCU.svg"
                alt="Pimpri Chinchwad University (PCU)"
                loading="lazy"
                className="h-20 w-full max-w-xs object-contain md:h-24"
              />
            </article>

            <article className="flex min-h-40 flex-col items-center justify-center gap-4 rounded-2xl border border-[color:var(--hairline)] bg-[#fbfcfe] px-5 py-6">
              <h3 className="text-sm font-bold uppercase tracking-[0.12em] text-[color:var(--navy)]">
                Hosted By
              </h3>
              <div className="grid w-full grid-cols-2 items-center justify-items-center gap-5">
                <img
                  src="/Assets/Associated-Logos/Sava_H_C.svg"
                  alt="SAVA Healthcare"
                  loading="lazy"
                  className="h-20 w-full max-w-[190px] object-contain md:h-24"
                />
                <img
                  src="/Assets/Associated-Logos/RECI_india.svg"
                  alt="RECI India"
                  loading="lazy"
                  className="h-20 w-full max-w-[190px] object-contain md:h-24"
                />
              </div>
            </article>
          </div>

          <div className="mt-6 flex justify-center">
            <Link to="/partners-sponsors" className="gef-btn gef-btn-secondary">
              Explore More <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

function EcosystemMapBlock() {
  const [activeNodeId, setActiveNodeId] = useState(ECOSYSTEM_NODES[0].id);
  const activeNode = ECOSYSTEM_NODES.find((node) => node.id === activeNodeId) ?? ECOSYSTEM_NODES[0];

  return (
    <section className="gef-section pt-0 !pb-2 md:!pb-3 lg:!pb-4">
      <div className="gef-container">
        <div
          className="relative overflow-hidden rounded-[32px] border border-[color:var(--hairline)] px-5 pb-4 pt-6 shadow-[0_32px_80px_-48px_rgba(5,43,87,0.28)] md:px-7 md:pb-5 md:pt-7 lg:px-8 lg:pb-5 lg:pt-7"
          style={{
            background:
              "linear-gradient(180deg, rgba(255,255,255,1) 0%, rgba(249,247,240,0.95) 100%)",
          }}
        >
          <div
            className="pointer-events-none absolute inset-0 opacity-70"
            style={{
              background:
                "radial-gradient(42% 42% at 50% 42%, rgba(228,196,106,0.18), transparent 72%), radial-gradient(55% 60% at 20% 18%, rgba(5,43,87,0.05), transparent 72%), radial-gradient(55% 60% at 82% 82%, rgba(5,43,87,0.06), transparent 72%)",
            }}
          />

          <div className="relative mx-auto max-w-[52rem] text-center">
            <span className="gef-eyebrow">The GEF Ecosystem</span>
            <h2 className="mt-3 text-[clamp(1.65rem,2.7vw,2.35rem)] font-normal leading-[1.05] text-[color:var(--navy)]">
              One Platform. Endless Connections.
            </h2>
          </div>

          <div className="relative mt-5 lg:mt-5">
            <div className="hidden items-center gap-8 lg:grid lg:grid-cols-[minmax(0,1fr)_20rem] xl:grid-cols-[minmax(0,1fr)_22rem]">
              <div className="relative mx-auto aspect-[1.16/1] w-full max-w-[42rem]">
                <svg
                  aria-hidden="true"
                  viewBox="0 0 100 100"
                  className="absolute inset-0 h-full w-full overflow-visible"
                  preserveAspectRatio="none"
                >
                  {ECOSYSTEM_NODES.map((node) => {
                    const isActive = node.id === activeNodeId;

                    return (
                      <g key={node.id}>
                        <line
                          x1="50"
                          y1="39"
                          x2={node.x}
                          y2={node.y}
                          stroke={isActive ? node.accent : "rgba(5, 43, 87, 0.14)"}
                          strokeWidth={isActive ? "0.72" : "0.42"}
                          strokeDasharray={isActive ? "0" : "1.5 1.8"}
                          className="transition-all duration-300"
                        />
                        <circle
                          cx={node.x}
                          cy={node.y}
                          r={isActive ? "0.95" : "0.5"}
                          fill={isActive ? node.accent : "rgba(5, 43, 87, 0.24)"}
                          className="transition-all duration-300"
                        />
                      </g>
                    );
                  })}
                </svg>

                  <div
                    className="group absolute left-1/2 top-[39%] h-[8.9rem] w-[9.7rem] -translate-x-1/2 -translate-y-1/2 [clip-path:polygon(25%_6%,75%_6%,100%_50%,75%_94%,25%_94%,0_50%)] p-[2.5px]"
                    style={{
                      background: "rgba(228,196,106,0.72)",
                      boxShadow: "0 18px 38px -30px rgba(5,43,87,0.16)",
                    }}
                  >
                  <div className="relative flex h-full w-full items-center justify-center bg-white [clip-path:polygon(25%_6%,75%_6%,100%_50%,75%_94%,25%_94%,0_50%)] shadow-[0_28px_60px_-36px_rgba(5,43,87,0.28)]">
                    <div
                      className="pointer-events-none absolute inset-[10%] rounded-full blur-3xl"
                      style={{ background: "rgba(228,196,106,0.14)" }}
                    />
                    <img
                      src={gefIconLogo}
                      alt="Global Entrepreneurs Forum"
                      className="relative h-auto w-[6.3rem] transition-transform duration-300 group-hover:scale-[1.06]"
                      width={190}
                      height={72}
                    />
                  </div>
                </div>

                {ECOSYSTEM_NODES.map((node) => {
                  const isActive = node.id === activeNodeId;
                  const Icon = node.icon;

                  return (
                      <button
                        key={node.id}
                        type="button"
                        onMouseEnter={() => setActiveNodeId(node.id)}
                        onFocus={() => setActiveNodeId(node.id)}
                        onClick={() => setActiveNodeId(node.id)}
                        className={`absolute h-[8.9rem] w-[9.7rem] -translate-x-1/2 -translate-y-1/2 [clip-path:polygon(25%_6%,75%_6%,100%_50%,75%_94%,25%_94%,0_50%)] p-[2.5px] transition-all duration-300 ${
                          isActive ? "scale-[1.04]" : "hover:scale-[1.02]"
                        }`}
                        style={{
                          left: `${node.x}%`,
                          top: `${node.y}%`,
                          background: isActive ? node.accent : node.accentBorder,
                          boxShadow: isActive
                            ? "0 22px 48px -34px rgba(5,43,87,0.28)"
                            : "0 18px 38px -30px rgba(5,43,87,0.16)",
                        }}
                      >
                        <div
                          className="flex h-full w-full flex-col items-center justify-center px-4 text-center transition-all duration-300 [clip-path:polygon(25%_6%,75%_6%,100%_50%,75%_94%,25%_94%,0_50%)]"
                          style={{
                            background: isActive ? `linear-gradient(180deg, ${node.accent} 0%, ${node.accent}dd 100%)` : "rgba(255,255,255,0.98)",
                            color: isActive ? "#ffffff" : "var(--navy)",
                          }}
                        >
                        <Icon
                          className="h-6 w-6"
                          style={{ color: isActive ? "#ffffff" : node.accent }}
                        />
                        <div className="mt-3 text-[1rem] font-semibold leading-tight">{node.name}</div>
                      </div>
                    </button>
                  );
                })}
              </div>

              <div
                className="rounded-[28px] border p-6 shadow-[0_26px_56px_-34px_rgba(5,43,87,0.32)] transition-all duration-300"
                style={{
                  background: `linear-gradient(180deg, ${activeNode.accent} 0%, ${activeNode.accent}e6 100%)`,
                  borderColor: activeNode.accentBorder,
                  color: "#ffffff",
                }}
              >
                <div className="flex items-center gap-3">
                  <div className="grid h-11 w-11 place-items-center rounded-full bg-white/14 backdrop-blur-sm">
                    <activeNode.icon className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-white/72">
                      Active Connection
                    </p>
                    <h3
                      className="mt-1 text-[1.35rem] font-semibold text-white"
                      style={{ fontFamily: "var(--font-display)" }}
                    >
                      {activeNode.name}
                    </h3>
                  </div>
                </div>
                <p className="mt-5 text-sm leading-relaxed text-white/86">
                  {activeNode.description}
                </p>
                <div className="mt-5 h-px w-full bg-white/18" />
                <p className="mt-4 text-xs uppercase tracking-[0.18em] text-white/70">
                  Connect | Collaborate | CO-CREATE
                </p>
              </div>
            </div>

            <div className="relative hidden min-h-[32rem] lg:hidden xl:min-h-[34rem]">
              <svg
                aria-hidden="true"
                viewBox="0 0 100 100"
                className="absolute inset-0 h-full w-full overflow-visible"
                preserveAspectRatio="none"
              >
                {ECOSYSTEM_NODES.map((node) => {
                  const isActive = node.id === activeNodeId;

                  return (
                    <g key={node.id}>
                      <line
                        x1="50"
                        y1="50"
                        x2={node.x}
                        y2={node.y}
                        stroke={isActive ? "rgba(180, 127, 17, 0.95)" : "rgba(5, 43, 87, 0.18)"}
                        strokeWidth={isActive ? "0.55" : "0.38"}
                        strokeDasharray={isActive ? "0" : "1.4 1.6"}
                        className="transition-all duration-300"
                      />
                      <circle
                        cx={node.x}
                        cy={node.y}
                        r={isActive ? "0.85" : "0.55"}
                        fill={isActive ? "rgba(180, 127, 17, 1)" : "rgba(5, 43, 87, 0.32)"}
                        className="transition-all duration-300"
                      />
                    </g>
                  );
                })}
              </svg>

                <div className="group absolute left-1/2 top-1/2 w-full max-w-[15.5rem] -translate-x-1/2 -translate-y-1/2">
                <div className="relative rounded-[28px] border border-[rgba(228,196,106,0.35)] bg-white px-6 py-6 text-center shadow-[0_30px_60px_-36px_rgba(5,43,87,0.28)]">
                  <div className="pointer-events-none absolute inset-[-14px] rounded-[40px] border border-[rgba(228,196,106,0.16)]" />
                  <div
                    className="pointer-events-none absolute left-1/2 top-1/2 h-32 w-32 -translate-x-1/2 -translate-y-1/2 rounded-full blur-3xl"
                    style={{ background: "rgba(228,196,106,0.14)" }}
                  />
                  <img
                    src={gefIconLogo}
                    alt="Global Entrepreneurs Forum"
                    className="relative mx-auto h-auto w-full max-w-[9.5rem] transition-transform duration-300 group-hover:scale-[1.06]"
                    width={190}
                    height={72}
                  />
                  <p className="mt-3 text-[11px] font-medium uppercase tracking-[0.22em] text-[color:var(--gold-dark)]">
                    Connect | Collaborate | CO-CREATE
                  </p>
                </div>
              </div>

              {ECOSYSTEM_NODES.map((node) => {
                const isActive = node.id === activeNodeId;

                return (
                  <button
                    key={node.id}
                    type="button"
                    onMouseEnter={() => setActiveNodeId(node.id)}
                    onFocus={() => setActiveNodeId(node.id)}
                    onClick={() => setActiveNodeId(node.id)}
                    className={`absolute min-w-[9.5rem] -translate-x-1/2 -translate-y-1/2 rounded-full border px-4 py-2.5 text-[13px] font-semibold shadow-[0_20px_45px_-34px_rgba(5,43,87,0.32)] transition-all duration-300 ${
                      isActive
                        ? "border-[color:var(--gold)] bg-[color:var(--navy)] text-white"
                        : "border-[color:var(--hairline)] bg-white text-[color:var(--navy)] hover:-translate-y-[52%] hover:border-[color:var(--gold)] hover:text-[color:var(--gold-dark)]"
                    }`}
                    style={{ left: `${node.x}%`, top: `${node.y}%` }}
                  >
                    {node.name}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="mt-4 lg:hidden">
              <div className="group relative mx-auto max-w-sm overflow-hidden rounded-[24px] border border-[rgba(228,196,106,0.28)] bg-white px-5 py-5 text-center shadow-[0_22px_50px_-36px_rgba(5,43,87,0.24)]">
              <div
                className="pointer-events-none absolute left-1/2 mt-2 h-24 w-24 -translate-x-1/2 rounded-full blur-3xl"
                style={{ background: "rgba(228,196,106,0.12)" }}
              />
                <div className="relative">
                  <img
                    src={gefIconLogo}
                    alt="Global Entrepreneurs Forum"
                    className="mx-auto h-auto w-full max-w-[8.5rem] transition-transform duration-300 group-hover:scale-[1.06]"
                    width={190}
                    height={72}
                  />
                <p className="mt-3 text-[10px] font-medium uppercase tracking-[0.2em] text-[color:var(--gold-dark)]">
                  Connect | Collaborate | CO-CREATE
                </p>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-3">
              {ECOSYSTEM_NODES.map((node) => {
                const isActive = node.id === activeNodeId;
                const Icon = node.icon;

                return (
                  <button
                    key={node.id}
                    type="button"
                    onClick={() => setActiveNodeId(node.id)}
                    className={`rounded-[20px] border-2 px-3 py-3 text-center transition-all duration-300 ${
                        isActive ? "text-white shadow-[0_22px_42px_-34px_rgba(5,43,87,0.5)]" : "bg-white text-[color:var(--navy)]"
                      }`}
                      style={{
                        background: isActive ? `linear-gradient(180deg, ${node.accent} 0%, ${node.accent}dd 100%)` : "rgba(255,255,255,0.98)",
                        borderColor: isActive ? node.accent : node.accentBorder,
                        boxShadow: isActive
                          ? "0 22px 42px -34px rgba(5,43,87,0.5)"
                          : `0 0 0 1.5px ${node.accentBorder}, 0 14px 30px -28px rgba(5,43,87,0.12)`,
                      }}
                    >
                    <div className="flex flex-col items-center">
                      <Icon
                        className="h-5 w-5"
                        style={{ color: isActive ? "#ffffff" : node.accent }}
                      />
                      <div className="mt-2 text-[13px] font-semibold leading-snug">{node.name}</div>
                    </div>
                  </button>
                );
              })}
            </div>

            <div
              className="mt-4 rounded-[22px] border p-4 shadow-[0_18px_44px_-34px_rgba(5,43,87,0.18)] backdrop-blur-sm transition-all duration-300"
              style={{
                background: `linear-gradient(180deg, ${activeNode.accent} 0%, ${activeNode.accent}e6 100%)`,
                borderColor: activeNode.accentBorder,
                color: "#ffffff",
              }}
            >
              <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-white/72">
                Active Connection
              </p>
              <div className="mt-3 flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-full bg-white/14">
                  <activeNode.icon className="h-5 w-5 text-white" />
                </div>
                <h3
                  className="text-[1.1rem] font-semibold text-white"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {activeNode.name}
                </h3>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-white/86">
                {activeNode.description}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function GalleryBlock() {
  return (
    <section className="gef-section !py-10 md:!py-12 lg:!py-14">
      <div className="gef-container">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <SectionHeading eyebrow="Gallery" title="Inside the GEF ecosystem." />
          <Link to="/media" className="gef-btn gef-btn-secondary !h-11">View Gallery</Link>
        </div>
        <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-4">
          {GALLERY.slice(0, 9).map((g, i) => (
            <div
              key={g.src}
              className={`group relative overflow-hidden rounded-xl ${i === 0 ? "col-span-2 row-span-2 aspect-square" : "aspect-square"}`}
            >
              <img src={g.src} alt={g.alt} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" width={1200} height={1200} />
              <div className="absolute inset-0 bg-gradient-to-t from-[rgba(5,43,87,0.6)] to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Home() {
  return (
    <>
      <div className="sr-only">
        <h1>Global Entrepreneurs Forum (GEF) Official Website</h1>
        <p>
          Global Entrepreneurs Forum, also searched as Global Entrepreneur Forum or GEF,
          connects entrepreneurs, startups, investors, institutions, and ecosystem leaders.
        </p>
      </div>
      <HeroSlider />
      <ImpactBar />
      <EventHighlightBlock />
      <AboutBlock />
      {SHOW_PARTICIPATION_PATHS ? <ParticipationPaths /> : null}
      <WhyWhoBlock />
      <EcosystemMapBlock />
      <KeyFiguresBlock />
      <AssociatedOrganizationsBlock />
      <GalleryBlock />
      <FinalCTA className="!pt-8 !pb-10 md:!pt-10 md:!pb-12 lg:!pt-12 lg:!pb-14" />
    </>
  );
}
