import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  BadgeDollarSign,
  BriefcaseBusiness,
  Building2,
  CalendarDays,
  ChevronDown,
  Globe2,
  GraduationCap,
  Handshake,
  Landmark,
  Lightbulb,
  Rocket,
  Sparkles,
  Store,
} from "lucide-react";
import {
  ACTIVE_EVENT,
  WHO_CAN_ATTEND,
} from "../data/gef";
import platinumPassCard from "../assets/gef/platinum-pass-card.png";
import { SectionHeading } from "../components/gef/CTA";
import { PlatinumPassExperience } from "./platinum-pass";
import { SPEAKER_PROFILES, type SpeakerProfile } from "../content/speakers";
import { useAlignedProfileNames } from "../hooks/useAlignedProfileNames";
import {
  breadcrumbSchema,
  createSeoHead,
  eventSchema,
  faqSchema,
  parseEventDateRange,
  webpageSchema,
} from "../lib/seo";

const EVENT_PAGE_SLUG = "GEFPune2027";
const hero = "/Assets/Events/GEF_Pune 2026/Pune2026-cover (1).webp";
const UPCOMING_EVENT_TABS = ["Overview", "Leadership", "Speakers", "Agenda", "Supported By", "Platinum Pass"] as const;
type UpcomingEventTab = (typeof UPCOMING_EVENT_TABS)[number];

const PUNE_EVENT_STATS = [
  { value: "3000+", label: "Entrepreneurs" },
  { value: "120+", label: "Speakers" },
  { value: "100+", label: "Investors & Vcs" },
  { value: "50+", label: "Partners" },
  { value: "30+", label: "Diplomats & Global Thought Leaders" },
  { value: "25+", label: "Countries Represented by Delegates" },
] as const;

const PUNE_EVENT_HIGHLIGHTS = [
  { title: "Expand Your Network", desc: "Build meaningful connections across industries and borders." },
  { title: "Discover Collaborations", desc: "Meet partners, mentors, and institutions that accelerate growth." },
  { title: "Unlock New Opportunities", desc: "Explore investments, business partnerships, and market access." },
  { title: "Accelerate Growth", desc: "Access ideas, resources, and strategies to scale your enterprise." },
  { title: "Gain Actionable Insights", desc: "Learn from global leaders, innovators, and changemakers." },
  { title: "Be Part of the Ecosystem", desc: "Join a community committed to innovation and sustainable impact." },
] as const;

const PROFILE_PLACEHOLDER = "/Assets/Speakers/Profile.jpg";
const EVENT_INTRO_IMAGE = "/Assets/Gallary/1.webp";

function leadershipProfile(
  name: string,
  {
    sourceName = name,
    designation,
    organization,
    country,
    photo,
  }: Partial<SpeakerProfile> & { sourceName?: string } = {},
): SpeakerProfile {
  const existingProfile = SPEAKER_PROFILES.find((speaker) => speaker.name === sourceName);

  return {
    name,
    designation: designation ?? existingProfile?.designation,
    organization: organization ?? existingProfile?.organization,
    country: country ?? existingProfile?.country,
    photo: photo ?? existingProfile?.photo ?? PROFILE_PLACEHOLDER,
  };
}

const PUNE_LEADERSHIP_GROUPS: { group: string; people: SpeakerProfile[] }[] = [
  {
    group: "Chief Patron",
    people: [
      leadershipProfile("Coming Soon", {
        photo: PROFILE_PLACEHOLDER,
      }),
    ],
  },
  {
    group: "Chief Mentor",
    people: [leadershipProfile("Vinod Jadhav", { sourceName: "Vinod Jadhav", photo: "/Assets/Leaders/Vinod_Jadhav.jpg" })],
  },
  {
    group: "Patrons",
    people: [
      leadershipProfile("Padma Vibhushan Dr. R. A. Mashelkar", {
        sourceName: "Padma Vibhushan Dr. R. A. Mashelkar",
      }),
      leadershipProfile("Padma Shri Prataprao Pawar", { sourceName: "Padma Shri Prataprao Pawar" }),
      leadershipProfile("Padma Shri Dr. G. D. Yadav", { sourceName: "Padma Shri Dr. G. D. Yadav" }),
      leadershipProfile("Sundeep Waslekar"),
      leadershipProfile("Dr. Anand Deshpande", { sourceName: "Dr. Anand Deshpande" }),
      leadershipProfile("Prakash Bhalerao"),
      
      leadershipProfile("Ravindra Boratkar"),
      leadershipProfile("Dr. Rajendra Jagdale"),
      leadershipProfile("Atul Shirodkar", {
        designation: "Founder & MD",
        organization: "Chourangi Group of Companies",
        photo: "/Assets/Events/GEF_Pune 2026/Leaders/Atul Shirodkar (1).jpg",
      }),
      leadershipProfile("Dr. Neelivethil Rajeev"),
      leadershipProfile("Subhash Deshmukh", {
        designation: "MLA",
        organization: "Maharashtra",
        photo: "/Assets/Events/GEF_Pune 2026/Leaders/Subhash Deshmukh.jpg",
      }),
      leadershipProfile("Anand Ganu"),
      leadershipProfile("Dr. Sanjay Paithankar"),
      
    ],
  },
  {
    group: "Convener",
    people: [
      leadershipProfile("Sachin Itkar", {
        designation: "Ecosystem Builder & Policy Strategist",
        organization: "",
        country: "",
        photo: "/Assets/Leadership/Sachin_GEF1.jpg",
      }),
      leadershipProfile("Sagar Babar", {
        designation: "Entrepreneur | Technologist | Business Coach",
        organization: "",
        country: "",
        photo: "/Assets/Leadership/Sagar_GEF1.jpg",
      }),
    ],
  },
  {
    group: "Conference Chairs",
    people: [
      leadershipProfile("Dr. Girish Desai", {
        designation: "Executive Director",
        organization: "PCET & PCU",
        photo: "/Assets/Leaders/Dr. Girish Desai.jpg",
      }),
      leadershipProfile("Ganesh Nibe", {
        designation: "Chairman, MD & CEO",
        organization: "Nibe Limited",
        photo: "/Assets/Events/GEF_Pune 2026/Leaders/Ganesh Nibe (1).jpg",
      }),
      leadershipProfile("Pankaj Ghode", {
        designation: "MD",
        organization: "Elmirate Capital",
        photo: "/Assets/Events/GEF_Pune 2026/Leaders/Pankaj Ghode.jpg",
      }),
      leadershipProfile("Rajendra Mutha", {
        designation: "Founder & Executive Chairman",
        organization: "Krsnaa Diagnostics Ltd",
        photo: "/Assets/Leaders/Rajendra Mutha (1).jpg",
      }),
    ],
  },
  {
    group: "Advisory Board",
    people: [
      leadershipProfile("Dr. Makarand Jawadekar", { designation: "Director", organization: "Pfizer", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/1 Dr. Makarand Jawadekar.jpg" }),
      
      leadershipProfile("Chandrakant Dalvi", { designation: "Chairman", organization: "Rayat Shikshan Sanstha", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/3 Chandrakant Dalvi.jpg" }),
      leadershipProfile("Sundeep Padhye", { designation: "Vice President of Salesforce", organization: "InfoBeans", country: "USA", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/5 Sandeep padhye.jpg" }),
      leadershipProfile("Ravindra Mangave", { designation: "President", organization: "MACCIA", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/6 Ravindra Mangave.jpg" }),
      leadershipProfile("Sandeep Chhetri", { designation: "CEO", organization: "Trade India", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/7 Sandeep Chhetri - Trade India.jpg" }),
      leadershipProfile("Dr. Sunil Manjarekar", { designation: "President", organization: "GMBF", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/8 Dr. Sunil Majarekar.jpg" }),
      leadershipProfile("Jitendra Joshi", { designation: "Founder & Global President", organization: "GIBF", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/9 Jitendra Joshi - GIBF.jpg" }),
      leadershipProfile("Dr. Vijaykant Mishra", { designation: "Chairman", organization: "ICTTC", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/10 VijayKant Mishra ICTTC.jpg" }),
      leadershipProfile("Vijayendra Surve", { designation: "CEO", organization: "Polaris International", country: "UAE", photo: "/Assets/Leaders/Vijayendra Surve.jpg" }),
      leadershipProfile("Dr. Ajit Ranade", { designation: "Founder", organization: "India Europe Business Desk", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/12 Ajit Ranade.jpg" }),
      leadershipProfile("Siddharth Mukne", { designation: "Founder & MD", organization: "Ergo Europe Ltd", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/13 Siddharth Mukane.jpg" }),
      leadershipProfile("Ravindra Gadgil", { designation: "Enterprise Architect & AI Researcher", organization: "OmPeg", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/Ravindra Godgil.jpg" }),
      leadershipProfile("Milind Deshmukh", { designation: "Director", organization: "SAM Building Contracting", country: "UAE" }),
      leadershipProfile("Sachin Chopda", { designation: "MD", organization: "Pushpam Group", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/16 Sachin Chopada.jpg" }),
      leadershipProfile("Milind Lunkad", { designation: "Director", organization: "Rohan Builders", photo: "/Assets/Leaders/Milind Lunkad.jpg" }),
      leadershipProfile("M. B. Kautkar", { designation: "Director", organization: "Jagruti Technical Services", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/18 M B Kautkar.jpg" }),
      leadershipProfile("Papachsorn Meepa", { designation: "Founder & Owner", organization: "Phuket9 Real Estate Development Co.", country: "Thailand", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/Papachsorn Meepa.jpg" }),
      leadershipProfile("Ujjwala Haware", { designation: "Chairperson & MD", organization: "Haware Legacy", photo: "/Assets/Leaders/Ujwala Haware.jpg" }),
      leadershipProfile("Rajesh Mhaske", { designation: "MD", organization: "Manas Automotive Systems ", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/11 Rajesh Maske.jpg" }),
      leadershipProfile("Suhas Phadnis", { designation: "Founder", organization: "S Phadnis Properties", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/22 Suhas phadnis 1.jpg" }),
      leadershipProfile("Pradnya Godbole", { designation: "CEO", organization: "deAsra Foundation", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/23 Pradnya Godbole.jpg" }),
      leadershipProfile("Anandsagar Shiralkar", { designation: "Founder & CEO", organization: "DG FutureTech India", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/Anandsagar Shiralkar.jpg" }),
      leadershipProfile("Rajesh Pokharkar", { designation: "Founder, Chairman & MD", organization: "Adhya Group", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/Rajesh Pokharkar.jpg" }),
      leadershipProfile("Pratap Nagar", { designation: "Director", organization: "Swan LNG ", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/Pratap Nagar.jpg" }),
      leadershipProfile("Sunil Kulkarni", { designation: "President", organization: "Fidel Technologies", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/Sunil Kulkarni.jpg" }),
      leadershipProfile("Rahul Tulpule", { designation: "Founder & CEO", organization: "Covenant Group", country: "UAE", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/Rahul Tulpule.jpg" }),
      leadershipProfile("Dr. Prasad Pradhaan", { country: "USA" }),
      leadershipProfile("Gaurav Gupta", { designation: "Founder & President", organization: "GTTCI Trade Chamber", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/Gaurav Gupta.jpg" }),
      leadershipProfile("Sushil Borde", { designation: "President, Strategic Initiatives & Innovation", organization: "Reliance", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/Sushil Borde.jpg" }),
      leadershipProfile("Vivek Kolhe", { designation: "MLA", organization: "Maharashtra", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/2 Vivek Kolhe.jpg" }),
      leadershipProfile("Shrinivas Deshingkar", { designation: "Founder & Chairman", organization: "ShreeTech Data ", photo: "/Assets/Events/GEF_Pune 2026/Leaders/ABoard/Shrinivas Deshingkar.jpg" }),
    ],
  },
];

const SHOW_PUNE_INVITED_SPEAKERS = true;

const PUNE_INVITED_SPEAKERS: SpeakerProfile[] = [
  { name: "Kamlesh D. Patel (Daaji)", designation: "Indian Spiritual Leader", photo: "/Assets/Events/GEF_Pune 2026/Speakers/Kamlesh D Patel.jpg" },
  { name: "Kishore Mehboobani", designation: "Former UNSC President", organization: "United Nations", country: "Singapore", photo: "/Assets/Events/GEF_Pune 2026/Speakers/Kishor Mehboobani.jpg" },
  { name: "Dr. Chinmay Pandya", designation: "Pro Vice Chancellor", organization: "DSVV", photo: "/Assets/Events/GEF_Pune 2026/Speakers/Chinmay Pandya.jpg" },
  { name: "Kamini Ramani", designation: "Former CMO", organization: "Mayfield", photo: "/Assets/Events/GEF_Pune 2026/Speakers/Kamini Ramani.jpg" },
  { name: "H.E. Dr. Lavina Ramkissoon", designation: "Co-Chair & Ambassador", organization: "AU-ASRIC Council (AI)", country: "Addis Ababa", photo: "/Assets/Events/GEF_Pune 2026/Speakers/H. E. Dr. Lavina Ramkissoon.jpg" },
  { name: "Mr. Nqabekaya Nqandela", designation: "Special Advisor", organization: "South African Government", country: "South Africa", photo: "/Assets/Events/GEF_Pune 2026/Speakers/Mr. Nqabekaya Nqandela.jpg" },
  { name: "Ms. Mbali Dawn Hlophe", designation: "Chairperson & Member", organization: "Gauteng e-Government", country: "South Africa", photo: "/Assets/Events/GEF_Pune 2026/Speakers/Honourable Ms Mbali Dawn Hlophe.jpg" },
  { name: "Mr. Choonsik Yoo", designation: "Senior AI Specialist", organization: "MLex", country: "South Korea", photo: "/Assets/Events/GEF_Pune 2026/Speakers/Mr. Choonsik Yoo.jpg" },
  { name: "Dr. Cheonkyo Park", designation: "Director General", organization: "KIAT", country: "South Korea", photo: "/Assets/Events/GEF_Pune 2026/Speakers/Dr. Cheonkyo Park.jpg" },
  { name: "Prof. Jung Ho Ahn", designation: "Professor", organization: "Seoul National University", country: "South Korea", photo: "/Assets/Events/GEF_Pune 2026/Speakers/Prof. Jung Ho Ahn.jpg" },
  { name: "Prof. Derrick Swartz", designation: "Scientific Expert", organization: "South African Government", country: "South Africa", photo: "/Assets/Events/GEF_Pune 2026/Speakers/Prof Derrick Swartz.jpg" },
];

const PUNE_AGENDA_THEMES = [
  {
    title: "Connect",
    desc: "Purposeful relationships, cross-border dialogue, and practical collaborations that help businesses move forward.",
  },
  {
    title: "Capital",
    desc: "Investment conversations, investor access, and the relationships that help ventures move from ambition to scale.",
  },
  {
    title: "Market",
    desc: "Market access, trade opportunities, and cross-border connections linking Rural Bharat with global markets.",
  },
] as const;

const PUNE_SUPPORTERS = [
  { name: "PCET", logo: "/Assets/Associated-Logos/PCET.svg" },
  { name: "SAVA Healthcare", logo: "/Assets/Associated-Logos/Sava_H_C.svg" },
  { name: "Krsnaa Diagnostics", logo: "/Assets/Associated-Logos/Krsnaa_D.svg" },
] as const;

const PUNE_ASSOCIATES = [
  { name: "SAT Club Global", logo: "/Assets/Events/GEF_Pune 2026/Associates/1_Sat_Club_Global_T.svg" },
  { name: "deAsra", logo: "/Assets/Events/GEF_Pune 2026/Associates/2_DeAsra.svg" },
  { name: "GMBF", logo: "/Assets/Events/GEF_Pune 2026/Associates/3_GMBF_G.svg" },
  { name: "IEBD", logo: "/Assets/Events/GEF_Pune 2026/Associates/4_IEBD.svg" },
  { name: "Global India Business Forum", logo: "/Assets/Events/GEF_Pune 2026/Associates/5_GIBF.svg" },
  { name: "Lokmangal", logo: "/Assets/Events/GEF_Pune 2026/Associates/6_Lokmangal.jpg" },
  { name: "Trade India", logo: "/Assets/Events/GEF_Pune 2026/Associates/7_Trade_india.svg" },
  { name: "Global India Business Corridor", logo: "/Assets/Events/GEF_Pune 2026/Associates/8_global india business coridor.jpg" },
  { name: "ICTTC", logo: "/Assets/Events/GEF_Pune 2026/Associates/9_ICTTC.jpg" },
  { name: "ILACoC", logo: "/Assets/Events/GEF_Pune 2026/Associates/10_ILACoC.jpg" },
  { name: "Garje Marathi Global", logo: "/Assets/Events/GEF_Pune 2026/Associates/11_Garaje_ Marathi.svg" },
  { name: "Rayat", logo: "/Assets/Events/GEF_Pune 2026/Associates/12_Rayat.svg" },
] as const;

const PUNE_PRESENTING_PARTNER = {
  name: "Pimpri Chinchwad University (PCU)",
  logo: "/Assets/Associated-Logos/PCU.svg",
};

const PUNE_HOSTS = [
  { name: "SAVA Healthcare", logo: "/Assets/Associated-Logos/Sava_H_C.svg" },
  { name: "RECI India", logo: "/Assets/Associated-Logos/RECI_india.svg" },
] as const;

const PUNE_TECHNOLOGY_PARTNERS = [
  { name: "Comsense", logo: "/Assets/Associated-Logos/Comsense.svg" },
  { name: "HiLabs" },
  { name: "FaceBuild", logo: "/Assets/Associated-Logos/Facebuild.png" },
] as const;

const WHY_ATTEND_ICONS = [
  Globe2,
  Handshake,
  Lightbulb,
  BadgeDollarSign,
  Rocket,
  Landmark,
];

const WHO_SHOULD_ATTEND_ICONS = [
  BriefcaseBusiness,
  Rocket,
  BadgeDollarSign,
  Store,
  Building2,
  Landmark,
  GraduationCap,
  Handshake,
];

const EVENT_FAQS = [
  {
    question: "When will GEF Pune 2027 take place?",
    answer: "GEF Pune 2027 will take place on 16 and 17 January 2027.",
  },
  {
    question: "Where will the event be held?",
    answer: "GEF Pune 2027 will be held at The Orchid Hotel, Balewadi | Pune, India.",
  },
  {
    question: "How do I register for GEF Pune 2027?",
    answer: "Registration is now open. Visit the Register page, choose your delegate category, and complete the secure registration process.",
  },
  {
    question: "Who can attend GEF Pune 2027?",
    answer: "The event is being designed for entrepreneurs, founders, investors, institutions, ecosystem partners, and business leaders. More detailed attendee information will be shared soon.",
  },
  {
    question: "Will speaker details be announced in advance?",
    answer: "Yes, the speaker lineup will be revealed in stages. Please keep checking this space as updates will be published here.",
  },
  {
    question: "Where can I find official event updates?",
    answer: "This page and the GEF Pune 2027 registration page carry the latest official event information, including registration updates and the announced venue.",
  },
];

export const Route = createFileRoute("/GEFPune2027")({
  head: () => {
    const eventDates = parseEventDateRange(ACTIVE_EVENT.date);
    const seo = createSeoHead({
      title: "GEF Pune 2027 | Global Entrepreneurs Forum | Pune, India",
      description:
        "GEF Pune 2027 takes place on 16 and 17 January 2027 at The Orchid Hotel, Balewadi | Pune, India, connecting entrepreneurs, investors, business leaders, institutions, and innovators around Connect, Capital, and Market access.",
      path: `/${EVENT_PAGE_SLUG}`,
      image: hero,
      keywords: [
        ACTIVE_EVENT.name,
        "GEF Pune 2027",
        "GEF Pune 2027",
        "upcoming entrepreneur event",
        "Global Entrepreneur Forum Pune",
        "entrepreneurship event Pune",
        "business networking Pune",
        "The Orchid Hotel, Balewadi | Pune, India",
        "Pune entrepreneur conference January 2027",
      ],
    });

    return {
      ...seo,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@graph": [
              webpageSchema({
                path: `/${EVENT_PAGE_SLUG}`,
                name: ACTIVE_EVENT.name,
                description: ACTIVE_EVENT.tagline,
              }),
              breadcrumbSchema([
                { name: "Home", path: "/" },
                { name: "Upcoming Events", path: "/upcoming-events" },
                { name: ACTIVE_EVENT.name, path: `/${EVENT_PAGE_SLUG}` },
              ]),
              eventSchema({
                path: `/${EVENT_PAGE_SLUG}`,
                name: ACTIVE_EVENT.name,
                description: ACTIVE_EVENT.tagline,
                image: hero,
                startDate: eventDates.startDate,
                endDate: eventDates.endDate,
                locationName: ACTIVE_EVENT.venue,
                locationAddress: `${ACTIVE_EVENT.venue}, ${ACTIVE_EVENT.city}`,
                eventStatus: "https://schema.org/EventScheduled",
              }),
              faqSchema(EVENT_FAQS),
            ],
          }),
        },
      ],
    };
  },
  component: ActiveEvent,
});

function ActiveEvent() {
  const [tab, setTab] = useState<UpcomingEventTab>("Overview");
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [headerVisible, setHeaderVisible] = useState(true);
  const eventTabContentRef = useRef<HTMLDivElement>(null);
  useAlignedProfileNames(eventTabContentRef, tab);

  useEffect(() => {
    const handleHeaderVisibility = (event: Event) => {
      setHeaderVisible((event as CustomEvent<boolean>).detail);
    };

    const headerOffset = getComputedStyle(document.documentElement).getPropertyValue("--gef-header-offset").trim();
    setHeaderVisible(headerOffset !== "0px");
    window.addEventListener("gef:header-visibility", handleHeaderVisibility);
    return () => window.removeEventListener("gef:header-visibility", handleHeaderVisibility);
  }, []);

  const scrollToTabSection = () => {
    const section = document.getElementById("event-tab-content");
    if (!section) return;

    const headerHeight = headerVisible ? (document.querySelector("header")?.getBoundingClientRect().height ?? 80) : 0;
    const tabBarHeight = document.getElementById("event-sections")?.getBoundingClientRect().height ?? 64;
    const targetTop = section.getBoundingClientRect().top + window.scrollY - headerHeight - tabBarHeight - 16;

    window.scrollTo({ top: Math.max(0, targetTop), behavior: "smooth" });
  };

  return (
    <>
      <section className="relative overflow-hidden bg-[color:var(--navy-deep)]">
        <img
          src={hero}
          alt={`${ACTIVE_EVENT.name} hero`}
          className="absolute inset-0 h-full w-full object-cover opacity-35"
          width={1600}
          height={1000}
        />
        <div className="absolute inset-0" style={{ background: "var(--gradient-hero-overlay)" }} />
        <div className="gef-container relative pb-10 pt-12 md:pb-14 md:pt-14">
          <span className="gef-eyebrow text-[color:var(--gold-light)]">Flagship Event</span>
          <h1 className="mt-4 max-w-3xl text-[clamp(2.1rem,5vw,4.2rem)] font-normal leading-[1.02] text-white">
            {ACTIVE_EVENT.name}
          </h1>
          <p className="mt-4 max-w-2xl text-lg text-white/80 md:text-xl">{ACTIVE_EVENT.theme}</p>
          <p className="mt-2 max-w-2xl text-white/72">{ACTIVE_EVENT.tagline}</p>
          <p className="mt-5 text-sm font-semibold uppercase tracking-[0.16em] text-[color:var(--gold-light)]">
            {ACTIVE_EVENT.date} | {ACTIVE_EVENT.city}
          </p>
          <p className="mt-1 text-sm font-medium text-white/78">
            Venue: {ACTIVE_EVENT.venue}
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/register" className="gef-btn gef-btn-primary">
              Delegate Registration
            </Link>
            <Link
              to="/platinum-pass"
              aria-label="Explore the Platinum Pass VIP experience"
              className="platinum-pass-cta gef-btn relative isolate h-auto min-h-[5.5rem] w-full max-w-[26rem] justify-between gap-3 overflow-hidden rounded-xl border border-[#f6df98] bg-[linear-gradient(135deg,#fff4ca_0%,#e8c96d_24%,#c8952e_52%,#f3dc91_77%,#d6aa48_100%)] px-4 py-3 text-left text-[#031a35] shadow-[inset_0_1px_0_rgba(255,255,255,0.85),inset_0_-2px_0_rgba(120,75,12,0.22),0_12px_24px_-12px_rgba(201,154,46,0.72)] sm:w-auto sm:min-w-[20rem]"
            >
              <span className="relative z-10 flex min-w-0 flex-col items-start leading-tight">
                <span className="text-[9px] font-bold uppercase tracking-[0.2em] text-[#67470c] sm:text-[10px]">
                  ✦ VIP EXPERIENCE ✦
                </span>
                <span className="mt-1 flex items-center gap-2 text-sm font-extrabold uppercase tracking-[0.15em] text-[#031a35] sm:text-base">
                  <Sparkles aria-hidden="true" className="h-4 w-4 shrink-0 text-[#76520b]" />
                  PLATINUM PASS
                </span>
                <span className="mt-1 text-[8px] font-semibold uppercase tracking-[0.08em] text-[#49350f] sm:text-[9px]">
                  EXCLUSIVE ACCESS · PREMIUM NETWORKING · MORE
                </span>
              </span>
              <ArrowRight
                aria-hidden="true"
                className="platinum-pass-arrow relative z-10 h-4 w-4 shrink-0 text-[#49350f]"
              />
            </Link>
          </div>
        </div>
      </section>

      <section className="border-b border-[color:var(--hairline)] bg-white">
        <div className="gef-container grid grid-cols-3 gap-x-3 gap-y-3 py-4 sm:gap-x-5 sm:gap-y-4 sm:py-5 lg:grid-cols-6 lg:py-6">
          {PUNE_EVENT_STATS.map((item) => (
            <div key={item.label} className="text-center">
              <div className="font-display text-[1.45rem] tracking-tight text-[color:var(--gold-dark)] md:text-[1.8rem]">
                {item.value}
              </div>
              <div className="mt-1 text-[10px] uppercase tracking-[0.13em] leading-snug text-[color:var(--ink-muted)]">
                {item.label}
              </div>
            </div>
          ))}
        </div>
      </section>

      <section
        id="event-sections"
        className="sticky z-30 border-b border-[color:var(--hairline)] bg-white/92 backdrop-blur transition-[top] duration-300 ease-out"
        style={{ top: headerVisible ? "5rem" : "0px" }}
      >
        <div className="gef-container">
          <div className="flex gap-3 overflow-x-auto py-4">
            {UPCOMING_EVENT_TABS.map((item) => {
              const isPlatinumPass = item === "Platinum Pass";

              return (
                <button
                  key={item}
                  onClick={() => {
                    setTab(item);
                    window.setTimeout(scrollToTabSection, 0);
                  }}
                  className={`rounded-full border px-5 py-2.5 text-sm font-medium whitespace-nowrap transition-all md:px-6 md:text-[15px] ${
                    isPlatinumPass
                      ? tab === item
                        ? "border-[#f4d77d] bg-[linear-gradient(135deg,#f7df8c_0%,#d8a531_55%,#bd7c13_100%)] text-[color:var(--navy-deep)] shadow-[0_12px_28px_-18px_rgba(132,82,8,0.6)]"
                        : "border-[#d9ae4f]/80 bg-[color:var(--gold-soft)] text-[color:var(--navy)] shadow-[0_8px_20px_-16px_rgba(132,82,8,0.48)] hover:-translate-y-0.5 hover:border-[#bd7c13] hover:bg-[color:var(--gold-light)]"
                      : tab === item
                        ? "border-[color:var(--navy)] bg-[color:var(--navy)] text-white shadow-[0_12px_28px_-18px_rgba(5,43,87,0.55)]"
                        : "border-[color:var(--hairline)] bg-[color:var(--off-white)] text-[color:var(--ink-soft)] hover:border-[color:var(--gold)] hover:bg-white hover:text-[color:var(--navy)]"
                  }`}
                >
                  {item}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      <section id="event-tab-content" className="gef-section !py-5 md:!py-7">
        <div ref={eventTabContentRef} className="gef-container">
          <EventTabContent tab={tab} />
        </div>
      </section>

      <section className="gef-section !py-5 md:!py-7 bg-[color:var(--off-white)]">
        <div className="gef-container">
          <SectionHeading eyebrow="FAQ" title="Event questions we hear most." />
          <div className="mt-8 space-y-3">
            {EVENT_FAQS.map((item, index) => (
              <div key={item.question} className="rounded-2xl border border-[color:var(--hairline)] bg-white">
                <button
                  type="button"
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                  className="flex w-full items-center justify-between gap-4 p-5 text-left"
                >
                  <span className="font-medium text-[color:var(--navy)]">{item.question}</span>
                  <ChevronDown
                    className={`h-5 w-5 shrink-0 text-[color:var(--ink-muted)] transition-transform ${
                      openFaq === index ? "rotate-180" : ""
                    }`}
                  />
                </button>
                {openFaq === index ? (
                  <div className="px-5 pb-5 text-sm leading-relaxed text-[color:var(--ink-soft)]">{item.answer}</div>
                ) : null}
              </div>
            ))}
          </div>
        </div>
      </section>

      <EventParticipationPaths />

      <aside className="fixed inset-x-3 bottom-3 z-40 mx-auto max-w-6xl rounded-2xl border border-[#d9ae4f]/55 bg-[linear-gradient(105deg,#071f3e_0%,#0b3a69_60%,#11385c_100%)] px-4 py-3 text-white shadow-[0_22px_54px_-22px_rgba(5,43,87,0.6)] sm:px-5">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[color:var(--gold-light)]">GEF Pune 2027</p>
            <p className="mt-0.5 truncate text-sm font-medium text-white sm:hidden">Registration is open</p>
            <p className="mt-0.5 hidden text-sm text-white/80 sm:block">{ACTIVE_EVENT.date} | {ACTIVE_EVENT.venue}</p>
          </div>
          <div className="hidden text-right sm:block">
            <p className="text-[10px] uppercase tracking-[0.14em] text-white/60">Registration</p>
            <p className="text-sm font-semibold text-[color:var(--gold-light)]">Open Now</p>
          </div>
          <Link
            to="/register"
            className="inline-flex h-10 shrink-0 items-center justify-center rounded-full border border-[#f4d77d] bg-[linear-gradient(135deg,#f7df8c_0%,#d8a531_55%,#bd7c13_100%)] px-4 text-sm font-bold text-[color:var(--navy-deep)] shadow-[0_12px_24px_-14px_rgba(0,0,0,0.75)] transition-all duration-200 hover:-translate-y-0.5 hover:brightness-105 hover:shadow-[0_16px_28px_-14px_rgba(0,0,0,0.85)] sm:h-11 sm:px-5"
          >
            Register Now
          </Link>
        </div>
      </aside>
      <div className="h-28 sm:h-24" />
    </>
  );
}

function EventParticipationPaths() {
  return (
    <section className="relative overflow-hidden bg-[linear-gradient(135deg,#031c3b_0%,#062e5b_52%,#041f41_100%)] py-9 md:py-11">
      <div className="pointer-events-none absolute -left-20 top-0 h-64 w-64 rounded-full bg-[color:var(--gold)]/15 blur-3xl" />
      <div className="gef-container relative">
        <div className="mx-auto max-w-5xl text-center">
          <span className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[color:var(--gold-light)]">GEF Pune 2027</span>
          <h2 className="mt-3 text-[clamp(1.85rem,4vw,3.1rem)] font-normal leading-tight text-white md:whitespace-nowrap" style={{ fontFamily: "var(--font-display)" }}>
            Choose your GEF Pune experience.
          </h2>
          <p className="mx-auto mt-2 max-w-2xl text-sm leading-7 text-white/72">Join as a delegate or apply for a more curated leadership experience.</p>
        </div>
        <div className="mx-auto mt-6 grid max-w-5xl gap-4 md:grid-cols-2">
          <article className="flex flex-col justify-center rounded-2xl bg-white/[0.06] p-4 text-left shadow-[0_24px_54px_-34px_rgba(0,0,0,0.5)] backdrop-blur-sm md:p-5">
            <div className="overflow-hidden rounded-[18px] bg-[#061a36]">
              <img
                src={platinumPassCard}
                alt="GEF Pune 2027 Platinum Pass, offering curated access"
                className="aspect-[1.58/1] w-full object-cover object-center"
                loading="lazy"
              />
            </div>
            <Link
              to="/platinum-pass"
              className="gef-btn mt-4 self-start border-0 bg-[color:var(--gold-light)] text-[color:var(--navy-deep)] hover:bg-white"
            >
              Apply Now <ArrowRight className="h-4 w-4" />
            </Link>
          </article>
          <article className="rounded-2xl border border-white/20 bg-white/[0.08] p-5 text-left text-white backdrop-blur-sm md:p-6">
            <div className="flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-full bg-white/12"><BriefcaseBusiness className="h-5 w-5 text-[color:var(--gold-light)]" /></div><span className="text-xs font-semibold uppercase tracking-[0.18em] text-white/60">Event Access</span></div>
            <h3 className="mt-4 text-2xl font-normal text-white" style={{ fontFamily: "var(--font-display)" }}>Delegate Registration</h3>
            <p className="mt-2 text-sm leading-6 text-white/72">Join the GEF Pune 2027 programme and connect with the wider ecosystem.</p>
            <Link to="/register" className="gef-btn mt-5 border border-white/30 bg-white text-[color:var(--navy)] hover:bg-[color:var(--gold-light)]">Register as a Delegate</Link>
          </article>
        </div>
      </div>
    </section>
  );
}

function EventAboutSection() {
  return (
    <section className="grid items-center gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:gap-12">
      <div>
        <span className="gef-eyebrow">About Global Entrepreneurs Forum</span>
        <h2 className="mt-4 max-w-xl text-[clamp(2rem,3.6vw,3.35rem)] font-normal leading-[1.06] text-[color:var(--navy)]">
          A forum where ambition meets opportunity.
        </h2>
        <p className="mt-5 max-w-2xl text-[color:var(--ink-soft)] md:text-lg">
          <strong className="font-semibold text-[color:var(--navy)]">Global Entrepreneurs Forum (GEF)</strong> brings entrepreneurs, investors, industry leaders, institutions, and changemakers together to build meaningful connections across sectors and borders.
        </p>
        <p className="mt-4 max-w-2xl text-[color:var(--ink-soft)] md:text-lg">
          <strong className="font-semibold text-[color:var(--navy)]">GEF Pune 2027</strong> takes place on 16 and 17 January at <strong className="font-semibold text-[color:var(--navy)]">The Orchid Hotel, Balewadi | Pune, India</strong>. Guided by <strong className="font-semibold text-[color:var(--navy)]">From Rural Bharat to Global Markets</strong>, it brings together leaders for practical collaboration around <strong className="font-semibold text-[color:var(--navy)]">Connect, Capital, and Market</strong>.
        </p>
      </div>
      <figure className="overflow-hidden rounded-[24px] border border-[color:var(--hairline)] bg-[color:var(--off-white)] shadow-[0_20px_48px_-32px_rgba(5,43,87,0.26)]">
        <img src={EVENT_INTRO_IMAGE} alt="Global Entrepreneurs Forum gathering" className="aspect-[4/3] h-full w-full object-cover" width={1200} height={900} />
      </figure>
    </section>
  );
}

function HostedBySection() {
  return (
    <section className="mt-10 bg-white md:mt-12">
      <div className="mx-auto max-w-3xl text-center">
        <span className="gef-eyebrow">GEF Pune 2027</span>
        <h2 className="mt-3 text-[clamp(1.6rem,2.6vw,2.3rem)] font-normal leading-[1.08] text-[color:var(--navy)]">
          Presenting Partner &amp; Hosted By
        </h2>
      </div>
      <div className="mt-6 grid gap-4 md:mt-7 md:grid-cols-2 md:gap-6">
        <article className="flex min-h-40 flex-col items-center justify-center gap-4 rounded-2xl border border-[color:var(--hairline)] bg-[#fbfcfe] px-5 py-6">
          <h3 className="text-sm font-bold uppercase tracking-[0.12em] text-[color:var(--navy)]">
            Presenting Partner
          </h3>
          <img
            src={PUNE_PRESENTING_PARTNER.logo}
            alt={PUNE_PRESENTING_PARTNER.name}
            loading="lazy"
            className="h-20 w-full max-w-xs object-contain md:h-24"
          />
        </article>

        <article className="flex min-h-40 flex-col items-center justify-center gap-4 rounded-2xl border border-[color:var(--hairline)] bg-[#fbfcfe] px-5 py-6">
          <h3 className="text-sm font-bold uppercase tracking-[0.12em] text-[color:var(--navy)]">
            Hosted By
          </h3>
          <div className="grid w-full grid-cols-2 items-center justify-items-center gap-5">
            {PUNE_HOSTS.map((host) => (
              <img
                key={host.name}
                src={host.logo}
                alt={host.name}
                loading="lazy"
                className="h-20 w-full max-w-[190px] object-contain md:h-24"
              />
            ))}
          </div>
        </article>
      </div>
    </section>
  );
}

function EventTabContent({ tab }: { tab: UpcomingEventTab }) {
  if (tab === "Overview") {
    return (
      <div>
        <EventAboutSection />
        <HostedBySection />
        <EventOverviewSections />
      </div>
    );
  }

  if (tab === "Leadership") {
    const chiefMentor = PUNE_LEADERSHIP_GROUPS.find((group) => group.group === "Chief Mentor")?.people[0];
    const patrons = PUNE_LEADERSHIP_GROUPS.find((group) => group.group === "Patrons")?.people ?? [];
    const conveners = PUNE_LEADERSHIP_GROUPS.find((group) => group.group === "Convener")?.people ?? [];
    const conferenceChairs = PUNE_LEADERSHIP_GROUPS.find((group) => group.group === "Conference Chairs")?.people ?? [];
    const advisoryBoard = PUNE_LEADERSHIP_GROUPS.find((group) => group.group === "Advisory Board")?.people ?? [];
    const mobileLeadershipRoles = [
      { title: "Convener", person: conveners[0] },
      { title: "Co-Convener", person: conveners[1] },
    ];

    return (
      <div className="space-y-7 md:space-y-9">
        {chiefMentor ? (
          <div className="mx-auto w-full max-w-[18rem]">
            <p className="mb-3 text-center text-xs font-semibold uppercase tracking-[0.16em] text-[color:var(--gold-deep)]">
              Chief Mentor
            </p>
            <EventProfileCard profile={chiefMentor} reserveDetailLines={2} />
          </div>
        ) : null}
        <LeadershipProfileGroup title="Patrons" people={patrons} />
        <section className="relative overflow-hidden rounded-[30px] border border-[#c4d9ea] bg-[linear-gradient(135deg,#eef8ff_0%,#e4f2fb_50%,#f7fbfe_100%)] p-5 shadow-[0_20px_48px_-40px_rgba(5,43,87,0.38)] md:p-8">
          <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-[color:var(--gold-soft)]/55 blur-3xl" />
          <div className="relative md:hidden">
            <div className="grid grid-cols-2 gap-3">
              {mobileLeadershipRoles.map(({ title, person }) =>
                person ? (
                  <div key={title} className="min-w-0">
                    <p className="text-center text-[10px] font-semibold uppercase tracking-[0.13em] text-[color:var(--gold-deep)]">
                      {title}
                    </p>
                    <div className="mt-3">
                      <EventProfileCard profile={person} />
                    </div>
                  </div>
                ) : null,
              )}
            </div>
            <div className="mt-7">
              <EventCategoryHeading title="Conference Chairs" />
              <div className="mt-4 grid grid-cols-2 gap-3">
                {conferenceChairs.map((person) => (
                  <EventProfileCard key={person.name} profile={person} />
                ))}
              </div>
            </div>
          </div>
          <div className="relative hidden gap-8 md:grid md:grid-cols-3 md:gap-x-7 md:gap-y-9">
            <LeadershipRoleCard title="Convener" person={conveners[0]} />
            <div className="rounded-2xl border border-white/80 bg-white/45 p-4 shadow-[0_14px_34px_-28px_rgba(5,43,87,0.22)] md:col-span-2 md:p-5">
              <EventCategoryHeading title="Conference Chairs" />
              <div className="mt-5 grid grid-cols-2 gap-4 md:gap-6">
                {conferenceChairs.slice(0, 2).map((person) => (
                  <EventProfileCard key={person.name} profile={person} reserveDetailLines={2} />
                ))}
              </div>
            </div>
            <LeadershipRoleCard title="Co-Convener" person={conveners[1]} />
            <div className="rounded-2xl border border-white/80 bg-white/45 p-4 shadow-[0_14px_34px_-28px_rgba(5,43,87,0.22)] md:col-span-2 md:p-5">
              <div className="invisible" aria-hidden="true">
                <EventCategoryHeading title="Conference Chairs" />
              </div>
              <div className="mt-5 grid grid-cols-2 gap-4 md:gap-6">
                {conferenceChairs.slice(2, 4).map((person) => (
                  <EventProfileCard key={person.name} profile={person} reserveDetailLines={2} />
                ))}
              </div>
            </div>
          </div>
        </section>
        <LeadershipProfileGroup title="Advisory Board" people={advisoryBoard} />
      </div>
    );
  }

  if (tab === "Speakers") {
    if (!SHOW_PUNE_INVITED_SPEAKERS) {
      return <ComingSoonPanel title="Speaker announcements are coming soon." />;
    }

    return (
      <div>
        <SectionHeading
          eyebrow="Invited Speakers & Guests"
          title="Perspectives from across the GEF ecosystem."
          align="center"
        />
        <div className="mt-8 flex flex-wrap justify-center gap-5">
          {PUNE_INVITED_SPEAKERS.map((speaker) => {
            const directoryProfile = SPEAKER_PROFILES.find((profile) => profile.name === speaker.name);
            const profile = directoryProfile ?? speaker;

            return (
            <div key={speaker.name} className="w-[calc(50%-0.625rem)] lg:w-[calc(20%-1rem)]">
              <EventProfileCard profile={profile} />
            </div>
            );
          })}
        </div>
      </div>
    );
  }

  if (tab === "Agenda") {
    return (
      <div>
        <SectionHeading eyebrow="Agenda Focus" title="Connect. Capital. Market." />
        <div className="relative mt-7 overflow-hidden rounded-2xl border border-[color:var(--gold)]/35 bg-[linear-gradient(120deg,#031a35_0%,#082f5e_62%,#0b3b70_100%)] px-5 py-6 text-white shadow-[0_20px_44px_-30px_rgba(5,43,87,0.48)] sm:px-7 sm:py-7">
          <div aria-hidden="true" className="pointer-events-none absolute -right-12 -top-16 h-48 w-48 rounded-full border border-white/10" />
          <div className="relative flex items-center gap-4 sm:gap-5">
            <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl border border-[color:var(--gold-light)]/35 bg-white/10 sm:h-14 sm:w-14">
              <CalendarDays aria-hidden="true" className="h-6 w-6 text-[color:var(--gold-light)] sm:h-7 sm:w-7" />
            </div>
            <div className="min-w-0">
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[color:var(--gold-light)]">
                Coming soon
              </span>
              <h3 className="mt-1 text-xl font-semibold leading-snug text-white sm:text-2xl">
                The event agenda is on its way.
              </h3>
              <p className="mt-1 text-sm leading-relaxed text-white/75">
                The detailed programme will be announced closer to the event. Check back for updates.
              </p>
            </div>
            <Sparkles aria-hidden="true" className="ml-auto hidden h-6 w-6 shrink-0 text-[color:var(--gold-light)] sm:block" />
          </div>
        </div>
        <div className="mt-8 grid gap-5 md:grid-cols-3">
          {PUNE_AGENDA_THEMES.map((theme) => (
            <article key={theme.title} className="rounded-2xl border border-[color:var(--hairline)] bg-white p-6 shadow-[0_18px_44px_-32px_rgba(5,43,87,0.16)]">
              <h3 className="text-xl font-semibold text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)", fontWeight: 500 }}>
                {theme.title}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-[color:var(--ink-soft)]">{theme.desc}</p>
            </article>
          ))}
        </div>
      </div>
    );
  }

  if (tab === "Supported By") {
    return (
      <div className="space-y-10 md:space-y-12">
        <HostedBySection />
        <div>
          <EventCategoryHeading title="Technology Partners" showRules={false} />
          <div className="mx-auto mt-7 grid max-w-3xl grid-cols-2 gap-4 sm:grid-cols-3 sm:gap-6">
            {PUNE_TECHNOLOGY_PARTNERS.map((partner) => (
              <div key={partner.name} className="group flex min-h-32 items-center justify-center rounded-2xl border border-[color:var(--hairline)] bg-white p-5 shadow-[0_16px_34px_-28px_rgba(5,43,87,0.22)] transition-all hover:-translate-y-0.5 hover:border-[color:var(--gold)] hover:shadow-[0_12px_28px_-22px_rgba(5,43,87,0.2)] sm:min-h-36 sm:p-7">
                {"logo" in partner ? (
                  <img src={partner.logo} alt={partner.name} loading="lazy" className="max-h-20 w-full object-contain" />
                ) : (
                  <span className="text-center text-3xl font-bold tracking-[-0.06em] text-[#1d6fd8]">Hi<span className="text-[#111111]">Labs</span></span>
                )}
              </div>
            ))}
          </div>
        </div>
        <LogoGroup title="Associates" logos={PUNE_ASSOCIATES} prominentFirstTwo />
      </div>
    );
  }

  if (tab === "Platinum Pass") {
    return <PlatinumPassExperience applicationHref="/platinum-pass#platinum-pass-application" />;
  }

  return null;
}

function EventOverviewSections() {
  return (
    <div className="mt-10 space-y-10 border-t border-[color:var(--hairline)] pt-8 md:mt-12 md:pt-10">
      <div>
        <SectionHeading eyebrow="What to Expect" title="Key Highlights of GEF Pune 2027" />
        <div className="mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {PUNE_EVENT_HIGHLIGHTS.map((item, index) => {
            const Icon = WHY_ATTEND_ICONS[index] ?? Globe2;

            return (
              <div key={item.title} className="group gef-card flex items-start gap-4">
                <div className="group/icon grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[color:var(--gold-soft)] transition-all duration-300 group-hover:scale-[1.06] group-hover:bg-[color:var(--navy)]">
                  <Icon className="h-5 w-5 text-[color:var(--gold-dark)] transition-all duration-300 group-hover/icon:scale-110 group-hover/icon:-translate-y-0.5 group-hover/icon:rotate-[-6deg] group-hover/icon:text-[color:var(--gold-light)]" />
                </div>
                <div>
                  <h3
                    className="text-lg font-semibold text-[color:var(--navy)]"
                    style={{ fontFamily: "var(--font-display)", fontWeight: 500 }}
                  >
                    {item.title}
                  </h3>
                  <p className="mt-1 text-sm text-[color:var(--ink-soft)]">{item.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="border-t border-[color:var(--hairline)] pt-8 md:pt-10">
        <SectionHeading eyebrow="The GEF Community" title="Who Should Attend" />
        <div className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {WHO_CAN_ATTEND.map((item, index) => {
            const Icon = WHO_SHOULD_ATTEND_ICONS[index % WHO_SHOULD_ATTEND_ICONS.length];

            return (
              <div
                key={item}
                className="group rounded-xl border border-[color:var(--hairline)] bg-white px-4 py-4 text-center transition-all duration-300 hover:-translate-y-0.5 hover:border-[color:var(--gold)] hover:bg-[color:var(--gold-soft)] hover:shadow-[0_14px_34px_-24px_rgba(5,43,87,0.18)]"
              >
                <div className="mx-auto grid h-10 w-10 place-items-center rounded-full bg-[color:var(--gold-soft)] transition-all duration-300 group-hover:scale-[1.06] group-hover:bg-[color:var(--navy)]">
                  <Icon className="h-5 w-5 text-[color:var(--gold-dark)] transition-all duration-300 group-hover:scale-110 group-hover:-translate-y-0.5 group-hover:text-[color:var(--gold-light)]" />
                </div>
                <div className="mt-3 text-sm font-medium text-[color:var(--navy)]">{item}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function LeadershipProfileGroup({
  title,
  people,
  compact = false,
  className = "",
}: {
  title: string;
  people: SpeakerProfile[];
  compact?: boolean;
  className?: string;
}) {
  const useTwoColumns = compact && people.length > 1;

  return (
    <div className={className}>
      <EventCategoryHeading title={title} />
      <div className={useTwoColumns ? "mt-5 grid grid-cols-2 gap-4" : "mt-5 flex flex-wrap justify-center gap-5"}>
        {people.map((person, index) => (
          <div
            key={person.name}
            className={
              useTwoColumns
                ? "min-w-0"
                : compact
                  ? "w-full max-w-[14rem]"
                  : "w-[calc(50%-0.625rem)] sm:max-w-[16rem] lg:w-[calc(20%-1rem)]"
            }
          >
            <EventProfileCard profile={person} reserveNameLines={title === "Patrons" && index < 5 ? 2 : 1} />
          </div>
        ))}
      </div>
    </div>
  );
}

function EventProfileCard({
  profile,
  hideName = false,
  reserveNameLines = 1,
  reserveDetailLines = 0,
}: {
  profile: SpeakerProfile;
  hideName?: boolean;
  reserveNameLines?: 1 | 2;
  reserveDetailLines?: number;
}) {
  const metaLines = [profile.designation, profile.organization, profile.country].filter(
    (line): line is string => Boolean(line && line.trim()),
  );
  const detailLines = [...metaLines, ...Array(Math.max(0, reserveDetailLines - metaLines.length)).fill("")];

  return (
    <article data-profile-card className="mx-auto flex h-full w-full max-w-[16rem] flex-col overflow-hidden rounded-[22px] border border-[color:var(--hairline)] bg-white text-center shadow-[0_18px_44px_-28px_rgba(5,43,87,0.18)] transition-transform duration-300 hover:-translate-y-1">
      <div className="aspect-[43/50] overflow-hidden bg-white">
        <img src={profile.photo} alt={profile.name} loading="lazy" className="h-full w-full object-contain object-center" width={258} height={300} />
      </div>
      <div className="flex flex-1 flex-col border-t border-[color:var(--hairline)] px-4 py-4 md:px-5">
        {!hideName ? (
          <h3
            data-profile-name
            className={`${reserveNameLines === 2 ? "min-h-[3.3rem]" : "min-h-[1.65rem]"} text-lg font-semibold leading-snug text-[color:var(--navy)]`}
            style={{ fontFamily: "var(--font-display)" }}
          >
            {profile.name}
          </h3>
        ) : null}
        <div className="mt-2 space-y-0.5 text-sm leading-relaxed text-[color:var(--ink-soft)]">
          {detailLines.map((line, index) => (
            <p key={`${profile.name}-${line}`} className={`min-h-[1.35rem] ${index === 0 ? "font-medium text-[color:var(--gold-dark)]" : index === metaLines.length - 1 && profile.country === line ? "uppercase tracking-[0.08em] text-[color:var(--ink-muted)]" : ""}`}>
              {line || "\u00a0"}
            </p>
          ))}
        </div>
      </div>
    </article>
  );
}

function EventCategoryHeading({ title, showRules = true }: { title: string; showRules?: boolean }) {
  if (!showRules) {
    return (
      <h2 className="text-center text-[clamp(1.6rem,2.7vw,2.35rem)] font-normal leading-none text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>
        {title}
      </h2>
    );
  }

  return (
    <div className="flex items-center justify-center gap-4 text-center">
      <span className="h-px w-10 bg-[color:var(--gold)]/70 sm:w-16" />
      <h2 className="whitespace-nowrap text-[clamp(1.6rem,2.7vw,2.35rem)] font-normal leading-none text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>
        {title}
      </h2>
      <span className="h-px w-10 bg-[color:var(--gold)]/70 sm:w-16" />
    </div>
  );
}

function LeadershipRoleCard({ title, person }: { title: string; person?: SpeakerProfile }) {
  if (!person) return null;

  return (
    <div className="rounded-2xl border border-white/80 bg-white/55 p-4 shadow-[0_14px_34px_-28px_rgba(5,43,87,0.3)] md:p-5">
      <EventCategoryHeading title={title} />
      <div className="mt-5">
        <EventProfileCard profile={person} reserveDetailLines={2} />
      </div>
    </div>
  );
}

function LogoGroup({
  title,
  logos,
  prominentFirstTwo = false,
}: {
  title: string;
  logos: readonly { name: string; logo: string }[];
  prominentFirstTwo?: boolean;
}) {
  return (
    <div>
      <EventCategoryHeading title={title} />
      <div className="mt-7 flex flex-wrap justify-center gap-4">
        {logos.map((partner, index) => (
          <div key={partner.name} className="group flex min-h-24 w-[calc(50%-0.5rem)] items-center justify-center rounded-2xl border border-[color:var(--hairline)] bg-white p-4 transition-all hover:-translate-y-0.5 hover:border-[color:var(--gold)] hover:shadow-[0_12px_28px_-22px_rgba(5,43,87,0.2)] sm:w-[calc(33.333%-0.67rem)] lg:w-[calc(20%-0.8rem)]">
            <img
              src={partner.logo}
              alt={partner.name}
              loading="lazy"
              className={`max-h-16 w-full object-contain ${prominentFirstTwo && index < 2 ? "scale-[1.22]" : ""}`}
            />
          </div>
        ))}
      </div>
    </div>
  );
}

function ComingSoonPanel({
  title,
  note = "Stay connected and check this space for updates.",
}: {
  title: string;
  note?: string;
}) {
  return (
    <div className="rounded-[28px] border border-dashed border-[color:var(--gold)]/45 bg-[color:var(--off-white)] px-6 py-12 text-center md:px-10 md:py-16">
      <div className="gef-eyebrow">Coming Soon</div>
      <h2
        className="mt-4 text-[clamp(1.6rem,3vw,2.4rem)] font-normal text-[color:var(--navy)]"
        style={{ fontFamily: "var(--font-display)" }}
      >
        {title}
      </h2>
      <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-[color:var(--ink-soft)] md:text-base">
        {note}
      </p>
    </div>
  );
}
