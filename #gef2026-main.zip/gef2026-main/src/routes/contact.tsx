import { createFileRoute } from "@tanstack/react-router";
import emailjs from "@emailjs/browser";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { Mail, Phone, MapPin, Linkedin, Instagram, Facebook, Youtube } from "lucide-react";
import { FinalCTA, SectionHeading } from "../components/gef/CTA";
import {
  ORGANIZATION_ADDRESS_TEXT,
  ORGANIZATION_EMAIL,
  ORGANIZATION_PHONE,
  SOCIAL_PROFILES,
  breadcrumbSchema,
  createSeoHead,
  webpageSchema,
} from "../lib/seo";

export const Route = createFileRoute("/contact")({
  head: () => {
    const seo = createSeoHead({
      title: "Contact Global Entrepreneurs Forum (GEF) | Get in Touch",
      description:
        "Contact Global Entrepreneurs Forum for event participation, partnerships, sponsorships, investor connections, speaking opportunities, and general enquiries.",
      path: "/contact",
      keywords: [
        "contact GEF",
        "Global Entrepreneurs Forum contact",
        "Global Entrepreneur Forum contact",
        "GEF inquiries",
        "partnership inquiry",
        "media inquiry",
      ],
    });

    return {
      ...seo,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@graph": [
              webpageSchema({
                path: "/contact",
                name: "Contact GEF",
                description:
                  "Official contact page for Global Entrepreneurs Forum event, partnership, media, and speaker inquiries.",
              }),
              breadcrumbSchema([
                { name: "Home", path: "/" },
                { name: "Contact", path: "/contact" },
              ]),
            ],
          }),
        },
      ],
    };
  },
  component: ContactPage,
});

const CATEGORIES = [
  "General Inquiry",
  "Event Inquiry",
  "Sponsorship",
  "Partnership",
  "Media",
  "Speaker Inquiry",
  "Other",
];

function ContactPage() {
  const [isSending, setIsSending] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [captchaToken, setCaptchaToken] = useState<string | null>(null);
  const [ReCAPTCHAComponent, setReCAPTCHAComponent] = useState<any>(null);

  const recaptchaRef = useRef<any>(null);

  const recaptchaSiteKey = import.meta.env.VITE_RECAPTCHA_SITE_KEY;

  useEffect(() => {
    let mounted = true;

    import("react-google-recaptcha")
      .then((module) => {
        const importedModule = module as any;

        const Component =
          importedModule?.default?.default ??
          importedModule?.default ??
          importedModule;

        if (mounted) {
          setReCAPTCHAComponent(() => Component);
        }
      })
      .catch((error) => {
        console.error("Failed to load Google reCAPTCHA.", error);

        if (mounted) {
          setErrorMessage(
            "reCAPTCHA could not load. Please refresh the page and try again."
          );
        }
      });

    return () => {
      mounted = false;
    };
  }, []);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!captchaToken) {
      setSuccessMessage("");
      setErrorMessage("Please verify that you are not a robot.");
      return;
    }

    if (isSending) {
      return;
    }

    setIsSending(true);
    setSuccessMessage("");
    setErrorMessage("");

    const serviceId = import.meta.env.VITE_EMAILJS_SERVICE_ID;
    const templateId = import.meta.env.VITE_EMAILJS_CONTACT_TEMPLATE_ID;
    const publicKey = import.meta.env.VITE_EMAILJS_PUBLIC_KEY;

    if (!serviceId || !templateId || !publicKey) {
      console.error("EmailJS configuration is missing for the contact form.");
      setErrorMessage(
        "We could not submit your inquiry right now. Please try again."
      );
      setIsSending(false);
      return;
    }

    const form = event.currentTarget;
    const formData = new FormData(form);

    const templateParams = {
      name: String(formData.get("name") || "").trim(),
      email: String(formData.get("email") || "").trim(),
      phone: String(formData.get("phone") || "").trim(),
      organization: String(formData.get("organization") || "").trim(),
      inquiry_type: String(formData.get("inquiry_type") || "").trim(),
      message: String(formData.get("message") || "").trim(),
      "g-recaptcha-response": captchaToken,
    };

    try {
      await emailjs.send(serviceId, templateId, templateParams, {
        publicKey,
        blockHeadless: true,
        limitRate: {
          id: "gef-contact-inquiry",
          throttle: 10_000,
        },
      });

      setSuccessMessage(
        "Thank you. Your inquiry has been submitted successfully."
      );

      form.reset();
      setCaptchaToken(null);
      recaptchaRef.current?.reset();
    } catch (error) {
      console.error("EmailJS contact form submission failed.", error);

      setErrorMessage(
        "We could not submit your inquiry right now. Please try again."
      );
    } finally {
      setIsSending(false);
    }
  };

  return (
    <>
      <div className="sr-only">
        <h1>Contact Global Entrepreneurs Forum (GEF)</h1>
        <p>
          Official contact page for Global Entrepreneurs Forum covering event,
          partnership, media, and speaker inquiries.
        </p>
      </div>

      <section className="gef-section !pt-8 !pb-10 md:!pt-10 md:!pb-12">
        <div className="gef-container grid gap-8 lg:grid-cols-[1.4fr_1fr]">
          <div className="rounded-2xl border border-[color:var(--hairline)] bg-white p-6 md:p-8">
            <SectionHeading
              eyebrow="Inquiry Form"
              title="Send us a message."
            />

            <form onSubmit={handleSubmit} className="mt-6 grid gap-4">
              <div className="grid gap-4 md:grid-cols-2">
                <Field label="Name" required>
                  <input
                    name="name"
                    className="gef-input"
                    required
                    maxLength={100}
                  />
                </Field>

                <Field label="Email" required>
                  <input
                    name="email"
                    type="email"
                    className="gef-input"
                    required
                    maxLength={150}
                  />
                </Field>

                <Field label="Phone">
                  <input
                    name="phone"
                    type="tel"
                    className="gef-input"
                    maxLength={30}
                  />
                </Field>

                <Field label="Organization">
                  <input
                    name="organization"
                    className="gef-input"
                    maxLength={120}
                  />
                </Field>
              </div>

              <Field label="Inquiry Type" required>
                <select
                  name="inquiry_type"
                  className="gef-input"
                  required
                >
                  <option value="">Select...</option>

                  {CATEGORIES.map((category) => (
                    <option key={category}>{category}</option>
                  ))}
                </select>
              </Field>

              <Field label="Message" required>
                <textarea
                  name="message"
                  className="gef-input"
                  required
                  maxLength={2000}
                />
              </Field>

              <p className="text-xs text-[color:var(--ink-muted)]">
                Your details are safe and will only be used to respond to your
                inquiry.
              </p>

              {recaptchaSiteKey && ReCAPTCHAComponent ? (
                <div className="mt-2 overflow-x-auto">
                  <ReCAPTCHAComponent
                    ref={recaptchaRef}
                    sitekey={recaptchaSiteKey}
                    onChange={(token: string | null) => {
                      setCaptchaToken(token);
                      setErrorMessage("");
                    }}
                    onExpired={() => {
                      setCaptchaToken(null);
                    }}
                    onErrored={() => {
                      setCaptchaToken(null);
                      setErrorMessage(
                        "reCAPTCHA could not load. Please try again."
                      );
                    }}
                  />
                </div>
              ) : recaptchaSiteKey ? (
                <p className="text-sm text-[color:var(--ink-muted)]">
                  Loading verification...
                </p>
              ) : (
                <p className="text-sm text-red-700">
                  reCAPTCHA configuration is unavailable.
                </p>
              )}

              {successMessage ? (
                <p className="text-sm text-[color:var(--navy)]">
                  {successMessage}
                </p>
              ) : null}

              {errorMessage ? (
                <p className="text-sm text-red-700">{errorMessage}</p>
              ) : null}

              <button
                type="submit"
                className="gef-btn gef-btn-primary mt-2"
                disabled={isSending || !captchaToken}
              >
                {isSending ? "Submitting..." : "Submit Inquiry"}
              </button>
            </form>
          </div>

          <div className="space-y-6">
            <div className="rounded-2xl border border-[color:var(--hairline)] bg-white p-6">
              <h3
                className="text-lg font-semibold text-[color:var(--navy)]"
                style={{
                  fontFamily: "var(--font-display)",
                  fontWeight: 500,
                }}
              >
                Direct Contact
              </h3>

              <ul className="mt-4 space-y-3 text-sm">
                <li className="flex items-start gap-2 text-[color:var(--navy)]">
                  <Mail className="mt-0.5 h-4 w-4 text-[color:var(--gold-dark)]" />
                  {ORGANIZATION_EMAIL}
                </li>

                <li className="flex items-start gap-2 text-[color:var(--navy)]">
                  <Phone className="mt-0.5 h-4 w-4 text-[color:var(--gold-dark)]" />
                  {ORGANIZATION_PHONE}
                </li>

                <li className="flex items-start gap-2 text-[color:var(--navy)]">
                  <MapPin className="mt-0.5 h-4 w-4 text-[color:var(--gold-dark)]" />
                  {ORGANIZATION_ADDRESS_TEXT}
                </li>
              </ul>

              <div className="mt-5 border-t border-[color:var(--hairline)] pt-4">
                <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-[color:var(--ink-muted)]">
                  Social Media
                </div>

                <div className="mt-3 flex flex-wrap gap-3">
                  <SocialIcon
                    href={SOCIAL_PROFILES.linkedin}
                    label="LinkedIn"
                    Icon={Linkedin}
                  />
                  <SocialIcon
                    href={SOCIAL_PROFILES.instagram}
                    label="Instagram"
                    Icon={Instagram}
                  />
                  <SocialIcon
                    href={SOCIAL_PROFILES.youtube}
                    label="YouTube"
                    Icon={Youtube}
                  />
                  <SocialIcon
                    href={SOCIAL_PROFILES.facebook}
                    label="Facebook"
                    Icon={Facebook}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="gef-section !py-10 md:!py-12 lg:!py-14 bg-[color:var(--off-white)]">
        <div className="gef-container">
          <SectionHeading
            eyebrow="Find Us"
            title="GEF chapters across markets."
            align="center"
          />

          <div className="mt-8 overflow-hidden rounded-2xl border border-[color:var(--hairline)] bg-white">
            <iframe
              title="GEF Pune map"
              src="https://maps.google.com/maps?q=Pune%2C%20Maharashtra&t=&z=11&ie=UTF8&iwloc=&output=embed"
              className="h-[360px] w-full"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>

      <FinalCTA />
    </>
  );
}

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium uppercase tracking-[0.12em] text-[color:var(--ink-muted)]">
        {label}
        {required ? " *" : ""}
      </span>

      {children}
    </label>
  );
}

function SocialIcon({
  href,
  label,
  Icon,
}: {
  href: string | null;
  label: string;
  Icon: typeof Linkedin;
}) {
  const className =
    "inline-flex h-10 w-10 items-center justify-center rounded-full border border-[color:var(--hairline)] text-[color:var(--navy)] transition hover:border-[color:var(--gold)] hover:bg-[color:var(--gold-soft)]";

  if (!href) {
    return (
      <span
        aria-hidden="true"
        className={`${className} opacity-50`}
      >
        <Icon className="h-4 w-4 text-[color:var(--gold-dark)]" />
      </span>
    );
  }

  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      aria-label={label}
      title={label}
      className={className}
    >
      <Icon className="h-4 w-4 text-[color:var(--gold-dark)]" />
    </a>
  );
}