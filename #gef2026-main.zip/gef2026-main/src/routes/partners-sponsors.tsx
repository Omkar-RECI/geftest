import { createFileRoute } from "@tanstack/react-router";
import {
  Globe2,
  Handshake,
  Presentation,
  ShieldCheck,
} from "lucide-react";
import { FinalCTA, SectionHeading } from "../components/gef/CTA";
import { breadcrumbSchema, createSeoHead, webpageSchema } from "../lib/seo";

export const Route = createFileRoute("/partners-sponsors")({
  head: () => {
    const seo = createSeoHead({
      title: "Partners & Sponsors | Global Entrepreneurs Forum (GEF)",
      description:
        "Partner with Global Entrepreneurs Forum (GEF) to reach founders, investors, business leaders, institutions, and ecosystem communities across global markets.",
      path: "/partners-sponsors",
      keywords: [
        "partner with GEF",
        "GEF sponsorship",
        "Global Entrepreneurs Forum partners",
        "Global Entrepreneur Forum partners",
        "ecosystem partners",
        "business sponsorship",
      ],
    });

    return {
      ...seo,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@graph": [
              webpageSchema({
                path: "/partners-sponsors",
                name: "Partners & Sponsors",
                description:
                  "Official partnership and sponsorship page for Global Entrepreneurs Forum.",
              }),
              breadcrumbSchema([
                { name: "Home", path: "/" },
                {
                  name: "Partners & Sponsors",
                  path: "/partners-sponsors",
                },
              ]),
            ],
          }),
        },
      ],
    };
  },
  component: PartnersPage,
});

const REASONS = [
  {
    title: "High-Value Audience",
    desc: "Reach founders, investors and senior business leaders in one room.",
    icon: Presentation,
  },
  {
    title: "Brand Visibility",
    desc: "Build trust with the global entrepreneurship ecosystem.",
    icon: ShieldCheck,
  },
  {
    title: "Cross-Border Reach",
    desc: "Support founders and capital across markets.",
    icon: Globe2,
  },
  {
    title: "Ecosystem Partnerships",
    desc: "Create lasting relationships with institutions and communities.",
    icon: Handshake,
  },
];

const ECOSYSTEM_PARTNER_LOGOS = [
  { name: "PCU", logo: "/Assets/Associated-Logos/PCU.svg" },
  { name: "SAVA", logo: "/Assets/Associated-Logos/Sava_H_C.svg" },
  { name: "DEASRA", logo: "/Assets/Associated-Logos/DeAsra.svg" },
  { name: "Krsnaa", logo: "/Assets/Associated-Logos/Krsnaa_D.svg" },
  { name: "COMSENSE", logo: "/Assets/Associated-Logos/Comsense.svg" },
  {
    name: "GARJE MARATHI GLOBAL",
    logo: "/Assets/Associated-Logos/Garaje_ Marathi.svg",
  },
  { name: "PCET", logo: "/Assets/Associated-Logos/PCET.svg" },
  {
    name: "Trade India",
    logo: "/Assets/Associated-Logos/Trade_india.svg",
  },
  { name: "RAYAT", logo: "/Assets/Associated-Logos/Rayat.svg" },
  { name: "IEBD", logo: "/Assets/Associated-Logos/IEBD.svg" },
  {
    name: "VSS",
    logo: "/Assets/Associated-Logos/Samiti_org_VSS.svg",
  },
  {
    name: "Saturday Club Global Trust",
    logo: "/Assets/Associated-Logos/Sat_Club_Global_T.svg",
  },
  {
    name: "NMEIT talegaon",
    logo: "/Assets/Associated-Logos/NMEIT talegaon.svg",
  },
  {
    name: "Global India Business Forum",
    logo: "/Assets/Associated-Logos/GIBF.svg",
  },
  { name: "GMBF", logo: "/Assets/Associated-Logos/GMBF_G.svg" },
] as const;

function PartnersPage() {
  return (
    <>
      <div className="sr-only">
        <h1>Global Entrepreneurs Forum Partners and Sponsors</h1>
        <p>
          Official partnership and sponsorship page for Global Entrepreneurs
          Forum, including ecosystem partners and inquiry options.
        </p>
      </div>

      <section className="gef-section !py-10 md:!py-12 lg:!py-14">
        <div className="gef-container">
          <SectionHeading
            eyebrow="Trust"
            title="Ecosystem Partners"
            align="center"
          />

          <div className="mt-8 rounded-[28px] border border-[color:var(--hairline)] bg-white px-6 py-7 shadow-[0_22px_60px_-40px_rgba(5,43,87,0.2)] md:px-8 md:py-8">
            <div className="grid grid-cols-2 gap-x-4 gap-y-6 sm:grid-cols-3 sm:gap-x-6 sm:gap-y-8 lg:grid-cols-5">
              {ECOSYSTEM_PARTNER_LOGOS.map((partner) => (
                <article
                  key={partner.name}
                  className="flex min-h-[92px] items-center justify-center rounded-2xl bg-white px-2 py-3"
                >
                  <img
                    src={partner.logo}
                    alt={partner.name}
                    loading="lazy"
                    className="max-h-16 w-full object-contain object-center md:max-h-20"
                  />
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="gef-section !pt-8 !pb-8 md:!pt-10 md:!pb-10">
        <div className="gef-container">
          <SectionHeading
            eyebrow="Why Partner"
            title="What partnership with GEF unlocks."
          />

          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {REASONS.map((reason) => (
              <div
                key={reason.title}
                className="group rounded-[24px] border border-[color:var(--hairline)] bg-white p-6 shadow-[0_18px_44px_-34px_rgba(5,43,87,0.16)] transition-all duration-300 hover:-translate-y-1 hover:border-[color:var(--gold)] hover:shadow-[0_24px_54px_-34px_rgba(5,43,87,0.24)]"
              >
                <div className="grid h-11 w-11 place-items-center rounded-full bg-[color:var(--gold-soft)] transition-all duration-300 group-hover:scale-[1.06] group-hover:bg-[color:var(--navy)]">
                  <reason.icon className="h-5 w-5 text-[color:var(--gold-dark)] transition-all duration-300 group-hover:scale-110 group-hover:text-[color:var(--gold-light)]" />
                </div>

                <h3
                  className="mt-5 text-lg font-semibold text-[color:var(--navy)]"
                  style={{
                    fontFamily: "var(--font-display)",
                    fontWeight: 500,
                  }}
                >
                  {reason.title}
                </h3>

                <p className="mt-2 text-sm text-[color:var(--ink-soft)]">
                  {reason.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <FinalCTA />
    </>
  );
}
