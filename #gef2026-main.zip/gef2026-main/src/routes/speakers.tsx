import { createFileRoute } from "@tanstack/react-router";
import { useRef } from "react";
import { FinalCTA } from "../components/gef/CTA";
import { SpeakerProfileCard } from "../components/gef/SpeakerProfileCard";
import { SPEAKER_PROFILES } from "../content/speakers";
import { useAlignedProfileNames } from "../hooks/useAlignedProfileNames";
import {
  breadcrumbSchema,
  collectionPageSchema,
  createSeoHead,
  itemListSchema,
  personSchema,
} from "../lib/seo";

export const Route = createFileRoute("/speakers")({
  head: () => {
    const seo = createSeoHead({
      title: "Global Entrepreneurs Forum Speakers | Business & Industry Leaders",
      description:
        "Meet the entrepreneurs, investors, business leaders, policymakers, academics, and industry experts contributing to the Global Entrepreneurs Forum.",
      path: "/speakers",
      keywords: [
        "GEF speakers",
        "Global Entrepreneurs Forum speakers",
        "Global Entrepreneur Forum speakers",
        "entrepreneur speakers",
        "investor speakers",
        "policy leaders",
        "business leaders",
        "industry experts",
      ],
    });

    return {
      ...seo,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@graph": [
              collectionPageSchema({
                path: "/speakers",
                name: "Global Entrepreneurs Forum Speakers",
                description:
                  "Influential founders, investors, diplomats, policymakers, and ecosystem leaders associated with GEF.",
              }),
              breadcrumbSchema([
                { name: "Home", path: "/" },
                { name: "Speakers", path: "/speakers" },
              ]),
              itemListSchema({
                name: "GEF Speaker Profiles",
                items: SPEAKER_PROFILES.map((speaker) => ({
                  name: speaker.name,
                  url: "/speakers",
                })),
              }),
              ...SPEAKER_PROFILES.map((speaker) =>
                personSchema({
                  name: speaker.name,
                  designation: speaker.designation,
                  organization: speaker.organization,
                  country: speaker.country,
                  photo: speaker.photo,
                }),
              ),
            ],
          }),
        },
      ],
    };
  },
  component: SpeakersPage,
});

function SpeakersPage() {
  const speakerGridRef = useRef<HTMLDivElement>(null);
  useAlignedProfileNames(speakerGridRef);
  const getSpeakerMetaLines = (speaker: (typeof SPEAKER_PROFILES)[number]) =>
    [speaker.designation, speaker.organization, speaker.country].filter(
      (line): line is string => Boolean(line && line.trim()),
    );

  const speakerCards = SPEAKER_PROFILES.map((speaker) => {
    const metaLines = getSpeakerMetaLines(speaker);

    return (
      <article
        key={speaker.name}
        data-profile-card
        className="mx-auto flex h-full w-full max-w-[16rem] flex-col overflow-hidden rounded-[22px] border border-[color:var(--hairline)] bg-white text-center shadow-[0_18px_44px_-28px_rgba(5,43,87,0.18)] transition-transform duration-300 hover:-translate-y-1"
      >
        <div className="aspect-[43/50] overflow-hidden bg-white">
          <img
            src={speaker.photo}
            alt={speaker.name}
            loading="lazy"
            className="h-full w-full object-contain object-center"
            width={258}
            height={300}
          />
        </div>
        <div className="flex flex-1 flex-col border-t border-[color:var(--hairline)] px-4 py-4 md:px-5">
          <h3
            data-profile-name
            className="min-h-[1.65rem] text-lg font-semibold leading-snug text-[color:var(--navy)]"
            style={{ fontFamily: "var(--font-display)" }}
          >
            {speaker.name}
          </h3>
          <div className="mt-2 space-y-0.5 text-sm leading-relaxed text-[color:var(--ink-soft)]">
            {metaLines.map((line, index) => (
              <p
                key={`${speaker.name}-${line}-${index}`}
                className={`min-h-[1.35rem] ${
                  index === 0
                    ? "font-medium text-[color:var(--gold-dark)]"
                    : index === metaLines.length - 1 && speaker.country === line
                      ? "uppercase tracking-[0.08em] text-[color:var(--ink-muted)]"
                      : ""
                }`}
              >
                {line}
              </p>
            ))}
          </div>
        </div>
      </article>
    );
  });

  return (
    <>
      <div className="sr-only">
        <h1>Global Entrepreneurs Forum Speakers Directory</h1>
        <p>
          Official speaker directory for Global Entrepreneurs Forum featuring founders,
          investors, diplomats, policymakers, and ecosystem leaders.
        </p>
      </div>
      <section className="gef-section !pt-8 !pb-10 md:!pt-10 md:!pb-12">
        <div className="gef-container">
          <div className="mx-auto max-w-2xl text-center">
            <span className="gef-eyebrow">Global Presence</span>
            <h1 className="mt-3 text-[clamp(1.5rem,2.6vw,2.15rem)] font-normal leading-[1.08] text-[color:var(--navy)]">
              Voices connected with the GEF ecosystem.
            </h1>
          </div>

          <div ref={speakerGridRef} className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5">{speakerCards}</div>
        </div>
      </section>
      <FinalCTA className="!pt-6 md:!pt-8" />
    </>
  );
}
