import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check, Crown, Handshake, ShieldCheck, UsersRound, Utensils } from "lucide-react";
import { SectionHeading } from "../components/gef/CTA";
import { PlatinumPassApplicationForm } from "../components/gef/PlatinumPassApplicationForm";
import { PlatinumPassVisualCard } from "../components/gef/PlatinumPassVisualCard";
import { ACTIVE_EVENT } from "../data/gef";
import { breadcrumbSchema, createSeoHead, webpageSchema } from "../lib/seo";

const PRIVILEGES = [
  { title: "Pre-conclave dinner", description: "An exclusive dinner ahead of the conclave for meaningful peer connection.", Icon: Utensils },
  { title: "Patrons & Advisory Board", description: "A hosted opportunity to meet GEF Patrons and Advisory Board members.", Icon: UsersRound },
  { title: "Investor meetings", description: "Curated meeting opportunities with investors aligned to your growth journey.", Icon: Handshake },
  { title: "Reserved seating", description: "Reserved first- and second-row seating in selected sessions.", Icon: Crown },
  { title: "Dedicated check-in", description: "A separate Platinum Pass check-in for a smooth arrival experience.", Icon: ShieldCheck },
  { title: "Platinum coordination", description: "A dedicated GEF contact for Platinum Pass-related event coordination.", Icon: ShieldCheck },
] as const;

const PASS_PROCESS = [
  "Strictly limited to 100 selected leaders",
  "Applications are reviewed by the GEF team",
  "Confirmed inclusions are shared in writing",
  "Dedicated Platinum Pass coordination",
];

export const Route = createFileRoute("/platinum-pass")({
  head: () => {
    const seo = createSeoHead({
      title: "GEF Platinum Pass | GEF Pune 2027 Curated Access",
      description: "Apply for the limited, reviewed GEF Platinum Pass experience for GEF Pune 2027 in Pune, India.",
      path: "/platinum-pass",
      keywords: ["GEF Platinum Pass", "GEF Pune 2027 VIP pass", "Global Entrepreneurs Forum premium access"],
    });

    return {
      ...seo,
      scripts: [{ type: "application/ld+json", children: JSON.stringify({
        "@context": "https://schema.org",
        "@graph": [
          webpageSchema({ path: "/platinum-pass", name: "GEF Platinum Pass", description: "Curated access application page for GEF Pune 2027." }),
          breadcrumbSchema([
            { name: "Home", path: "/" },
            { name: "GEF Pune 2027", path: "/GEFPune2027" },
            { name: "GEF Platinum Pass", path: "/platinum-pass" },
          ]),
        ],
      }) }],
    };
  },
  component: PlatinumPassPage,
});

function PlatinumPassPage() {
  return (
    <main className="bg-[#f8f6f0]">
      <PlatinumPassExperience />
      <PlatinumPassApplicationForm />
    </main>
  );
}

export function PlatinumPassExperience({
  applicationHref = "#platinum-pass-application",
}: {
  applicationHref?: string;
}) {
  return (
    <>
      <section className="relative overflow-hidden bg-[linear-gradient(125deg,#02152e_0%,#052d5a_55%,#061c38_100%)] py-12 text-white md:py-20">
        <div className="pointer-events-none absolute -left-16 top-8 h-72 w-72 rounded-full bg-[color:var(--gold)]/15 blur-3xl" />
        <div className="pointer-events-none absolute right-0 top-0 h-full w-[42%] bg-[linear-gradient(135deg,transparent_0%,rgba(228,196,106,0.14)_100%)]" />
        <div className="gef-container relative grid items-center gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16">
          <div className="max-w-2xl">
            <div className="flex flex-wrap gap-2">
              <span className="inline-flex rounded-full border border-[color:var(--gold)]/45 bg-[color:var(--gold)]/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.2em] text-[color:var(--gold-light)]">GEF Pune 2027</span>
              <span className="inline-flex rounded-full border border-white/20 bg-white/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-white">100 selected leaders only</span>
            </div>
            <h1 className="mt-6 text-[clamp(3rem,6.2vw,5.6rem)] font-normal leading-[0.9] !text-white" style={{ fontFamily: "var(--font-display)", color: "#fff" }}>
              GEF<br /><span className="text-[color:var(--gold-light)]">Platinum</span> Pass
            </h1>
            <p className="mt-6 max-w-xl text-base leading-8 text-white/80 md:text-lg">A limited, reviewed experience for the leaders, investors and builders who want to engage with GEF more intentionally.</p>
            <div className="mt-7 flex flex-wrap items-center gap-x-3 gap-y-2 text-sm text-white/75">
              <span>15, 16, 17 January 2027</span>
              <span className="text-[color:var(--gold)]">|</span>
              <span>{ACTIVE_EVENT.venue}</span>
            </div>
            <a href={applicationHref} className="mt-8 inline-flex min-h-12 items-center justify-center rounded-full border border-[color:var(--gold)]/55 bg-white/10 px-5 text-sm font-bold text-[color:var(--gold-light)] transition hover:bg-[color:var(--gold)] hover:text-[color:var(--navy-deep)]">
              Apply Now
            </a>
          </div>

          <PlatinumPassVisualCard className="mx-auto max-w-md" />
        </div>
        <p className="absolute bottom-3 right-4 sm:bottom-4 sm:right-6 md:bottom-5 md:right-8 z-10 text-[10px] font-medium uppercase tracking-[0.16em] text-white/50">*T&amp;C Apply</p>
      </section>

      <section className="gef-section !pt-7 !pb-11 md:!pt-10 md:!pb-16">
        <div className="gef-container">
          <div className="mx-auto max-w-3xl text-center"><span className="gef-eyebrow">Designed for considered access</span><h2 className="mt-3 text-[clamp(2rem,4vw,3.4rem)] font-normal leading-tight text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>The Platinum experience.</h2><p className="mt-4 text-sm leading-7 text-[color:var(--ink-soft)] md:text-base">A more personal way to navigate GEF Pune 2027, designed around access, comfort and high-value conversations.</p></div>
          <div className="mt-9 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {PRIVILEGES.map(({ title, description, Icon }, index) => (
              <article key={title} className="group relative overflow-hidden rounded-2xl border border-[color:var(--hairline)] bg-white p-6 transition-all duration-300 hover:-translate-y-1 hover:border-[color:var(--gold)] hover:shadow-[0_22px_44px_-28px_rgba(5,43,87,0.28)]">
                <span className="absolute right-5 top-4 text-4xl font-normal text-[color:var(--gold-soft)]" style={{ fontFamily: "var(--font-display)" }}>0{index + 1}</span>
                <div className="grid h-11 w-11 place-items-center rounded-full bg-[color:var(--gold-soft)] transition-colors group-hover:bg-[color:var(--navy)]"><Icon className="h-5 w-5 text-[color:var(--gold-dark)] transition-colors group-hover:text-[color:var(--gold-light)]" /></div>
                <h3 className="mt-5 text-2xl text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>{title}</h3><p className="mt-2 text-sm leading-6 text-[color:var(--ink-soft)]">{description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="gef-section !pt-2 !pb-11 md:!pt-4 md:!pb-16">
        <div className="gef-container grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="rounded-[26px] bg-[color:var(--navy)] p-7 text-white md:p-9"><span className="text-[11px] font-semibold uppercase tracking-[0.2em] text-[color:var(--gold-light)]">Indicative contribution</span><p className="mt-3 text-5xl font-normal text-white" style={{ fontFamily: "var(--font-display)" }}>INR 25,000</p><p className="mt-4 text-sm leading-7 text-white/72">The final contribution and confirmed inclusions are shared after application review. This is a limited pass, not an automatic purchase.</p></div>
          <div className="rounded-[26px] border border-[color:var(--hairline)] bg-white p-7 md:p-9"><SectionHeading eyebrow="Platinum allocation" title="Limited by design." /><ul className="mt-6 grid gap-3 sm:grid-cols-2">{PASS_PROCESS.map((step) => <li key={step} className="flex items-center gap-3 text-sm text-[color:var(--ink-soft)]"><Check className="h-4 w-4 shrink-0 text-[color:var(--gold-dark)]" />{step}</li>)}</ul><p className="mt-5 text-xs leading-5 text-[color:var(--ink-muted)]">This is a reviewed access programme. Final Platinum Pass inclusions will be confirmed in writing by the GEF team.</p></div>
        </div>
      </section>

      <section className="pb-12 md:pb-16">
        <div className="gef-container">
          <div className="rounded-[28px] border border-[color:var(--gold)]/45 bg-[linear-gradient(135deg,#fff9e7_0%,#f6edcd_100%)] p-7 md:p-10">
            <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-end">
              <div>
                <span className="gef-eyebrow">Application review</span>
                <h2 className="mt-3 text-[clamp(2rem,4vw,3.2rem)] font-normal leading-tight text-[color:var(--navy)]" style={{ fontFamily: "var(--font-display)" }}>
                  Limited by design. Selected with intent.
                </h2>
                <p className="mt-4 max-w-2xl text-sm leading-7 text-[color:var(--ink-soft)]">
                  Only 100 selected leaders will be offered Platinum Pass access. Applications are now open; the GEF team will review each application and share confirmed next steps.
                </p>
              </div>
              <div className="flex flex-wrap gap-3 lg:justify-end">
                <a href={applicationHref} className="gef-btn border-0 bg-[color:var(--navy)] text-white hover:bg-[color:var(--navy-deep)]">
                  Apply Now <ArrowRight className="h-4 w-4" />
                </a>
                <Link to="/GEFPune2027" className="gef-btn border border-[color:var(--navy)] bg-white text-[color:var(--navy)] hover:bg-[color:var(--navy)] hover:text-white">
                  Explore GEF Pune 2027 <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
