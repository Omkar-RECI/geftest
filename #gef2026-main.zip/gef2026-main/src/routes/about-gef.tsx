import { createFileRoute } from "@tanstack/react-router";
import { useRef } from "react";
import {
  BadgeDollarSign,
  BriefcaseBusiness,
  Building2,
  Globe2,
  GraduationCap,
  Handshake,
  Landmark,
  Lightbulb,
  Network,
  Rocket,
  Scale,
  Sparkles,
  Store,
  Users2,
  type LucideIcon,
} from "lucide-react";
import { EVENT_MODE } from "../data/gef";
import { FinalCTA, SectionHeading } from "../components/gef/CTA";
import { ProfileCard } from "../components/gef/ProfileCard";
import { useAlignedProfileNames } from "../hooks/useAlignedProfileNames";
import { breadcrumbSchema, createSeoHead, webpageSchema } from "../lib/seo";

const ABOUT_LEADERSHIP = [
  {
    name: "Sachin Itkar",
    bio: "Ecosystem Builder & Policy Strategist",
    photo: "/Assets/Leadership/Sachin_GEF1.jpg",
  },
  {
    name: "Sagar Babar",
    bio: "Entrepreneur | Technologist | Business Coach",
    photo: "/Assets/Leadership/Sagar_GEF1.jpg",
  },
];

const PROFILE_FALLBACK_PHOTO = "/Assets/Events/GEC_Pune 2025/Speakers/Sample_Img.webp";

const ABOUT_PATRONS = [
  {
    name: "Padma Shri Prataprao Pawar",
    title: "Chairman",
    organization: "Sakal Media",
    photo: "/Assets/Leaders/PGP_GEF.jpg",
  },
  {
    name: "Padma Shri Dr. G. D. Yadav",
    title: "Former Vice Chancellor",
    organization: "ICT Mumbai",
    photo: "/Assets/Leaders/G_D_yadav.jpg",
  },
  {
    name: "Dr. Anand Deshpande",
    title: "Founder, Chairman & MD",
    organization: "Persistent",
    photo: "/Assets/Leaders/Anand_Deshpande.jpg",
  },
  {
    name: "Vinod Jadhav",
    title: "MD",
    organization: "SAVA Healthcare",
    country: "UAE",
    photo: "/Assets/Leaders/Vinod_Jadhav.jpg",
  },
  {
    name: "Prakash Bhalerao",
    title: "Entrepreneur & VC",
    photo: "/Assets/Leaders/Prakash_B.jpg",
    country: "USA",
  },
  {
    name: "Anand Ganu",
    title: "Founder and President",
    organization: "Garje Marathi Global",
    country: "USA",
    photo: "/Assets/Leaders/Anand_ganu.jpg",
  },
  {
    name: "Sundeep Waslekar",
    title: "President",
    organization: "Strategic Foresight Group",
    photo: "/Assets/Leaders/Dr. Sandeep_W.jpg",
  },
  {
    name: "Dr. Rajendra Jagdale",
    title: "Director General & CEO",
    organization: "Science & Technology Park",
    photo: "/Assets/Leaders/Dr. Rajendra Jagdale.jpg",
  },
] as const;

const ABOUT_MENTORS = [
  {
    name: "Rajendra Mutha",
    title: "Executive Chairman",
    organization: "Krsnaa Diagnostics Ltd",
    photo: "/Assets/Leaders/Rajendra Mutha (1).jpg",
  },
  {
    name: "Milind Deshmukh",
    title: "Director",
    organization: "SAM Contracting",
    country: "UAE",
    photo: "/Assets/Speakers/Milind Deshmukh.jpg",
  },
  {
    name: "Dr. Sanjay Paithankar",
    title: "Founder & Board Member",
    organization: "Right Health",
    country: "UAE",
    photo: "/Assets/Speakers/Sanjay Paithankar.jpg",
  },
  {
    name: "Dr. Girish Desai",
    title: "Executive Director",
    organization: "PCET & PCU",
    photo: "/Assets/Leaders/Dr. Girish Desai.jpg",
  },
  {
    name: "Vijayendra Surve",
    title: "CEO",
    organization: "Polaris International",
    country: "UAE",
    photo: "/Assets/Leaders/Vijayendra Surve.jpg",
  },
  {
    name: "Milind Lunkad",
    title: "Director",
    organization: "Rohan Builders",
    photo: "/Assets/Leaders/Milind Lunkad.jpg",
  },
  {
    name: "Rajesh Pokharkar",
    title: "Founder, Chairman & MD",
    organization: "Adhya Group",
    photo: "/Assets/Leaders/Rajesh Pokharkar.jpg",
  },
  {
    name: "Ujjwala Haware",
    title: "Chairperson & MD",
    organization: "Haware Legacy",
    photo: "/Assets/Leaders/Ujwala Haware.jpg",
  },
] as const;

const ECOSYSTEM_PILLARS = [
  "Global Connectivity",
  "Strategic Collaborations",
  "Knowledge & Innovation",
  "Investment Opportunities",
  "Business Growth",
  "Sustainable Impact",
  "Policy Dialogue",
  "Market Access",
];

const ECOSYSTEM_PILLAR_ICONS: LucideIcon[] = [
  Globe2,
  Handshake,
  Lightbulb,
  BadgeDollarSign,
  Rocket,
  Sparkles,
  Scale,
  Network,
];

const WHO_WE_BRING_TOGETHER = [
  "Entrepreneurs",
  "Startups",
  "MSMEs",
  "Investors",
  "Corporates",
  "Academia",
  "Policymakers",
  "Incubators",
  "Industry Leaders",
  "Innovation Partners",
];

const WHO_WE_BRING_TOGETHER_ICONS: LucideIcon[] = [
  BriefcaseBusiness,
  Rocket,
  Store,
  BadgeDollarSign,
  Building2,
  GraduationCap,
  Landmark,
  Lightbulb,
  Users2,
  Handshake,
];

const ABOUT_OVERVIEW_IMAGE = "/Assets/Gallary/1.webp";

export const Route = createFileRoute("/about-gef")({
  head: () => {
    const seo = createSeoHead({
      title: "About Global Entrepreneurs Forum (GEF) | Mission & Vision",
      description:
        "Learn about Global Entrepreneurs Forum, its mission, vision, and global entrepreneurship ecosystem connecting entrepreneurs, investors, businesses, academia, and policymakers.",
      path: "/about-gef",
      keywords: [
        "about GEF",
        "Global Entrepreneurs Forum",
        "Global Entrepreneur Forum",
        "RECI India Foundation",
        "entrepreneur ecosystem",
        "global entrepreneurship platform",
        "business collaboration",
      ],
    });

    return {
      ...seo,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@graph": [
              webpageSchema({
                path: "/about-gef",
                name: "About GEF",
                description:
                  "Learn about GEF's journey, purpose, vision, mission, leadership, and global entrepreneurial ecosystem.",
              }),
              breadcrumbSchema([
                { name: "Home", path: "/" },
                { name: "About GEF", path: "/about-gef" },
              ]),
            ],
          }),
        },
      ],
    };
  },
  component: AboutPage,
});

function AboutPage() {
  return (
    <>
      <div className="sr-only">
        <h1>About Global Entrepreneurs Forum (GEF)</h1>
        <p>
          Official about page for Global Entrepreneurs Forum, covering its journey, purpose,
          mission, vision, leadership, and ecosystem.
        </p>
      </div>
      <section className="gef-section !pt-8 !pb-10 md:!pt-10 md:!pb-12">
        <div className="gef-container">
          <div className="grid items-center gap-10 lg:grid-cols-[1.02fr_0.98fr] lg:gap-16">
            <div>
              <SectionHeading
                eyebrow="About GEF"
                title="What is GEF?"
              />
              <p className="mt-6 text-base leading-8 text-[color:var(--ink-soft)] md:text-lg">
                The <strong className="font-semibold text-[color:var(--navy)]">Global Entrepreneurs Forum (GEF)</strong> is dedicated to building a globally connected entrepreneurial ecosystem. <strong className="font-semibold text-[color:var(--navy)]">GEF</strong> brings together entrepreneurs, startups, investors, industry leaders, academia, policymakers, and ecosystem enablers to foster collaboration, innovation, and sustainable growth.
              </p>

              <div className="mt-6 grid gap-4">
                <div className="rounded-[24px] border border-[color:var(--hairline)] bg-white p-5 shadow-[0_18px_44px_-34px_rgba(5,43,87,0.18)] md:p-6">
                  <div className="text-[11px] font-semibold uppercase tracking-[0.24em] text-[color:var(--gold-dark)]">
                    Journey & Purpose
                  </div>
                  <p className="mt-3 text-sm leading-7 text-[color:var(--ink-soft)] md:text-base">
                    What began as <strong className="font-semibold text-[color:var(--navy)]">Global Entrepreneurs Conclave</strong> is evolving into{" "}
                    <strong className="font-semibold text-[color:var(--navy)]">Global Entrepreneurs Forum</strong> to create a stronger, year-round platform for collaboration, networking, knowledge sharing, investments, innovation, and global opportunities.
                  </p>
                  <p className="mt-3 text-sm leading-7 text-[color:var(--ink-soft)] md:text-base">
                    The purpose of <strong className="font-semibold text-[color:var(--navy)]">GEF</strong> is to create meaningful opportunities that empower entrepreneurs, strengthen businesses, and contribute to economic and social progress.
                  </p>
                </div>
              </div>
            </div>

            <div className="group relative overflow-hidden rounded-[24px]">
              <img
                src={ABOUT_OVERVIEW_IMAGE}
                alt="GEF delegates and ecosystem leaders engaging during a forum session"
                loading="lazy"
                width={1280}
                height={1280}
                className="aspect-[4/4.2] w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
              />
              <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(5,43,87,0.08)_0%,rgba(5,43,87,0.5)_100%)]" />
              <div className="absolute bottom-5 left-5 right-5 rounded-[22px] border border-white/20 bg-white/88 p-4 backdrop-blur md:bottom-6 md:left-6 md:right-6 md:p-5">
                <div className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[color:var(--gold-dark)]">
                  Connect | Collaborate | CO-CREATE
                </div>
                <p className="mt-2 text-sm leading-6 text-[color:var(--navy)] md:text-[15px]">
                  <strong className="font-semibold">GEF</strong> is built to turn conversations into collaboration and collaboration into long-term impact.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="gef-section !py-10 md:!py-12 lg:!py-14 bg-[color:var(--off-white)]">
        <div className="gef-container grid gap-6 md:grid-cols-2">
          <div
            className="flex h-full flex-col justify-between rounded-[24px] border border-[rgba(228,196,106,0.24)] p-10 shadow-[0_20px_50px_-36px_rgba(5,43,87,0.28)] transition-all duration-300 hover:-translate-y-1 hover:border-[rgba(228,196,106,0.46)] hover:shadow-[0_26px_60px_-36px_rgba(5,43,87,0.32)]"
            style={{ background: "var(--gradient-navy)", color: "#fff" }}
          >
            <span className="gef-eyebrow text-[color:var(--gold-light)]">Vision</span>
            <h3 className="mt-4 flex-1 text-3xl font-normal leading-tight text-white">
              To build one of the world's most trusted platforms connecting entrepreneurs,
              ideas, and opportunities across borders.
            </h3>
          </div>
          <div className="gef-card flex h-full flex-col justify-between">
            <span className="gef-eyebrow">Mission</span>
            <h3 className="mt-4 flex-1 text-3xl font-normal leading-tight text-[color:var(--navy)]">
              To enable collaboration, knowledge exchange, innovation, investment, and
              global partnerships that help entrepreneurs grow and succeed.
            </h3>
          </div>
        </div>
      </section>

      <section className="gef-section !py-10 md:!py-12 lg:!py-14">
        <div className="gef-container">
          <SectionHeading
            eyebrow="Continuous Ecosystem"
            title="How GEF creates value beyond the event."
          />
            <div className="mt-10 grid grid-cols-1 gap-3 min-[460px]:grid-cols-2 md:gap-5 lg:grid-cols-4">
              {ECOSYSTEM_PILLARS.map((item, index) => {
                const Icon = ECOSYSTEM_PILLAR_ICONS[index % ECOSYSTEM_PILLAR_ICONS.length];

                return (
                  <div key={item} className="group gef-card flex min-h-[88px] items-center gap-4 py-5">
                    <div className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-[color:var(--gold-soft)] transition-all duration-300 group-hover:scale-[1.06] group-hover:bg-[color:var(--navy)]">
                      <Icon className="h-5 w-5 text-[color:var(--gold-dark)] transition-all duration-300 group-hover:scale-110 group-hover:-translate-y-0.5 group-hover:text-[color:var(--gold-light)]" />
                    </div>
                    <h3
                      className="text-lg font-semibold text-[color:var(--navy)]"
                    style={{ fontFamily: "var(--font-display)", fontWeight: 500 }}
                  >
                    {item}
                  </h3>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="gef-section !pt-8 !pb-10 md:!pt-10 md:!pb-12 bg-[color:var(--off-white)]">
        <div className="gef-container">
          <div className="rounded-[28px] border border-[color:var(--hairline)] bg-white px-6 py-8 shadow-[0_22px_60px_-40px_rgba(5,43,87,0.2)] md:px-10 md:py-10">
            <SectionHeading
              eyebrow="Who We Bring Together"
              title="The people and institutions that shape the GEF ecosystem."
            />
            <div className="mt-8 grid grid-cols-1 gap-3 min-[460px]:grid-cols-2 lg:grid-cols-5">
              {WHO_WE_BRING_TOGETHER.map((group, index) => {
                const Icon = WHO_WE_BRING_TOGETHER_ICONS[index % WHO_WE_BRING_TOGETHER_ICONS.length];

                return (
                  <div
                    key={group}
                    className="group flex min-h-[58px] items-center justify-center gap-3 rounded-2xl border border-[color:var(--hairline)] bg-[color:var(--off-white)] px-4 py-3 text-center text-sm font-medium text-[color:var(--navy)] transition-all duration-300 hover:-translate-y-0.5 hover:border-[color:var(--gold)] hover:bg-white hover:shadow-[0_14px_34px_-24px_rgba(5,43,87,0.18)] md:px-5"
                  >
                    <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[color:var(--gold-soft)] transition-all duration-300 group-hover:scale-[1.06] group-hover:bg-[color:var(--navy)]">
                      <Icon className="h-4.5 w-4.5 text-[color:var(--gold-dark)] transition-all duration-300 group-hover:scale-110 group-hover:-translate-y-0.5 group-hover:text-[color:var(--gold-light)]" />
                    </div>
                    {group}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      <section className="gef-section !pt-8 !pb-12 md:!pt-10 md:!pb-14 bg-[color:var(--off-white)]">
        <div className="gef-container">
          <SectionHeading
            eyebrow="Leadership"
            title="People shaping the GEF agenda."
            align="center"
          />
          <div className="mx-auto mt-12 grid max-w-3xl grid-cols-1 gap-4 min-[460px]:grid-cols-2 md:gap-6">
            {ABOUT_LEADERSHIP.map((person) => (
              <ProfileCard
                key={person.name}
                name={person.name}
                photo={person.photo}
                bio={person.bio}
                compactName
              />
            ))}
          </div>

          <LeadershipGroup
            title="Patrons"
            subtitle="Senior voices whose presence strengthens the credibility and direction of the GEF platform."
            people={ABOUT_PATRONS}
            className="mt-16"
          />

          <LeadershipGroup
            title="Mentors"
            subtitle="Guides and ecosystem builders supporting entrepreneurs, partnerships, and long-term growth."
            people={ABOUT_MENTORS}
            className="mt-16"
          />
        </div>
      </section>

      <FinalCTA />
    </>
  );
}

function LeadershipGroup({
  title,
  subtitle,
  people,
  className = "",
}: {
  title: string;
  subtitle: string;
  people: ReadonlyArray<{
    name: string;
    title: string;
    organization?: string;
    country?: string;
    photo: string;
  }>;
  className?: string;
}) {
  const profileGridRef = useRef<HTMLDivElement>(null);
  useAlignedProfileNames(profileGridRef);
  const getProfileMetaLines = (person: (typeof people)[number]) =>
    [person.title, person.organization, person.country].filter(
      (line): line is string => Boolean(line && line.trim()),
    );

  return (
    <div className={className}>
      <div className="mx-auto max-w-3xl text-center">
        <h3
          className="text-[clamp(1.5rem,2.4vw,2.1rem)] font-normal text-[color:var(--navy)]"
          style={{ fontFamily: "var(--font-display)" }}
        >
          {title}
        </h3>
        <p className="mt-3 text-sm leading-relaxed text-[color:var(--ink-soft)] md:text-base">
          {subtitle}
        </p>
      </div>

      <div ref={profileGridRef} className="mt-10 grid grid-cols-1 gap-4 min-[460px]:grid-cols-2 md:gap-6 lg:grid-cols-4">
        {people.map((person) => {
          const metaLines = getProfileMetaLines(person);

          return (
            <article
              key={person.name}
              data-profile-card
              className="group mx-auto flex h-full w-full max-w-[16rem] flex-col overflow-hidden rounded-2xl border border-[color:var(--hairline)] bg-white text-center transition-all duration-300 hover:-translate-y-1 hover:border-[color:var(--gold)] hover:shadow-[0_18px_44px_-22px_rgba(5,43,87,0.18)]"
            >
              <div className="aspect-[43/50] overflow-hidden border-b border-[color:var(--hairline)] bg-white">
                <img
                  src={person.photo}
                  alt={person.name}
                  loading="lazy"
                  className="h-full w-full object-contain object-center transition-transform duration-700 group-hover:scale-[1.01]"
                  width={258}
                  height={300}
                />
              </div>
              <div className="flex flex-1 flex-col items-center px-4 py-5">
                <h4
                  data-profile-name
                  className="min-h-[1.65rem] text-lg font-semibold leading-snug text-[color:var(--navy)]"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {person.name}
                </h4>
                <div className="mt-2 space-y-0.5 text-sm leading-relaxed text-[color:var(--ink-soft)]">
                  {metaLines.map((line, metaIndex) => (
                    <p
                      key={`${person.name}-${line}-${metaIndex}`}
                      className={`min-h-[1.35rem] ${
                        metaIndex === 0
                          ? "font-medium text-[color:var(--gold-dark)]"
                          : metaIndex === metaLines.length - 1 && person.country === line
                            ? "uppercase tracking-[0.08em] text-[color:var(--ink-muted)]"
                            : ""
                      }`}
                    >
                      {line}
                    </p>
                  ))}
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
