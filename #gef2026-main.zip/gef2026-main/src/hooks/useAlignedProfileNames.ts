import { useEffect, type RefObject } from "react";

// Keeps profile metadata aligned with the tallest fully visible name in each responsive row.
export function useAlignedProfileNames(
  containerRef: RefObject<HTMLElement | null>,
  dependency?: unknown,
) {
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const alignNames = () => {
      const cards = Array.from(container.querySelectorAll<HTMLElement>("[data-profile-card]"));
      const rows = new Map<number, HTMLElement[]>();

      cards.forEach((card) => {
        const name = card.querySelector<HTMLElement>("[data-profile-name]");
        if (name) name.style.minHeight = "";

        const row = Math.round(card.offsetTop);
        rows.set(row, [...(rows.get(row) ?? []), card]);
      });

      rows.forEach((rowCards) => {
        const names = rowCards
          .map((card) => card.querySelector<HTMLElement>("[data-profile-name]"))
          .filter((name): name is HTMLElement => Boolean(name));
        const height = Math.max(...names.map((name) => name.offsetHeight), 0);

        names.forEach((name) => {
          name.style.minHeight = `${height}px`;
        });
      });
    };

    const frame = window.requestAnimationFrame(alignNames);
    const observer = new ResizeObserver(alignNames);
    observer.observe(container);

    return () => {
      window.cancelAnimationFrame(frame);
      observer.disconnect();
    };
  }, [containerRef, dependency]);
}
