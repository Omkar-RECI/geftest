$ErrorActionPreference = 'Stop'

$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$outputDir = Join-Path $root 'deliverables'
New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
$htmlPath = Join-Path $outputDir ("GEF_Legal_Policies_{0}.html" -f (Get-Date -Format 'yyyyMMddHHmmss'))
$docxPath = Join-Path $outputDir 'GEF_Legal_Policies.docx'
$pdfPath = Join-Path $outputDir 'GEF_Legal_Policies.pdf'

$privacy = @(
    @('Who this policy applies to', 'This Privacy Policy applies to gefofficial.com and Global Entrepreneurs Forum (GEF) digital communications. GEF is a flagship initiative of RECI India Foundation. It explains how we handle personal information when you browse our website, contact us, or use an event registration link made available through this website.'),
    @('Information we may collect', 'We may receive information you choose to provide, such as your name, email address, telephone number, organisation and message when you contact GEF. Our website may also collect limited technical information such as device, browser, pages visited and approximate location through cookies or analytics tools, where enabled.'),
    @('How we use information', 'We use information to respond to enquiries, manage event interest and registrations, improve website performance, communicate relevant GEF updates where permitted, and protect the website from misuse. We do not sell personal information.'),
    @('Event registration and third parties', 'Event registration may be completed through an embedded third-party ticketing or registration service. Information submitted within that service is handled under that provider''s terms and privacy practices, in addition to this policy. Please review the provider''s notices before entering payment or registration details.'),
    @('Sharing and retention', 'We share information only where reasonably necessary to operate GEF, work with authorised service providers, meet legal obligations, or protect our rights and users. We retain information only for as long as needed for the relevant purpose, legal requirements, or legitimate operational records.'),
    @('Your choices', 'You may request access, correction, deletion, or withdrawal of consent for personal information held by GEF, subject to applicable law and legitimate record-keeping requirements. You can also manage most browser cookies through your browser settings.'),
    @('Security and updates', 'We use reasonable organisational and technical safeguards, but no internet transmission or storage system can be guaranteed completely secure. We may update this policy as our website, events, or legal obligations change. The updated version will be posted on this page.')
)

$terms = @(
    @('Acceptance of these terms', 'By accessing or using this website, you agree to these Terms of Use. This website is operated for Global Entrepreneurs Forum (GEF), a flagship initiative of RECI India Foundation. If you do not agree, please do not use the website.'),
    @('Website content', 'GEF provides information about forums, events, speakers, partners, media and related initiatives for general informational purposes. We aim to keep content accurate and current, but event programmes, speakers, venues, schedules and other details may change without notice.'),
    @('Appropriate use', 'You must use this website lawfully and must not interfere with its security or operation, attempt unauthorised access, submit false information, misuse contact channels, or reproduce site content in a way that suggests endorsement by GEF or RECI India Foundation.'),
    @('Intellectual property', 'Unless stated otherwise, the GEF name, logos, website design, text, graphics, photographs and other materials are owned by or used with permission by GEF or their respective rights holders. They may not be copied, modified, distributed or commercially used without prior written permission.'),
    @('Events and registrations', 'Event participation, registration, payment, cancellation and attendance may be subject to separate event-specific terms and the policies of the relevant registration provider. Registration availability does not guarantee admission until confirmed through the applicable event process.'),
    @('Third-party links', 'This website may link to third-party websites, including RECI India Foundation, social channels and registration providers. These sites are outside GEF''s control. Their content, availability, security and privacy practices are governed by their own terms.'),
    @('Liability and contact', 'To the extent permitted by applicable law, GEF and RECI India Foundation are not liable for indirect loss arising from use of, or inability to use, this website. Questions about these terms can be sent to info@gefofficial.com. We may revise these terms by posting an updated version on this page.')
)

$payment = @(
    @('Registration fees and payment', 'Registration fees, inclusions, applicable taxes and payment methods are displayed during checkout. A registration is confirmed only after successful payment and confirmation from the applicable registration platform. Payments are processed by the designated third-party payment or ticketing provider; GEF does not store card or banking credentials.'),
    @('Cancellation by a participant', 'Cancellation or refund eligibility, if any, is governed by the event-specific terms shown at registration. Where no separate cancellation window is stated, confirmed registration fees are non-refundable, except where required by applicable law or where GEF cancels the event. Requests must be sent from the registered email address before the stated deadline.'),
    @('Transfers and substitutions', 'A delegate substitution may be considered before the event, subject to the event-specific deadline, delegate category, verification requirements and written approval from GEF. Tickets may not be transferred, sold or used for commercial resale without prior written approval.'),
    @('Event changes, postponement or cancellation', 'GEF may reasonably modify the programme, speakers, venue, format or schedule. If an event is postponed, registrations may be moved to the revised date. If GEF cancels a paid event, the available options, including a transfer, credit or refund where applicable, will be communicated to registered delegates in accordance with applicable law.'),
    @('Refund processing', 'Approved refunds are returned to the original payment method where possible. Processing times depend on the payment provider and financial institution. Any non-refundable third-party charges will be disclosed where applicable before a refund is processed.'),
    @('Travel and other costs', 'GEF is not responsible for travel, accommodation, visa, insurance or other personal costs incurred by a delegate, including where an event programme or schedule changes, except where required by applicable law.'),
    @('Chargebacks and support', 'Please contact GEF first to resolve a payment concern before initiating a chargeback. For payment, cancellation, transfer or refund requests, email info@gefofficial.com with your registration name, event name and confirmation reference.'),
    @('Applicable law and policy updates', 'This policy is subject to applicable law. GEF may update it before an event to reflect operational, regulatory or event-specific requirements. The version published on this page applies from its stated update date, without limiting rights that cannot be excluded under applicable law.')
)

function HtmlEncode([string]$value) { [System.Net.WebUtility]::HtmlEncode($value) }
function PolicyHtml([string]$number, [string]$title, [string]$intro, [object[]]$items) {
    $content = "<section class='policy'><div class='eyebrow'>$number</div><h1>$title</h1><div class='rule'></div><p class='updated'>Last updated: 12 September 2026</p><p class='intro'>$(HtmlEncode $intro)</p>"
    $i = 0
    foreach ($item in $items) {
        $i++
        $content += "<article><h2>$i. $(HtmlEncode $item[0])</h2><p>$(HtmlEncode $item[1])</p></article>"
    }
    return "$content</section>"
}

$html = @"
<!doctype html><html><head><meta charset='utf-8'><title>GEF Legal Policies</title>
<style>
@page { size: A4; margin: 18mm 18mm 17mm; }
body { font-family: Aptos, Calibri, Arial, sans-serif; color:#26384A; font-size:10.5pt; line-height:1.45; }
.cover { min-height: 228mm; box-sizing:border-box; padding:64mm 20mm 32mm; background:#031C3B; color:#fff; text-align:center; }
.cover .brand { color:#E8C46A; font-size:11pt; font-weight:700; letter-spacing:1.6pt; text-transform:uppercase; }
.cover h1 { color:#fff; font-family:Georgia,serif; font-size:30pt; font-weight:normal; margin:12pt 0; }
.cover .subtitle { color:#D8E4F2; font-size:11pt; }
.cover .line { border-top:2px solid #C8962D; width:52mm; margin:20pt auto; }
.cover .attribution { color:#E8C46A; font-weight:bold; margin-top:76mm; }
.cover .small { color:#D8E4F2; font-size:9.5pt; }
.contents, .policy { page-break-before:always; }
.contents { padding-top:20mm; }
.contents h1, .policy h1 { color:#052B57; font-family:Georgia,serif; font-weight:normal; }
.contents h1 { font-size:28pt; margin:0 0 10pt; border-bottom:2px solid #C8962D; padding-bottom:9pt; }
.contents .entry { padding:8pt 0; font-family:Georgia,serif; font-size:15pt; color:#052B57; }
.contents .num, .eyebrow { color:#C8962D; font-family:Aptos,Calibri,sans-serif; font-size:10pt; font-weight:bold; letter-spacing:1.5pt; }
.note { margin-top:38pt; padding:14pt 16pt; background:#F8F6F0; border-left:3px solid #C8962D; }
.policy { padding-top:11mm; }
.policy h1 { font-size:27pt; margin:3pt 0 8pt; }
.rule { border-top:2px solid #C8962D; margin-bottom:8pt; }
.updated { color:#6B7785; font-size:9pt; margin-bottom:18pt; }
.intro { font-size:11.2pt; margin-bottom:18pt; }
article { margin:0 0 12pt; page-break-inside:avoid; }
article h2 { color:#052B57; font-family:Georgia,serif; font-size:13.5pt; margin:0 0 3pt; }
article p { margin:0; }
</style></head><body>
<section class='cover'><div class='brand'>Global Entrepreneurs Forum</div><h1>GEF Legal Policies</h1><div class='subtitle'>Privacy Policy | Terms of Use | Payment &amp; Refund Policy</div><div class='line'></div><div class='attribution'>A flagship initiative of RECI India Foundation</div><p class='small'>Official website: gefofficial.com<br>Document version: 12 September 2026</p></section>
<section class='contents'><h1>Contents</h1><div class='entry'><span class='num'>01&nbsp;&nbsp;</span>Privacy Policy</div><div class='entry'><span class='num'>02&nbsp;&nbsp;</span>Terms of Use</div><div class='entry'><span class='num'>03&nbsp;&nbsp;</span>Payment &amp; Refund Policy</div><div class='note'><strong>Policy note</strong><br>This document consolidates the legal-policy content currently published by GEF. Event-specific terms displayed during registration remain applicable where stated.</div></section>
$(PolicyHtml '01' 'Privacy Policy' 'Global Entrepreneurs Forum respects your privacy and handles information responsibly. For privacy questions or requests, contact us at info@gefofficial.com.' $privacy)
$(PolicyHtml '02' 'Terms of Use' 'These terms establish the ground rules for using the Global Entrepreneurs Forum website and related digital services.' $terms)
$(PolicyHtml '03' 'Payment &amp; Refund Policy' 'This policy applies to paid registrations for Global Entrepreneurs Forum events, a flagship initiative of RECI India Foundation. Event-specific terms shown during registration form part of this policy and will prevail if they differ.' $payment)
</body></html>
"@

Set-Content -LiteralPath $htmlPath -Value $html -Encoding UTF8
$word = New-Object -ComObject Word.Application
$word.Visible = $false
try {
    $document = $word.Documents.Open($htmlPath)
    $document.SaveAs2($docxPath, 16)
    $document.ExportAsFixedFormat($pdfPath, 17)
    $document.Close()
} finally {
    $word.Quit()
    [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($word)
}
Remove-Item -LiteralPath $htmlPath -Force
Write-Output $docxPath
