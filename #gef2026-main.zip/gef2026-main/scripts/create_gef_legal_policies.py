from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


OUTPUT = Path("deliverables/GEF_Legal_Policies.docx")
NAVY = "052B57"
NAVY_DEEP = "031C3B"
GOLD = "C8962D"
GOLD_LIGHT = "E8C46A"
INK = "26384A"
MUTED = "6B7785"
OFF_WHITE = "F8F6F0"
HAIRLINE = "D8DEE5"

PRIVACY = [
    ("Who this policy applies to", "This Privacy Policy applies to gefofficial.com and Global Entrepreneurs Forum (GEF) digital communications. GEF is a flagship initiative of RECI India Foundation. It explains how we handle personal information when you browse our website, contact us, or use an event registration link made available through this website."),
    ("Information we may collect", "We may receive information you choose to provide, such as your name, email address, telephone number, organisation and message when you contact GEF. Our website may also collect limited technical information such as device, browser, pages visited and approximate location through cookies or analytics tools, where enabled."),
    ("How we use information", "We use information to respond to enquiries, manage event interest and registrations, improve website performance, communicate relevant GEF updates where permitted, and protect the website from misuse. We do not sell personal information."),
    ("Event registration and third parties", "Event registration may be completed through an embedded third-party ticketing or registration service. Information submitted within that service is handled under that provider's terms and privacy practices, in addition to this policy. Please review the provider's notices before entering payment or registration details."),
    ("Sharing and retention", "We share information only where reasonably necessary to operate GEF, work with authorised service providers, meet legal obligations, or protect our rights and users. We retain information only for as long as needed for the relevant purpose, legal requirements, or legitimate operational records."),
    ("Your choices", "You may request access, correction, deletion, or withdrawal of consent for personal information held by GEF, subject to applicable law and legitimate record-keeping requirements. You can also manage most browser cookies through your browser settings."),
    ("Security and updates", "We use reasonable organisational and technical safeguards, but no internet transmission or storage system can be guaranteed completely secure. We may update this policy as our website, events, or legal obligations change. The updated version will be posted on this page."),
]

TERMS = [
    ("Acceptance of these terms", "By accessing or using this website, you agree to these Terms of Use. This website is operated for Global Entrepreneurs Forum (GEF), a flagship initiative of RECI India Foundation. If you do not agree, please do not use the website."),
    ("Website content", "GEF provides information about forums, events, speakers, partners, media and related initiatives for general informational purposes. We aim to keep content accurate and current, but event programmes, speakers, venues, schedules and other details may change without notice."),
    ("Appropriate use", "You must use this website lawfully and must not interfere with its security or operation, attempt unauthorised access, submit false information, misuse contact channels, or reproduce site content in a way that suggests endorsement by GEF or RECI India Foundation."),
    ("Intellectual property", "Unless stated otherwise, the GEF name, logos, website design, text, graphics, photographs and other materials are owned by or used with permission by GEF or their respective rights holders. They may not be copied, modified, distributed or commercially used without prior written permission."),
    ("Events and registrations", "Event participation, registration, payment, cancellation and attendance may be subject to separate event-specific terms and the policies of the relevant registration provider. Registration availability does not guarantee admission until confirmed through the applicable event process."),
    ("Third-party links", "This website may link to third-party websites, including RECI India Foundation, social channels and registration providers. These sites are outside GEF's control. Their content, availability, security and privacy practices are governed by their own terms."),
    ("Liability and contact", "To the extent permitted by applicable law, GEF and RECI India Foundation are not liable for indirect loss arising from use of, or inability to use, this website. Questions about these terms can be sent to info@gefofficial.com. We may revise these terms by posting an updated version on this page."),
]

PAYMENT = [
    ("Registration fees and payment", "Registration fees, inclusions, applicable taxes and payment methods are displayed during checkout. A registration is confirmed only after successful payment and confirmation from the applicable registration platform. Payments are processed by the designated third-party payment or ticketing provider; GEF does not store card or banking credentials."),
    ("Cancellation by a participant", "Cancellation or refund eligibility, if any, is governed by the event-specific terms shown at registration. Where no separate cancellation window is stated, confirmed registration fees are non-refundable, except where required by applicable law or where GEF cancels the event. Requests must be sent from the registered email address before the stated deadline."),
    ("Transfers and substitutions", "A delegate substitution may be considered before the event, subject to the event-specific deadline, delegate category, verification requirements and written approval from GEF. Tickets may not be transferred, sold or used for commercial resale without prior written approval."),
    ("Event changes, postponement or cancellation", "GEF may reasonably modify the programme, speakers, venue, format or schedule. If an event is postponed, registrations may be moved to the revised date. If GEF cancels a paid event, the available options, including a transfer, credit or refund where applicable, will be communicated to registered delegates in accordance with applicable law."),
    ("Refund processing", "Approved refunds are returned to the original payment method where possible. Processing times depend on the payment provider and financial institution. Any non-refundable third-party charges will be disclosed where applicable before a refund is processed."),
    ("Travel and other costs", "GEF is not responsible for travel, accommodation, visa, insurance or other personal costs incurred by a delegate, including where an event programme or schedule changes, except where required by applicable law."),
    ("Chargebacks and support", "Please contact GEF first to resolve a payment concern before initiating a chargeback. For payment, cancellation, transfer or refund requests, email info@gefofficial.com with your registration name, event name and confirmation reference."),
    ("Applicable law and policy updates", "This policy is subject to applicable law. GEF may update it before an event to reflect operational, regulatory or event-specific requirements. The version published on this page applies from its stated update date, without limiting rights that cannot be excluded under applicable law."),
]


def shade(cell, color):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), color)
    tc_pr.append(shd)


def border_bottom(paragraph, color=GOLD, size="12"):
    p_pr = paragraph._p.get_or_add_pPr()
    p_bdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), size)
    bottom.set(qn("w:space"), "5")
    bottom.set(qn("w:color"), color)
    p_bdr.append(bottom)
    p_pr.append(p_bdr)


def set_font(run, size, color=INK, bold=False, name="Aptos"):
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:ascii"), name)
    run._element.rPr.rFonts.set(qn("w:hAnsi"), name)
    run.font.size = Pt(size)
    run.font.color.rgb = RGBColor.from_string(color)
    run.bold = bold


def style_doc(doc):
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(0.82)
    section.bottom_margin = Inches(0.78)
    section.left_margin = Inches(0.86)
    section.right_margin = Inches(0.86)
    section.header_distance = Inches(0.35)
    section.footer_distance = Inches(0.35)
    normal = doc.styles["Normal"]
    normal.font.name = "Aptos"
    normal._element.rPr.rFonts.set(qn("w:ascii"), "Aptos")
    normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Aptos")
    normal.font.size = Pt(10.5)
    normal.font.color.rgb = RGBColor.from_string(INK)
    normal.paragraph_format.space_after = Pt(7)
    normal.paragraph_format.line_spacing = 1.16


def add_header_footer(section):
    header = section.header
    p = header.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run("GLOBAL ENTREPRENEURS FORUM  |  GEF LEGAL POLICIES")
    set_font(r, 8, MUTED, True)
    footer = section.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(0)
    r = p.add_run("GEF | Flagship initiative of RECI India Foundation | ")
    set_font(r, 8, MUTED)
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    p._p.append(fld)


def add_cover(doc):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    cell = table.cell(0, 0)
    cell.width = Inches(6.78)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    shade(cell, NAVY_DEEP)
    for _ in range(3):
        cell.add_paragraph()
    p = cell.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("GLOBAL ENTREPRENEURS FORUM")
    set_font(r, 12, GOLD_LIGHT, True)
    p = cell.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("GEF Legal Policies")
    set_font(r, 30, "FFFFFF", False, "Georgia")
    p.paragraph_format.space_before = Pt(8)
    p.paragraph_format.space_after = Pt(8)
    p = cell.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("Privacy Policy | Terms of Use | Payment & Refund Policy")
    set_font(r, 11, "D8E4F2")
    for _ in range(3):
        cell.add_paragraph()

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(24)
    r = p.add_run("A flagship initiative of RECI India Foundation")
    set_font(r, 11, NAVY, True)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("Official website: gefofficial.com")
    set_font(r, 10, MUTED)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("Document version: 12 September 2026")
    set_font(r, 10, MUTED)


def add_contents(doc):
    doc.add_page_break()
    p = doc.add_paragraph()
    r = p.add_run("Contents")
    set_font(r, 23, NAVY, False, "Georgia")
    border_bottom(p)
    entries = [
        ("01", "Privacy Policy"),
        ("02", "Terms of Use"),
        ("03", "Payment & Refund Policy"),
    ]
    for number, title in entries:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(10)
        p.paragraph_format.space_after = Pt(5)
        r = p.add_run(f"{number}  ")
        set_font(r, 10, GOLD, True)
        r = p.add_run(title)
        set_font(r, 14, NAVY, True, "Georgia")
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(28)
    r = p.add_run("Policy note")
    set_font(r, 11, NAVY, True)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run("This document consolidates the legal-policy content currently published by GEF. Event-specific terms displayed during registration remain applicable where stated.")
    set_font(r, 10.5, INK)


def add_policy(doc, number, title, intro, sections, updated):
    doc.add_page_break()
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(number)
    set_font(r, 10, GOLD, True)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(8)
    r = p.add_run(title)
    set_font(r, 25, NAVY, False, "Georgia")
    border_bottom(p)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(16)
    r = p.add_run(updated)
    set_font(r, 9, MUTED)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(18)
    r = p.add_run(intro)
    set_font(r, 11, INK)
    for index, (heading, body) in enumerate(sections, start=1):
        p = doc.add_paragraph()
        p.paragraph_format.keep_with_next = True
        p.paragraph_format.space_before = Pt(11)
        p.paragraph_format.space_after = Pt(3)
        r = p.add_run(f"{index}. {heading}")
        set_font(r, 13, NAVY, True, "Georgia")
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(7)
        r = p.add_run(body)
        set_font(r, 10.5, INK)


def main():
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    doc = Document()
    style_doc(doc)
    for section in doc.sections:
        add_header_footer(section)
    add_cover(doc)
    add_contents(doc)
    add_policy(
        doc,
        "01",
        "Privacy Policy",
        "Global Entrepreneurs Forum respects your privacy and handles information responsibly. For privacy questions or requests, contact us at info@gefofficial.com.",
        PRIVACY,
        "Last updated: 12 September 2026",
    )
    add_policy(
        doc,
        "02",
        "Terms of Use",
        "These terms establish the ground rules for using the Global Entrepreneurs Forum website and related digital services.",
        TERMS,
        "Last updated: 12 September 2026",
    )
    add_policy(
        doc,
        "03",
        "Payment & Refund Policy",
        "This policy applies to paid registrations for Global Entrepreneurs Forum events, a flagship initiative of RECI India Foundation. Event-specific terms shown during registration form part of this policy and will prevail if they differ.",
        PAYMENT,
        "Last updated: 12 September 2026",
    )
    doc.core_properties.title = "GEF Legal Policies"
    doc.core_properties.subject = "Privacy Policy, Terms of Use, and Payment & Refund Policy"
    doc.core_properties.author = "Global Entrepreneurs Forum"
    doc.save(OUTPUT)
    print(OUTPUT.resolve())


if __name__ == "__main__":
    main()
